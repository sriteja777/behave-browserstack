# coding: UTF-8
import sys
bstack1l1llll_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack11l1lll_opy_ = 7
def bstack1l111l_opy_ (bstack1ll1l1l_opy_):
    global bstack1lllll1l_opy_
    bstack1lll_opy_ = ord (bstack1ll1l1l_opy_ [-1])
    bstack11l1111_opy_ = bstack1ll1l1l_opy_ [:-1]
    bstack111111_opy_ = bstack1lll_opy_ % len (bstack11l1111_opy_)
    bstack1llllll_opy_ = bstack11l1111_opy_ [:bstack111111_opy_] + bstack11l1111_opy_ [bstack111111_opy_:]
    if bstack1l1llll_opy_:
        bstack1l1l1_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack11111l1_opy_ + bstack1lll_opy_) % bstack11l1lll_opy_) for bstack11111l1_opy_, char in enumerate (bstack1llllll_opy_)])
    else:
        bstack1l1l1_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack11111l1_opy_ + bstack1lll_opy_) % bstack11l1lll_opy_) for bstack11111l1_opy_, char in enumerate (bstack1llllll_opy_)])
    return eval (bstack1l1l1_opy_)
import threading
bstack1l1l111lll_opy_ = 10
bstack1l1l1111ll_opy_ = 5
bstack1l1l11l11l_opy_ = 30
bstack1l1l1111l1_opy_ = 2
class bstack1l1l1llll1_opy_:
    def __init__(self, handler, bstack1l1l111l11_opy_=bstack1l1l111lll_opy_, bstack1l1l111l1l_opy_=bstack1l1l1111ll_opy_):
        self.queue = []
        self.handler = handler
        self.bstack1l1l111l11_opy_ = bstack1l1l111l11_opy_
        self.bstack1l1l111l1l_opy_ = bstack1l1l111l1l_opy_
        self.lock = threading.Lock()
        self.timer = None
    def start(self):
        if not self.timer:
            self.bstack1l1l11l111_opy_()
    def bstack1l1l11l111_opy_(self):
        self.timer = threading.Timer(self.bstack1l1l111l1l_opy_, self.bstack1l1l11l1l1_opy_)
        self.timer.start()
    def bstack1l1l11l1ll_opy_(self):
        self.timer.cancel()
    def bstack1l1l111ll1_opy_(self):
        self.bstack1l1l11l1ll_opy_()
        self.bstack1l1l11l111_opy_()
    def add(self, event):
        with self.lock:
            self.queue.append(event)
            if len(self.queue) >= self.bstack1l1l111l11_opy_:
                t = threading.Thread(target=self.bstack1l1l11l1l1_opy_)
                t.start()
                self.bstack1l1l111ll1_opy_()
    def bstack1l1l11l1l1_opy_(self):
        if len(self.queue) <= 0:
            return
        data = self.queue[:self.bstack1l1l111l11_opy_]
        del self.queue[:self.bstack1l1l111l11_opy_]
        self.handler(data)
    def shutdown(self):
        self.bstack1l1l11l1ll_opy_()
        while len(self.queue) > 0:
            self.bstack1l1l11l1l1_opy_()