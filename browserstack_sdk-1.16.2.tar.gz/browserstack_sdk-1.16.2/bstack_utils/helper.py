# coding: UTF-8
import sys
bstack1l1llll_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack11l1lll_opy_ = 7
def bstack1l111l_opy_ (bstack1ll1l1l_opy_):
    global bstack1lllll1l_opy_
    bstack1lll_opy_ = ord (bstack1ll1l1l_opy_ [-1])
    bstack11l1111_opy_ = bstack1ll1l1l_opy_ [:-1]
    bstack111111_opy_ = bstack1lll_opy_ % len (bstack11l1111_opy_)
    bstack1llllll_opy_ = bstack11l1111_opy_ [:bstack111111_opy_] + bstack11l1111_opy_ [bstack111111_opy_:]
    if bstack1l1llll_opy_:
        bstack1l1l1_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack11111l1_opy_ + bstack1lll_opy_) % bstack11l1lll_opy_) for bstack11111l1_opy_, char in enumerate (bstack1llllll_opy_)])
    else:
        bstack1l1l1_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack11111l1_opy_ + bstack1lll_opy_) % bstack11l1lll_opy_) for bstack11111l1_opy_, char in enumerate (bstack1llllll_opy_)])
    return eval (bstack1l1l1_opy_)
import datetime
import json
import os
import re
import subprocess
from urllib.parse import urlparse
import git
import requests
from packaging import version
from bstack_utils.config import Config
from bstack_utils.constants import bstack1ll111l1l1_opy_, bstack111ll1ll_opy_, bstack1ll11llll1_opy_, bstack1lll1l1ll_opy_
from bstack_utils.messages import bstack1lll111ll_opy_
from bstack_utils.proxy import bstack11l1l111_opy_
bstack1l1ll1ll1_opy_ = Config.get_instance()
def bstack1l1lll11ll_opy_(config):
    return config[bstack1l111l_opy_ (u"ࠬࡻࡳࡦࡴࡑࡥࡲ࡫ࠧဋ")]
def bstack1l1lll1l11_opy_(config):
    return config[bstack1l111l_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸࡑࡥࡺࠩဌ")]
def bstack1l11ll1lll_opy_(obj):
    values = []
    bstack1l11ll1111_opy_ = re.compile(bstack1l111l_opy_ (u"ࡲࠣࡠࡆ࡙ࡘ࡚ࡏࡎࡡࡗࡅࡌࡥ࡜ࡥ࠭ࠧࠦဍ"), re.I)
    for key in obj.keys():
        if bstack1l11ll1111_opy_.match(key):
            values.append(obj[key])
    return values
def bstack1l1lll11l1_opy_(config):
    tags = []
    tag = config.get(bstack1l111l_opy_ (u"ࠣࡥࡸࡷࡹࡵ࡭ࡕࡣࡪࠦဎ")) or os.environ.get(bstack1l111l_opy_ (u"ࠤࡆ࡙ࡘ࡚ࡏࡎࡡࡗࡅࡌࠨဏ"))
    if tag:
        tags.append(tag)
    tags.extend(bstack1l11ll1lll_opy_(os.environ))
    tags.extend(bstack1l11ll1lll_opy_(config))
    return tags
def bstack1l11lll1l1_opy_(markers):
    tags = []
    for marker in markers:
        tags.append(marker.name)
    return tags
def bstack1l11lllll1_opy_(bstack1l11lll111_opy_):
    if not bstack1l11lll111_opy_:
        return bstack1l111l_opy_ (u"ࠪࠫတ")
    return bstack1l111l_opy_ (u"ࠦࢀࢃࠠࠩࡽࢀ࠭ࠧထ").format(bstack1l11lll111_opy_.name, bstack1l11lll111_opy_.email)
def bstack1l1llll11l_opy_():
    try:
        repo = git.Repo(search_parent_directories=True)
        bstack1l11ll1l11_opy_ = repo.common_dir
        info = {
            bstack1l111l_opy_ (u"ࠧࡹࡨࡢࠤဒ"): repo.head.commit.hexsha,
            bstack1l111l_opy_ (u"ࠨࡳࡩࡱࡵࡸࡤࡹࡨࡢࠤဓ"): repo.git.rev_parse(repo.head.commit, short=True),
            bstack1l111l_opy_ (u"ࠢࡣࡴࡤࡲࡨ࡮ࠢန"): repo.active_branch.name,
            bstack1l111l_opy_ (u"ࠣࡶࡤ࡫ࠧပ"): repo.git.describe(all=True, tags=True, exact_match=True),
            bstack1l111l_opy_ (u"ࠤࡦࡳࡲࡳࡩࡵࡶࡨࡶࠧဖ"): bstack1l11lllll1_opy_(repo.head.commit.committer),
            bstack1l111l_opy_ (u"ࠥࡧࡴࡳ࡭ࡪࡶࡷࡩࡷࡥࡤࡢࡶࡨࠦဗ"): repo.head.commit.committed_datetime.isoformat(),
            bstack1l111l_opy_ (u"ࠦࡦࡻࡴࡩࡱࡵࠦဘ"): bstack1l11lllll1_opy_(repo.head.commit.author),
            bstack1l111l_opy_ (u"ࠧࡧࡵࡵࡪࡲࡶࡤࡪࡡࡵࡧࠥမ"): repo.head.commit.authored_datetime.isoformat(),
            bstack1l111l_opy_ (u"ࠨࡣࡰ࡯ࡰ࡭ࡹࡥ࡭ࡦࡵࡶࡥ࡬࡫ࠢယ"): repo.head.commit.message,
            bstack1l111l_opy_ (u"ࠢࡳࡱࡲࡸࠧရ"): repo.git.rev_parse(bstack1l111l_opy_ (u"ࠣ࠯࠰ࡷ࡭ࡵࡷ࠮ࡶࡲࡴࡱ࡫ࡶࡦ࡮ࠥလ")),
            bstack1l111l_opy_ (u"ࠤࡦࡳࡲࡳ࡯࡯ࡡࡪ࡭ࡹࡥࡤࡪࡴࠥဝ"): bstack1l11ll1l11_opy_,
            bstack1l111l_opy_ (u"ࠥࡻࡴࡸ࡫ࡵࡴࡨࡩࡤ࡭ࡩࡵࡡࡧ࡭ࡷࠨသ"): subprocess.check_output([bstack1l111l_opy_ (u"ࠦ࡬࡯ࡴࠣဟ"), bstack1l111l_opy_ (u"ࠧࡸࡥࡷ࠯ࡳࡥࡷࡹࡥࠣဠ"), bstack1l111l_opy_ (u"ࠨ࠭࠮ࡩ࡬ࡸ࠲ࡩ࡯࡮࡯ࡲࡲ࠲ࡪࡩࡳࠤအ")]).strip().decode(
                bstack1l111l_opy_ (u"ࠧࡶࡶࡩ࠱࠽࠭ဢ")),
            bstack1l111l_opy_ (u"ࠣ࡮ࡤࡷࡹࡥࡴࡢࡩࠥဣ"): repo.git.describe(tags=True, abbrev=0, always=True),
            bstack1l111l_opy_ (u"ࠤࡦࡳࡲࡳࡩࡵࡵࡢࡷ࡮ࡴࡣࡦࡡ࡯ࡥࡸࡺ࡟ࡵࡣࡪࠦဤ"): repo.git.rev_list(
                bstack1l111l_opy_ (u"ࠥࡿࢂ࠴࠮ࡼࡿࠥဥ").format(repo.head.commit, repo.git.describe(tags=True, abbrev=0, always=True)), count=True)
        }
        remotes = repo.remotes
        bstack1l11ll111l_opy_ = []
        for remote in remotes:
            bstack1l11lll11l_opy_ = {
                bstack1l111l_opy_ (u"ࠦࡳࡧ࡭ࡦࠤဦ"): remote.name,
                bstack1l111l_opy_ (u"ࠧࡻࡲ࡭ࠤဧ"): remote.url,
            }
            bstack1l11ll111l_opy_.append(bstack1l11lll11l_opy_)
        return {
            bstack1l111l_opy_ (u"ࠨ࡮ࡢ࡯ࡨࠦဨ"): bstack1l111l_opy_ (u"ࠢࡨ࡫ࡷࠦဩ"),
            **info,
            bstack1l111l_opy_ (u"ࠣࡴࡨࡱࡴࡺࡥࡴࠤဪ"): bstack1l11ll111l_opy_
        }
    except Exception as err:
        print(bstack1l111l_opy_ (u"ࠤࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡲࡲࡴࡺࡲࡡࡵ࡫ࡱ࡫ࠥࡍࡩࡵࠢࡰࡩࡹࡧࡤࡢࡶࡤࠤࡼ࡯ࡴࡩࠢࡨࡶࡷࡵࡲ࠻ࠢࡾࢁࠧါ").format(err))
        return {}
def bstack1l1ll1lll1_opy_():
    env = os.environ
    if (bstack1l111l_opy_ (u"ࠥࡎࡊࡔࡋࡊࡐࡖࡣ࡚ࡘࡌࠣာ") in env and len(env[bstack1l111l_opy_ (u"ࠦࡏࡋࡎࡌࡋࡑࡗࡤ࡛ࡒࡍࠤိ")]) > 0) or (
            bstack1l111l_opy_ (u"ࠧࡐࡅࡏࡍࡌࡒࡘࡥࡈࡐࡏࡈࠦီ") in env and len(env[bstack1l111l_opy_ (u"ࠨࡊࡆࡐࡎࡍࡓ࡙࡟ࡉࡑࡐࡉࠧု")]) > 0):
        return {
            bstack1l111l_opy_ (u"ࠢ࡯ࡣࡰࡩࠧူ"): bstack1l111l_opy_ (u"ࠣࡌࡨࡲࡰ࡯࡮ࡴࠤေ"),
            bstack1l111l_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧဲ"): env.get(bstack1l111l_opy_ (u"ࠥࡆ࡚ࡏࡌࡅࡡࡘࡖࡑࠨဳ")),
            bstack1l111l_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨဴ"): env.get(bstack1l111l_opy_ (u"ࠧࡐࡏࡃࡡࡑࡅࡒࡋࠢဵ")),
            bstack1l111l_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧံ"): env.get(bstack1l111l_opy_ (u"ࠢࡃࡗࡌࡐࡉࡥࡎࡖࡏࡅࡉࡗࠨ့"))
        }
    if env.get(bstack1l111l_opy_ (u"ࠣࡅࡌࠦး")) == bstack1l111l_opy_ (u"ࠤࡷࡶࡺ࡫္ࠢ") and env.get(bstack1l111l_opy_ (u"ࠥࡇࡎࡘࡃࡍࡇࡆࡍ်ࠧ")) == bstack1l111l_opy_ (u"ࠦࡹࡸࡵࡦࠤျ"):
        return {
            bstack1l111l_opy_ (u"ࠧࡴࡡ࡮ࡧࠥြ"): bstack1l111l_opy_ (u"ࠨࡃࡪࡴࡦࡰࡪࡉࡉࠣွ"),
            bstack1l111l_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥှ"): env.get(bstack1l111l_opy_ (u"ࠣࡅࡌࡖࡈࡒࡅࡠࡄࡘࡍࡑࡊ࡟ࡖࡔࡏࠦဿ")),
            bstack1l111l_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦ၀"): env.get(bstack1l111l_opy_ (u"ࠥࡇࡎࡘࡃࡍࡇࡢࡎࡔࡈࠢ၁")),
            bstack1l111l_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥ၂"): env.get(bstack1l111l_opy_ (u"ࠧࡉࡉࡓࡅࡏࡉࡤࡈࡕࡊࡎࡇࡣࡓ࡛ࡍࠣ၃"))
        }
    if env.get(bstack1l111l_opy_ (u"ࠨࡃࡊࠤ၄")) == bstack1l111l_opy_ (u"ࠢࡵࡴࡸࡩࠧ၅") and env.get(bstack1l111l_opy_ (u"ࠣࡖࡕࡅ࡛ࡏࡓࠣ၆")) == bstack1l111l_opy_ (u"ࠤࡷࡶࡺ࡫ࠢ၇"):
        return {
            bstack1l111l_opy_ (u"ࠥࡲࡦࡳࡥࠣ၈"): bstack1l111l_opy_ (u"࡙ࠦࡸࡡࡷ࡫ࡶࠤࡈࡏࠢ၉"),
            bstack1l111l_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣ၊"): env.get(bstack1l111l_opy_ (u"ࠨࡔࡓࡃ࡙ࡍࡘࡥࡂࡖࡋࡏࡈࡤ࡝ࡅࡃࡡࡘࡖࡑࠨ။")),
            bstack1l111l_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤ၌"): env.get(bstack1l111l_opy_ (u"ࠣࡖࡕࡅ࡛ࡏࡓࡠࡌࡒࡆࡤࡔࡁࡎࡇࠥ၍")),
            bstack1l111l_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣ၎"): env.get(bstack1l111l_opy_ (u"ࠥࡘࡗࡇࡖࡊࡕࡢࡆ࡚ࡏࡌࡅࡡࡑ࡙ࡒࡈࡅࡓࠤ၏"))
        }
    if env.get(bstack1l111l_opy_ (u"ࠦࡈࡏࠢၐ")) == bstack1l111l_opy_ (u"ࠧࡺࡲࡶࡧࠥၑ") and env.get(bstack1l111l_opy_ (u"ࠨࡃࡊࡡࡑࡅࡒࡋࠢၒ")) == bstack1l111l_opy_ (u"ࠢࡤࡱࡧࡩࡸ࡮ࡩࡱࠤၓ"):
        return {
            bstack1l111l_opy_ (u"ࠣࡰࡤࡱࡪࠨၔ"): bstack1l111l_opy_ (u"ࠤࡆࡳࡩ࡫ࡳࡩ࡫ࡳࠦၕ"),
            bstack1l111l_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨၖ"): None,
            bstack1l111l_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨၗ"): None,
            bstack1l111l_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦၘ"): None
        }
    if env.get(bstack1l111l_opy_ (u"ࠨࡂࡊࡖࡅ࡙ࡈࡑࡅࡕࡡࡅࡖࡆࡔࡃࡉࠤၙ")) and env.get(bstack1l111l_opy_ (u"ࠢࡃࡋࡗࡆ࡚ࡉࡋࡆࡖࡢࡇࡔࡓࡍࡊࡖࠥၚ")):
        return {
            bstack1l111l_opy_ (u"ࠣࡰࡤࡱࡪࠨၛ"): bstack1l111l_opy_ (u"ࠤࡅ࡭ࡹࡨࡵࡤ࡭ࡨࡸࠧၜ"),
            bstack1l111l_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨၝ"): env.get(bstack1l111l_opy_ (u"ࠦࡇࡏࡔࡃࡗࡆࡏࡊ࡚࡟ࡈࡋࡗࡣࡍ࡚ࡔࡑࡡࡒࡖࡎࡍࡉࡏࠤၞ")),
            bstack1l111l_opy_ (u"ࠧࡰ࡯ࡣࡡࡱࡥࡲ࡫ࠢၟ"): None,
            bstack1l111l_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧၠ"): env.get(bstack1l111l_opy_ (u"ࠢࡃࡋࡗࡆ࡚ࡉࡋࡆࡖࡢࡆ࡚ࡏࡌࡅࡡࡑ࡙ࡒࡈࡅࡓࠤၡ"))
        }
    if env.get(bstack1l111l_opy_ (u"ࠣࡅࡌࠦၢ")) == bstack1l111l_opy_ (u"ࠤࡷࡶࡺ࡫ࠢၣ") and env.get(bstack1l111l_opy_ (u"ࠥࡈࡗࡕࡎࡆࠤၤ")) == bstack1l111l_opy_ (u"ࠦࡹࡸࡵࡦࠤၥ"):
        return {
            bstack1l111l_opy_ (u"ࠧࡴࡡ࡮ࡧࠥၦ"): bstack1l111l_opy_ (u"ࠨࡄࡳࡱࡱࡩࠧၧ"),
            bstack1l111l_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥၨ"): env.get(bstack1l111l_opy_ (u"ࠣࡆࡕࡓࡓࡋ࡟ࡃࡗࡌࡐࡉࡥࡌࡊࡐࡎࠦၩ")),
            bstack1l111l_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦၪ"): None,
            bstack1l111l_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤၫ"): env.get(bstack1l111l_opy_ (u"ࠦࡉࡘࡏࡏࡇࡢࡆ࡚ࡏࡌࡅࡡࡑ࡙ࡒࡈࡅࡓࠤၬ"))
        }
    if env.get(bstack1l111l_opy_ (u"ࠧࡉࡉࠣၭ")) == bstack1l111l_opy_ (u"ࠨࡴࡳࡷࡨࠦၮ") and env.get(bstack1l111l_opy_ (u"ࠢࡔࡇࡐࡅࡕࡎࡏࡓࡇࠥၯ")) == bstack1l111l_opy_ (u"ࠣࡶࡵࡹࡪࠨၰ"):
        return {
            bstack1l111l_opy_ (u"ࠤࡱࡥࡲ࡫ࠢၱ"): bstack1l111l_opy_ (u"ࠥࡗࡪࡳࡡࡱࡪࡲࡶࡪࠨၲ"),
            bstack1l111l_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡹࡷࡲࠢၳ"): env.get(bstack1l111l_opy_ (u"࡙ࠧࡅࡎࡃࡓࡌࡔࡘࡅࡠࡑࡕࡋࡆࡔࡉ࡛ࡃࡗࡍࡔࡔ࡟ࡖࡔࡏࠦၴ")),
            bstack1l111l_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣၵ"): env.get(bstack1l111l_opy_ (u"ࠢࡔࡇࡐࡅࡕࡎࡏࡓࡇࡢࡎࡔࡈ࡟ࡏࡃࡐࡉࠧၶ")),
            bstack1l111l_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢၷ"): env.get(bstack1l111l_opy_ (u"ࠤࡖࡉࡒࡇࡐࡉࡑࡕࡉࡤࡐࡏࡃࡡࡌࡈࠧၸ"))
        }
    if env.get(bstack1l111l_opy_ (u"ࠥࡇࡎࠨၹ")) == bstack1l111l_opy_ (u"ࠦࡹࡸࡵࡦࠤၺ") and env.get(bstack1l111l_opy_ (u"ࠧࡍࡉࡕࡎࡄࡆࡤࡉࡉࠣၻ")) == bstack1l111l_opy_ (u"ࠨࡴࡳࡷࡨࠦၼ"):
        return {
            bstack1l111l_opy_ (u"ࠢ࡯ࡣࡰࡩࠧၽ"): bstack1l111l_opy_ (u"ࠣࡉ࡬ࡸࡑࡧࡢࠣၾ"),
            bstack1l111l_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧၿ"): env.get(bstack1l111l_opy_ (u"ࠥࡇࡎࡥࡊࡐࡄࡢ࡙ࡗࡒࠢႀ")),
            bstack1l111l_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨႁ"): env.get(bstack1l111l_opy_ (u"ࠧࡉࡉࡠࡌࡒࡆࡤࡔࡁࡎࡇࠥႂ")),
            bstack1l111l_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧႃ"): env.get(bstack1l111l_opy_ (u"ࠢࡄࡋࡢࡎࡔࡈ࡟ࡊࡆࠥႄ"))
        }
    if env.get(bstack1l111l_opy_ (u"ࠣࡅࡌࠦႅ")) == bstack1l111l_opy_ (u"ࠤࡷࡶࡺ࡫ࠢႆ") and env.get(bstack1l111l_opy_ (u"ࠥࡆ࡚ࡏࡌࡅࡍࡌࡘࡊࠨႇ")) == bstack1l111l_opy_ (u"ࠦࡹࡸࡵࡦࠤႈ"):
        return {
            bstack1l111l_opy_ (u"ࠧࡴࡡ࡮ࡧࠥႉ"): bstack1l111l_opy_ (u"ࠨࡂࡶ࡫࡯ࡨࡰ࡯ࡴࡦࠤႊ"),
            bstack1l111l_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥႋ"): env.get(bstack1l111l_opy_ (u"ࠣࡄࡘࡍࡑࡊࡋࡊࡖࡈࡣࡇ࡛ࡉࡍࡆࡢ࡙ࡗࡒࠢႌ")),
            bstack1l111l_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨႍࠦ"): env.get(bstack1l111l_opy_ (u"ࠥࡆ࡚ࡏࡌࡅࡍࡌࡘࡊࡥࡌࡂࡄࡈࡐࠧႎ")) or env.get(bstack1l111l_opy_ (u"ࠦࡇ࡛ࡉࡍࡆࡎࡍ࡙ࡋ࡟ࡑࡋࡓࡉࡑࡏࡎࡆࡡࡑࡅࡒࡋࠢႏ")),
            bstack1l111l_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦ႐"): env.get(bstack1l111l_opy_ (u"ࠨࡂࡖࡋࡏࡈࡐࡏࡔࡆࡡࡅ࡙ࡎࡒࡄࡠࡐࡘࡑࡇࡋࡒࠣ႑"))
        }
    if env.get(bstack1l111l_opy_ (u"ࠢࡕࡈࡢࡆ࡚ࡏࡌࡅࠤ႒")) == bstack1l111l_opy_ (u"ࠣࡖࡵࡹࡪࠨ႓"):
        return {
            bstack1l111l_opy_ (u"ࠤࡱࡥࡲ࡫ࠢ႔"): bstack1l111l_opy_ (u"࡚ࠥ࡮ࡹࡵࡢ࡮ࠣࡗࡹࡻࡤࡪࡱࠣࡘࡪࡧ࡭ࠡࡕࡨࡶࡻ࡯ࡣࡦࡵࠥ႕"),
            bstack1l111l_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡹࡷࡲࠢ႖"): bstack1l1l1lll1l_opy_ (u"ࠧࢁࡥ࡯ࡸ࠱࡫ࡪࡺࠨࠨࡕ࡜ࡗ࡙ࡋࡍࡠࡖࡈࡅࡒࡌࡏࡖࡐࡇࡅ࡙ࡏࡏࡏࡕࡈࡖ࡛ࡋࡒࡖࡔࡌࠫ࠮ࢃࡻࡦࡰࡹ࠲࡬࡫ࡴࠩࠩࡖ࡝ࡘ࡚ࡅࡎࡡࡗࡉࡆࡓࡐࡓࡑࡍࡉࡈ࡚ࡉࡅࠩࠬࢁࠧ႗"),
            bstack1l111l_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣ႘"): env.get(bstack1l111l_opy_ (u"ࠢࡔ࡛ࡖࡘࡊࡓ࡟ࡅࡇࡉࡍࡓࡏࡔࡊࡑࡑࡍࡉࠨ႙")),
            bstack1l111l_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢႚ"): env.get(bstack1l111l_opy_ (u"ࠤࡅ࡙ࡎࡒࡄࡠࡄࡘࡍࡑࡊࡉࡅࠤႛ"))
        }
    return {bstack1l111l_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤႜ"): None}
def get_host_info():
    uname = os.uname()
    return {
        bstack1l111l_opy_ (u"ࠦ࡭ࡵࡳࡵࡰࡤࡱࡪࠨႝ"): uname.nodename,
        bstack1l111l_opy_ (u"ࠧࡶ࡬ࡢࡶࡩࡳࡷࡳࠢ႞"): uname.sysname,
        bstack1l111l_opy_ (u"ࠨࡴࡺࡲࡨࠦ႟"): uname.machine,
        bstack1l111l_opy_ (u"ࠢࡷࡧࡵࡷ࡮ࡵ࡮ࠣႠ"): uname.version,
        bstack1l111l_opy_ (u"ࠣࡣࡵࡧ࡭ࠨႡ"): uname.machine
    }
def bstack1l11l1llll_opy_():
    try:
        import selenium
        return True
    except ImportError:
        return False
def bstack1l1lll111l_opy_():
    if bstack1l1ll1ll1_opy_.get_property(bstack1l111l_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬ࡡࡶࡩࡸࡹࡩࡰࡰࠪႢ")):
        return bstack1l111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠩႣ")
    return bstack1l111l_opy_ (u"ࠫࡺࡴ࡫࡯ࡱࡺࡲࡤ࡭ࡲࡪࡦࠪႤ")
def bstack1l1l1lllll_opy_(driver):
    info = {
        bstack1l111l_opy_ (u"ࠬࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡪࡧࡶࠫႥ"): driver.capabilities,
        bstack1l111l_opy_ (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴ࡟ࡪࡦࠪႦ"): driver.session_id,
        bstack1l111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࠨႧ"): driver.capabilities[bstack1l111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡐࡤࡱࡪ࠭Ⴈ")],
        bstack1l111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡢࡺࡪࡸࡳࡪࡱࡱࠫႩ"): driver.capabilities[bstack1l111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵ࡚ࡪࡸࡳࡪࡱࡱࠫႪ")],
        bstack1l111l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲ࠭Ⴋ"): driver.capabilities[bstack1l111l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡎࡢ࡯ࡨࠫႬ")],
    }
    if bstack1l1lll111l_opy_() == bstack1l111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠬႭ"):
        info[bstack1l111l_opy_ (u"ࠧࡱࡴࡲࡨࡺࡩࡴࠨႮ")] = bstack1l111l_opy_ (u"ࠨࡣࡳࡴ࠲ࡧࡵࡵࡱࡰࡥࡹ࡫ࠧႯ") if bstack1l1ll1ll1_opy_.get_property(bstack1l111l_opy_ (u"ࠩࡤࡴࡵࡥࡡࡶࡶࡲࡱࡦࡺࡥࠨႰ")) else bstack1l111l_opy_ (u"ࠪࡥࡺࡺ࡯࡮ࡣࡷࡩࠬႱ")
    return info
def bstack1ll1l111ll_opy_(bstack1l1l11111l_opy_, url, data, config):
    headers = config.get(bstack1l111l_opy_ (u"ࠫ࡭࡫ࡡࡥࡧࡵࡷࠬႲ"), None)
    proxies = bstack11l1l111_opy_(config, url)
    auth = config.get(bstack1l111l_opy_ (u"ࠬࡧࡵࡵࡪࠪႳ"), None)
    response = requests.request(
            bstack1l1l11111l_opy_,
            url=url,
            headers=headers,
            auth=auth,
            json=data,
            proxies=proxies
        )
    return response
def bstack1lll1111_opy_(bstack1l1111lll_opy_, size):
    bstack1ll11lllll_opy_ = []
    while len(bstack1l1111lll_opy_) > size:
        bstack111l11lll_opy_ = bstack1l1111lll_opy_[:size]
        bstack1ll11lllll_opy_.append(bstack111l11lll_opy_)
        bstack1l1111lll_opy_ = bstack1l1111lll_opy_[size:]
    bstack1ll11lllll_opy_.append(bstack1l1111lll_opy_)
    return bstack1ll11lllll_opy_
def bstack1l1l1ll1l1_opy_(message):
    os.write(1, bytes(message, bstack1l111l_opy_ (u"࠭ࡵࡵࡨ࠰࠼ࠬႴ")))
    os.write(1, bytes(bstack1l111l_opy_ (u"ࠧ࡝ࡰࠪႵ"), bstack1l111l_opy_ (u"ࠨࡷࡷࡪ࠲࠾ࠧႶ")))
def bstack1l11ll11ll_opy_():
    return os.environ[bstack1l111l_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡃࡘࡘࡔࡓࡁࡕࡋࡒࡒࠬႷ")].lower() == bstack1l111l_opy_ (u"ࠪࡸࡷࡻࡥࠨႸ")
def bstack1llll1ll1_opy_(bstack1l1l1ll1ll_opy_):
    return bstack1l111l_opy_ (u"ࠫࢀࢃ࠯ࡼࡿࠪႹ").format(bstack1ll111l1l1_opy_, bstack1l1l1ll1ll_opy_)
def bstack1l1lll1l_opy_():
    return datetime.datetime.utcnow().isoformat() + bstack1l111l_opy_ (u"ࠬࡠࠧႺ")
def bstack1l11llll1l_opy_(outcome):
    _, exception, _ = outcome.excinfo or (None, None, None)
    if exception:
        return bstack1l111l_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭Ⴛ")
    else:
        return bstack1l111l_opy_ (u"ࠧࡱࡣࡶࡷࡪࡪࠧႼ")
def bstack1l1ll1l111_opy_(val):
    return val.__str__().lower() == bstack1l111l_opy_ (u"ࠨࡶࡵࡹࡪ࠭Ⴝ")
def bstack1l11ll1l1l_opy_(val):
    return val.__str__().lower() == bstack1l111l_opy_ (u"ࠩࡩࡥࡱࡹࡥࠨႾ")
def bstack1l1ll11111_opy_(bstack1l11llllll_opy_=Exception, bstack1l1l1l1ll1_opy_=False, default_value=None):
    def decorator(func):
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except bstack1l11llllll_opy_ as e:
                print(bstack1l111l_opy_ (u"ࠥࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࢀࢃࠠ࠮ࡀࠣࡿࢂࡀࠠࡼࡿࠥႿ").format(func.__name__, bstack1l11llllll_opy_.__name__, str(e)))
                return default_value
        return wrapper
    def bstack1l11ll11l1_opy_(bstack1l11lll1ll_opy_):
        def wrapped(cls, *args, **kwargs):
            try:
                return bstack1l11lll1ll_opy_(cls, *args, **kwargs)
            except bstack1l11llllll_opy_ as e:
                print(bstack1l111l_opy_ (u"ࠦࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡪࡺࡴࡣࡵ࡫ࡲࡲࠥࢁࡽࠡ࠯ࡁࠤࢀࢃ࠺ࠡࡽࢀࠦჀ").format(bstack1l11lll1ll_opy_.__name__, bstack1l11llllll_opy_.__name__, str(e)))
                return default_value
        return wrapped
    if bstack1l1l1l1ll1_opy_:
        return bstack1l11ll11l1_opy_
    else:
        return decorator
def bstack11llll111_opy_(bstack1ll1l1ll_opy_):
    if bstack1l111l_opy_ (u"ࠬࡧࡵࡵࡱࡰࡥࡹ࡯࡯࡯ࠩჁ") in bstack1ll1l1ll_opy_ and bstack1l11ll1l1l_opy_(bstack1ll1l1ll_opy_[bstack1l111l_opy_ (u"࠭ࡡࡶࡶࡲࡱࡦࡺࡩࡰࡰࠪჂ")]):
        return False
    if bstack1l111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡇࡵࡵࡱࡰࡥࡹ࡯࡯࡯ࠩჃ") in bstack1ll1l1ll_opy_ and bstack1l11ll1l1l_opy_(bstack1ll1l1ll_opy_[bstack1l111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡁࡶࡶࡲࡱࡦࡺࡩࡰࡰࠪჄ")]):
        return False
    return True
def bstack1l11llll11_opy_():
    try:
        from pytest_bdd import reporting
        return True
    except Exception as e:
        return False
def bstack111111ll_opy_(hub_url):
    if bstack111lllll1_opy_() <= version.parse(bstack1l111l_opy_ (u"ࠩ࠶࠲࠶࠹࠮࠱ࠩჅ")):
        if hub_url != bstack1l111l_opy_ (u"ࠪࠫ჆"):
            return bstack1l111l_opy_ (u"ࠦ࡭ࡺࡴࡱ࠼࠲࠳ࠧჇ") + hub_url + bstack1l111l_opy_ (u"ࠧࡀ࠸࠱࠱ࡺࡨ࠴࡮ࡵࡣࠤ჈")
        return bstack1ll11llll1_opy_
    if hub_url != bstack1l111l_opy_ (u"࠭ࠧ჉"):
        return bstack1l111l_opy_ (u"ࠢࡩࡶࡷࡴࡸࡀ࠯࠰ࠤ჊") + hub_url + bstack1l111l_opy_ (u"ࠣ࠱ࡺࡨ࠴࡮ࡵࡣࠤ჋")
    return bstack1lll1l1ll_opy_
def bstack1l11ll1ll1_opy_():
    return isinstance(os.getenv(bstack1l111l_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡒ࡜ࡘࡊ࡙ࡔࡠࡒࡏ࡙ࡌࡏࡎࠨ჌")), str)
def bstack11ll1l1ll_opy_(url):
    return urlparse(url).hostname
def bstack1l1llll11_opy_(hostname):
    for bstack1llll11111_opy_ in bstack111ll1ll_opy_:
        regex = re.compile(bstack1llll11111_opy_)
        if regex.match(hostname):
            return True
    return False
def bstack1ll11l1ll1_opy_(directory_name, file_name, logger):
    bstack1l1l1l1l_opy_ = os.path.join(os.path.expanduser(bstack1l111l_opy_ (u"ࠪࢂࠬჍ")), directory_name)
    try:
        if not os.path.exists(bstack1l1l1l1l_opy_):
            os.makedirs(bstack1l1l1l1l_opy_)
        file_path = os.path.join(os.path.expanduser(bstack1l111l_opy_ (u"ࠫࢃ࠭჎")), directory_name, file_name)
        if not os.path.isfile(file_path):
            with open(file_path, bstack1l111l_opy_ (u"ࠬࡽࠧ჏")):
                pass
            with open(file_path, bstack1l111l_opy_ (u"ࠨࡷࠬࠤა")) as outfile:
                json.dump({}, outfile)
        return file_path
    except Exception as e:
        logger.debug(bstack1lll111ll_opy_.format(str(e)))
def bstack1ll11l1l11_opy_(file_name, key, value, logger):
    file_path = bstack1ll11l1ll1_opy_(bstack1l111l_opy_ (u"ࠧ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧბ"), file_name, logger)
    if file_path != None:
        if os.path.exists(file_path):
            bstack111l11l1l_opy_ = json.load(open(file_path, bstack1l111l_opy_ (u"ࠨࡴࡥࠫგ")))
        else:
            bstack111l11l1l_opy_ = {}
        bstack111l11l1l_opy_[key] = value
        with open(file_path, bstack1l111l_opy_ (u"ࠤࡺ࠯ࠧდ")) as outfile:
            json.dump(bstack111l11l1l_opy_, outfile)
def bstack11lll11l_opy_(file_name, logger):
    file_path = bstack1ll11l1ll1_opy_(bstack1l111l_opy_ (u"ࠪ࠲ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࠪე"), file_name, logger)
    bstack111l11l1l_opy_ = {}
    if file_path != None and os.path.exists(file_path):
        with open(file_path, bstack1l111l_opy_ (u"ࠫࡷ࠭ვ")) as bstack1llll111l_opy_:
            bstack111l11l1l_opy_ = json.load(bstack1llll111l_opy_)
    return bstack111l11l1l_opy_
def bstack1ll11lll1l_opy_(file_path, logger):
    try:
        if os.path.exists(file_path):
            os.remove(file_path)
    except Exception as e:
        logger.debug(bstack1l111l_opy_ (u"ࠬࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡥࡧ࡯ࡩࡹ࡯࡮ࡨࠢࡩ࡭ࡱ࡫࠺ࠡࠩზ") + file_path + bstack1l111l_opy_ (u"࠭ࠠࠨთ") + str(e))
def bstack111lllll1_opy_():
    from selenium import webdriver
    return version.parse(webdriver.__version__)
class Notset:
    def __repr__(self):
        return bstack1l111l_opy_ (u"ࠢ࠽ࡐࡒࡘࡘࡋࡔ࠿ࠤი")
def bstack111111l11_opy_(config):
    if bstack1l111l_opy_ (u"ࠨ࡫ࡶࡔࡱࡧࡹࡸࡴ࡬࡫࡭ࡺࠧკ") in config:
        del (config[bstack1l111l_opy_ (u"ࠩ࡬ࡷࡕࡲࡡࡺࡹࡵ࡭࡬࡮ࡴࠨლ")])
        return False
    if bstack111lllll1_opy_() < version.parse(bstack1l111l_opy_ (u"ࠪ࠷࠳࠺࠮࠱ࠩმ")):
        return False
    if bstack111lllll1_opy_() >= version.parse(bstack1l111l_opy_ (u"ࠫ࠹࠴࠱࠯࠷ࠪნ")):
        return True
    if bstack1l111l_opy_ (u"ࠬࡻࡳࡦ࡙࠶ࡇࠬო") in config and config[bstack1l111l_opy_ (u"࠭ࡵࡴࡧ࡚࠷ࡈ࠭პ")] is False:
        return False
    else:
        return True
def bstack1l1l1llll_opy_(args_list, bstack1l1l111111_opy_):
    index = -1
    for value in bstack1l1l111111_opy_:
        try:
            index = args_list.index(value)
            return index
        except Exception as e:
            return index
    return index