# coding: UTF-8
import sys
bstack1l1llll_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack11l1lll_opy_ = 7
def bstack1l111l_opy_ (bstack1ll1l1l_opy_):
    global bstack1lllll1l_opy_
    bstack1lll_opy_ = ord (bstack1ll1l1l_opy_ [-1])
    bstack11l1111_opy_ = bstack1ll1l1l_opy_ [:-1]
    bstack111111_opy_ = bstack1lll_opy_ % len (bstack11l1111_opy_)
    bstack1llllll_opy_ = bstack11l1111_opy_ [:bstack111111_opy_] + bstack11l1111_opy_ [bstack111111_opy_:]
    if bstack1l1llll_opy_:
        bstack1l1l1_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack11111l1_opy_ + bstack1lll_opy_) % bstack11l1lll_opy_) for bstack11111l1_opy_, char in enumerate (bstack1llllll_opy_)])
    else:
        bstack1l1l1_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack11111l1_opy_ + bstack1lll_opy_) % bstack11l1lll_opy_) for bstack11111l1_opy_, char in enumerate (bstack1llllll_opy_)])
    return eval (bstack1l1l1_opy_)
import sys
class bstack1l1l11lll1_opy_:
    def __init__(self, handler):
        self._1l1l11ll11_opy_ = sys.stdout.write
        self._1l1l11llll_opy_ = sys.stderr.write
        self.handler = handler
        self._started = False
    def start(self):
        if self._started:
            return
        self._started = True
        sys.stdout.write = self.bstack1l1l11ll1l_opy_
        sys.stdout.error = self.bstack1l1l1l1111_opy_
    def bstack1l1l11ll1l_opy_(self, _str):
        self._1l1l11ll11_opy_(_str)
        if self.handler:
            self.handler({bstack1l111l_opy_ (u"࠭࡬ࡦࡸࡨࡰࠬစ"): bstack1l111l_opy_ (u"ࠧࡊࡐࡉࡓࠬဆ"), bstack1l111l_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩဇ"): _str})
    def bstack1l1l1l1111_opy_(self, _str):
        self._1l1l11llll_opy_(_str)
        if self.handler:
            self.handler({bstack1l111l_opy_ (u"ࠩ࡯ࡩࡻ࡫࡬ࠨဈ"): bstack1l111l_opy_ (u"ࠪࡉࡗࡘࡏࡓࠩဉ"), bstack1l111l_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬည"): _str})
    def reset(self):
        if not self._started:
            return
        self._started = False
        sys.stdout.write = self._1l1l11ll11_opy_
        sys.stderr.write = self._1l1l11llll_opy_