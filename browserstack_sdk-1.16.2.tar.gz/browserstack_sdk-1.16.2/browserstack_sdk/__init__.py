# coding: UTF-8
import sys
bstack1l1llll_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack11l1lll_opy_ = 7
def bstack1l111l_opy_ (bstack1ll1l1l_opy_):
    global bstack1lllll1l_opy_
    bstack1lll_opy_ = ord (bstack1ll1l1l_opy_ [-1])
    bstack11l1111_opy_ = bstack1ll1l1l_opy_ [:-1]
    bstack111111_opy_ = bstack1lll_opy_ % len (bstack11l1111_opy_)
    bstack1llllll_opy_ = bstack11l1111_opy_ [:bstack111111_opy_] + bstack11l1111_opy_ [bstack111111_opy_:]
    if bstack1l1llll_opy_:
        bstack1l1l1_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack11111l1_opy_ + bstack1lll_opy_) % bstack11l1lll_opy_) for bstack11111l1_opy_, char in enumerate (bstack1llllll_opy_)])
    else:
        bstack1l1l1_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack11111l1_opy_ + bstack1lll_opy_) % bstack11l1lll_opy_) for bstack11111l1_opy_, char in enumerate (bstack1llllll_opy_)])
    return eval (bstack1l1l1_opy_)
import atexit
import os
import signal
import sys
import yaml
import requests
import logging
import threading
import socket
import datetime
import string
import random
import json
import collections.abc
import re
import multiprocessing
import traceback
import copy
from packaging import version
from browserstack.local import Local
from urllib.parse import urlparse
from bstack_utils.constants import *
import time
import requests
import time
def bstack1l1ll1l1_opy_():
  global CONFIG
  headers = {
        bstack1l111l_opy_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡸࡾࡶࡥࠨࢊ"): bstack1l111l_opy_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰࡬ࡶࡳࡳ࠭ࢋ"),
      }
  proxies = bstack11l1l111_opy_(CONFIG, bstack11ll1l1l1_opy_)
  try:
    response = requests.get(bstack11ll1l1l1_opy_, headers=headers, proxies=proxies, timeout=5)
    if response.json():
      bstack1ll1ll111_opy_ = response.json()[bstack1l111l_opy_ (u"ࠫ࡭ࡻࡢࡴࠩࢌ")]
      logger.debug(bstack1l1l111l_opy_.format(response.json()))
      return bstack1ll1ll111_opy_
    else:
      logger.debug(bstack11l111l1_opy_.format(bstack1l111l_opy_ (u"ࠧࡘࡥࡴࡲࡲࡲࡸ࡫ࠠࡋࡕࡒࡒࠥࡶࡡࡳࡵࡨࠤࡪࡸࡲࡰࡴࠣࠦࢍ")))
  except Exception as e:
    logger.debug(bstack11l111l1_opy_.format(e))
def bstack1lll11111l_opy_(hub_url):
  global CONFIG
  url = bstack1l111l_opy_ (u"ࠨࡨࡵࡶࡳࡷ࠿࠵࠯ࠣࢎ")+  hub_url + bstack1l111l_opy_ (u"ࠢ࠰ࡥ࡫ࡩࡨࡱࠢ࢏")
  headers = {
        bstack1l111l_opy_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡷࡽࡵ࡫ࠧ࢐"): bstack1l111l_opy_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬ࢑"),
      }
  proxies = bstack11l1l111_opy_(CONFIG, url)
  try:
    start_time = time.perf_counter()
    requests.get(url, headers=headers, proxies=proxies, timeout=5)
    latency = time.perf_counter() - start_time
    logger.debug(bstack1l11llll1_opy_.format(hub_url, latency))
    return dict(hub_url=hub_url, latency=latency)
  except Exception as e:
    logger.debug(bstack11lll1ll_opy_.format(hub_url, e))
def bstack111l1111_opy_():
  try:
    global bstack1ll11lll1_opy_
    bstack1ll1ll111_opy_ = bstack1l1ll1l1_opy_()
    bstack1111lll1l_opy_ = []
    results = []
    for bstack1ll1l11l1_opy_ in bstack1ll1ll111_opy_:
      bstack1111lll1l_opy_.append(bstack1l11l1lll_opy_(target=bstack1lll11111l_opy_,args=(bstack1ll1l11l1_opy_,)))
    for t in bstack1111lll1l_opy_:
      t.start()
    for t in bstack1111lll1l_opy_:
      results.append(t.join())
    bstack111l1111l_opy_ = {}
    for item in results:
      hub_url = item[bstack1l111l_opy_ (u"ࠪ࡬ࡺࡨ࡟ࡶࡴ࡯ࠫ࢒")]
      latency = item[bstack1l111l_opy_ (u"ࠫࡱࡧࡴࡦࡰࡦࡽࠬ࢓")]
      bstack111l1111l_opy_[hub_url] = latency
    bstack1l1llllll_opy_ = min(bstack111l1111l_opy_, key= lambda x: bstack111l1111l_opy_[x])
    bstack1ll11lll1_opy_ = bstack1l1llllll_opy_
    logger.debug(bstack1lll11l1l_opy_.format(bstack1l1llllll_opy_))
  except Exception as e:
    logger.debug(bstack1l11lll11_opy_.format(e))
from bstack_utils.messages import *
from bstack_utils.config import Config
from bstack_utils.helper import bstack1ll1l111ll_opy_, bstack1llll1ll1_opy_, bstack11llll111_opy_, Notset, bstack111111l11_opy_, \
  bstack11lll11l_opy_, bstack1ll11lll1l_opy_, bstack1l1l1llll_opy_
from bstack_utils.bstack111lll11_opy_ import bstack1lllll111_opy_
from bstack_utils.proxy import bstack11ll1111_opy_, bstack11l1l111_opy_, bstack1111ll11_opy_, bstack1111ll11l_opy_
from browserstack_sdk.bstack1llll111_opy_ import *
from browserstack_sdk.bstack1ll1ll1l_opy_ import *
bstack11l1111ll_opy_ = bstack1l111l_opy_ (u"ࠬࠦࠠ࠰ࠬࠣࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃࠠࠫ࠱࡟ࡲࠥࠦࡩࡧࠪࡳࡥ࡬࡫ࠠ࠾࠿ࡀࠤࡻࡵࡩࡥࠢ࠳࠭ࠥࢁ࡜࡯ࠢࠣࠤࡹࡸࡹࡼ࡞ࡱࠤࡨࡵ࡮ࡴࡶࠣࡪࡸࠦ࠽ࠡࡴࡨࡵࡺ࡯ࡲࡦࠪ࡟ࠫ࡫ࡹ࡜ࠨࠫ࠾ࡠࡳࠦࠠࠡࠢࠣࡪࡸ࠴ࡡࡱࡲࡨࡲࡩࡌࡩ࡭ࡧࡖࡽࡳࡩࠨࡣࡵࡷࡥࡨࡱ࡟ࡱࡣࡷ࡬࠱ࠦࡊࡔࡑࡑ࠲ࡸࡺࡲࡪࡰࡪ࡭࡫ࡿࠨࡱࡡ࡬ࡲࡩ࡫ࡸࠪࠢ࠮ࠤࠧࡀࠢࠡ࠭ࠣࡎࡘࡕࡎ࠯ࡵࡷࡶ࡮ࡴࡧࡪࡨࡼࠬࡏ࡙ࡏࡏ࠰ࡳࡥࡷࡹࡥࠩࠪࡤࡻࡦ࡯ࡴࠡࡰࡨࡻࡕࡧࡧࡦ࠴࠱ࡩࡻࡧ࡬ࡶࡣࡷࡩ࠭ࠨࠨࠪࠢࡀࡂࠥࢁࡽࠣ࠮ࠣࡠࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧ࡭ࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡆࡨࡸࡦ࡯࡬ࡴࠤࢀࡠࠬ࠯ࠩࠪ࡝ࠥ࡬ࡦࡹࡨࡦࡦࡢ࡭ࡩࠨ࡝ࠪࠢ࠮ࠤࠧ࠲࡜࡝ࡰࠥ࠭ࡡࡴࠠࠡࠢࠣࢁࡨࡧࡴࡤࡪࠫࡩࡽ࠯ࡻ࡝ࡰࠣࠤࠥࠦࡽ࡝ࡰࠣࠤࢂࡢ࡮ࠡࠢ࠲࠮ࠥࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠢ࠭࠳ࠬ࢔")
bstack1lll1lllll_opy_ = bstack1l111l_opy_ (u"࠭࡜࡯࠱࠭ࠤࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽ࠡࠬ࠲ࡠࡳࡩ࡯࡯ࡵࡷࠤࡧࡹࡴࡢࡥ࡮ࡣࡵࡧࡴࡩࠢࡀࠤࡵࡸ࡯ࡤࡧࡶࡷ࠳ࡧࡲࡨࡸ࡞ࡴࡷࡵࡣࡦࡵࡶ࠲ࡦࡸࡧࡷ࠰࡯ࡩࡳ࡭ࡴࡩࠢ࠰ࠤ࠸ࡣ࡜࡯ࡥࡲࡲࡸࡺࠠࡣࡵࡷࡥࡨࡱ࡟ࡤࡣࡳࡷࠥࡃࠠࡱࡴࡲࡧࡪࡹࡳ࠯ࡣࡵ࡫ࡻࡡࡰࡳࡱࡦࡩࡸࡹ࠮ࡢࡴࡪࡺ࠳ࡲࡥ࡯ࡩࡷ࡬ࠥ࠳ࠠ࠲࡟࡟ࡲࡨࡵ࡮ࡴࡶࠣࡴࡤ࡯࡮ࡥࡧࡻࠤࡂࠦࡰࡳࡱࡦࡩࡸࡹ࠮ࡢࡴࡪࡺࡠࡶࡲࡰࡥࡨࡷࡸ࠴ࡡࡳࡩࡹ࠲ࡱ࡫࡮ࡨࡶ࡫ࠤ࠲ࠦ࠲࡞࡞ࡱࡴࡷࡵࡣࡦࡵࡶ࠲ࡦࡸࡧࡷࠢࡀࠤࡵࡸ࡯ࡤࡧࡶࡷ࠳ࡧࡲࡨࡸ࠱ࡷࡱ࡯ࡣࡦࠪ࠳࠰ࠥࡶࡲࡰࡥࡨࡷࡸ࠴ࡡࡳࡩࡹ࠲ࡱ࡫࡮ࡨࡶ࡫ࠤ࠲ࠦ࠳ࠪ࡞ࡱࡧࡴࡴࡳࡵࠢ࡬ࡱࡵࡵࡲࡵࡡࡳࡰࡦࡿࡷࡳ࡫ࡪ࡬ࡹ࠺࡟ࡣࡵࡷࡥࡨࡱࠠ࠾ࠢࡵࡩࡶࡻࡩࡳࡧࠫࠦࡵࡲࡡࡺࡹࡵ࡭࡬࡮ࡴࠣࠫ࠾ࡠࡳ࡯࡭ࡱࡱࡵࡸࡤࡶ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵ࠶ࡢࡦࡸࡺࡡࡤ࡭࠱ࡧ࡭ࡸ࡯࡮࡫ࡸࡱ࠳ࡲࡡࡶࡰࡦ࡬ࠥࡃࠠࡢࡵࡼࡲࡨࠦࠨ࡭ࡣࡸࡲࡨ࡮ࡏࡱࡶ࡬ࡳࡳࡹࠩࠡ࠿ࡁࠤࢀࡢ࡮࡭ࡧࡷࠤࡨࡧࡰࡴ࠽࡟ࡲࡹࡸࡹࠡࡽ࡟ࡲࡨࡧࡰࡴࠢࡀࠤࡏ࡙ࡏࡏ࠰ࡳࡥࡷࡹࡥࠩࡤࡶࡸࡦࡩ࡫ࡠࡥࡤࡴࡸ࠯࡜࡯ࠢࠣࢁࠥࡩࡡࡵࡥ࡫ࠬࡪࡾࠩࠡࡽ࡟ࡲࠥࠦࠠࠡࡿ࡟ࡲࠥࠦࡲࡦࡶࡸࡶࡳࠦࡡࡸࡣ࡬ࡸࠥ࡯࡭ࡱࡱࡵࡸࡤࡶ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵ࠶ࡢࡦࡸࡺࡡࡤ࡭࠱ࡧ࡭ࡸ࡯࡮࡫ࡸࡱ࠳ࡩ࡯࡯ࡰࡨࡧࡹ࠮ࡻ࡝ࡰࠣࠤࠥࠦࡷࡴࡇࡱࡨࡵࡵࡩ࡯ࡶ࠽ࠤࡥࡽࡳࡴ࠼࠲࠳ࡨࡪࡰ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡤࡱࡰ࠳ࡵࡲࡡࡺࡹࡵ࡭࡬࡮ࡴࡀࡥࡤࡴࡸࡃࠤࡼࡧࡱࡧࡴࡪࡥࡖࡔࡌࡇࡴࡳࡰࡰࡰࡨࡲࡹ࠮ࡊࡔࡑࡑ࠲ࡸࡺࡲࡪࡰࡪ࡭࡫ࡿࠨࡤࡣࡳࡷ࠮࠯ࡽࡡ࠮࡟ࡲࠥࠦࠠࠡ࠰࠱࠲ࡱࡧࡵ࡯ࡥ࡫ࡓࡵࡺࡩࡰࡰࡶࡠࡳࠦࠠࡾࠫ࡟ࡲࢂࡢ࡮࠰ࠬࠣࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃࠠࠫ࠱࡟ࡲࠬ࢕")
from ._version import __version__
bstack1l11lllll_opy_ = None
CONFIG = {}
bstack1lll11l1l1_opy_ = {}
bstack111l1ll1_opy_ = {}
bstack111ll11l1_opy_ = None
bstack1lll1ll1l1_opy_ = None
bstack11ll1l111_opy_ = None
bstack11l1111l_opy_ = -1
bstack1111l1111_opy_ = bstack11ll11l11_opy_
bstack1l1lll11_opy_ = 1
bstack1lll1l111_opy_ = False
bstack1l1l11111_opy_ = False
bstack111111ll1_opy_ = bstack1l111l_opy_ (u"ࠧࠨ࢖")
bstack1ll1ll1ll1_opy_ = bstack1l111l_opy_ (u"ࠨࠩࢗ")
bstack1ll111l11_opy_ = False
bstack1111l11l1_opy_ = True
bstack1l1l1l11l_opy_ = bstack1l111l_opy_ (u"ࠩࠪ࢘")
bstack1llllllll1_opy_ = []
bstack1ll11lll1_opy_ = bstack1l111l_opy_ (u"࢙ࠪࠫ")
bstack111l11l1_opy_ = False
bstack1l11l1ll1_opy_ = None
bstack111l1l11_opy_ = None
bstack111l1l1l_opy_ = -1
bstack1ll1ll1ll_opy_ = os.path.join(os.path.expanduser(bstack1l111l_opy_ (u"ࠫࢃ࢚࠭")), bstack1l111l_opy_ (u"ࠬ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࢛ࠬ"), bstack1l111l_opy_ (u"࠭࠮ࡳࡱࡥࡳࡹ࠳ࡲࡦࡲࡲࡶࡹ࠳ࡨࡦ࡮ࡳࡩࡷ࠴ࡪࡴࡱࡱࠫ࢜"))
bstack1l1l1lll1_opy_ = []
bstack1l11111l_opy_ = []
bstack11l1l1l1l_opy_ = False
bstack1l11lll1l_opy_ = False
bstack11lll1l1_opy_ = None
bstack1lllllll1l_opy_ = None
bstack1ll1l1l1l_opy_ = None
bstack1l1l11lll_opy_ = None
bstack1l1l11l1l_opy_ = None
bstack11l111111_opy_ = None
bstack11lll1lll_opy_ = None
bstack1l1ll11l_opy_ = None
bstack1ll1lllll1_opy_ = None
bstack111ll1l1l_opy_ = None
bstack1lllll1111_opy_ = None
bstack11l1l1l1_opy_ = None
bstack11ll11111_opy_ = None
bstack1l11111ll_opy_ = None
bstack1l111l11_opy_ = None
bstack1lllll1ll_opy_ = None
bstack111lll1l_opy_ = None
bstack111ll1ll1_opy_ = None
bstack11l1l111l_opy_ = bstack1l111l_opy_ (u"ࠢࠣ࢝")
logger = logging.getLogger(__name__)
logging.basicConfig(level=bstack1111l1111_opy_,
                    format=bstack1l111l_opy_ (u"ࠨ࡞ࡱࠩ࠭ࡧࡳࡤࡶ࡬ࡱࡪ࠯ࡳࠡ࡝ࠨࠬࡳࡧ࡭ࡦࠫࡶࡡࡠࠫࠨ࡭ࡧࡹࡩࡱࡴࡡ࡮ࡧࠬࡷࡢࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭࢞"),
                    datefmt=bstack1l111l_opy_ (u"ࠩࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠫ࢟"),
                    stream=sys.stdout)
bstack1l1ll1ll1_opy_ = Config.get_instance()
def bstack111l1l111_opy_():
  global CONFIG
  global bstack1111l1111_opy_
  if bstack1l111l_opy_ (u"ࠪࡰࡴ࡭ࡌࡦࡸࡨࡰࠬࢠ") in CONFIG:
    bstack1111l1111_opy_ = bstack1lllll1l1l_opy_[CONFIG[bstack1l111l_opy_ (u"ࠫࡱࡵࡧࡍࡧࡹࡩࡱ࠭ࢡ")]]
    logging.getLogger().setLevel(bstack1111l1111_opy_)
def bstack1ll11111_opy_():
  global CONFIG
  global bstack11l1l1l1l_opy_
  bstack1l11ll1ll_opy_ = bstack1ll11l1ll_opy_(CONFIG)
  if (bstack1l111l_opy_ (u"ࠬࡹ࡫ࡪࡲࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠧࢢ") in bstack1l11ll1ll_opy_ and str(bstack1l11ll1ll_opy_[bstack1l111l_opy_ (u"࠭ࡳ࡬࡫ࡳࡗࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠨࢣ")]).lower() == bstack1l111l_opy_ (u"ࠧࡵࡴࡸࡩࠬࢤ")):
    bstack11l1l1l1l_opy_ = True
def bstack1l11111l1_opy_():
  from appium.version import version as appium_version
  return version.parse(appium_version)
def bstack111lllll1_opy_():
  from selenium import webdriver
  return version.parse(webdriver.__version__)
def bstack11l1ll1l1_opy_():
  args = sys.argv
  for i in range(len(args)):
    if bstack1l111l_opy_ (u"ࠣ࠯࠰ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡥࡲࡲ࡫࡯ࡧࡧ࡫࡯ࡩࠧࢥ") == args[i].lower() or bstack1l111l_opy_ (u"ࠤ࠰࠱ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡧࡴࡴࡦࡪࡩࠥࢦ") == args[i].lower():
      path = args[i + 1]
      sys.argv.remove(args[i])
      sys.argv.remove(path)
      global bstack1l1l1l11l_opy_
      bstack1l1l1l11l_opy_ += bstack1l111l_opy_ (u"ࠪ࠱࠲ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡇࡴࡴࡦࡪࡩࡉ࡭ࡱ࡫ࠠࠨࢧ") + path
      return path
  return None
bstack1l1111l1l_opy_ = re.compile(bstack1l111l_opy_ (u"ࡶࠧ࠴ࠪࡀ࡞ࠧࡿ࠭࠴ࠪࡀࠫࢀ࠲࠯ࡅࠢࢨ"))
def bstack111l1llll_opy_(loader, node):
  value = loader.construct_scalar(node)
  for group in bstack1l1111l1l_opy_.findall(value):
    if group is not None and os.environ.get(group) is not None:
      value = value.replace(bstack1l111l_opy_ (u"ࠧࠪࡻࠣࢩ") + group + bstack1l111l_opy_ (u"ࠨࡽࠣࢪ"), os.environ.get(group))
  return value
def bstack1lll1l11l_opy_():
  bstack1llllll1ll_opy_ = bstack11l1ll1l1_opy_()
  if bstack1llllll1ll_opy_ and os.path.exists(os.path.abspath(bstack1llllll1ll_opy_)):
    fileName = bstack1llllll1ll_opy_
  if bstack1l111l_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡃࡐࡐࡉࡍࡌࡥࡆࡊࡎࡈࠫࢫ") in os.environ and os.path.exists(
          os.path.abspath(os.environ[bstack1l111l_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡄࡑࡑࡊࡎࡍ࡟ࡇࡋࡏࡉࠬࢬ")])) and not bstack1l111l_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡎࡢ࡯ࡨࠫࢭ") in locals():
    fileName = os.environ[bstack1l111l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡆࡓࡓࡌࡉࡈࡡࡉࡍࡑࡋࠧࢮ")]
  if bstack1l111l_opy_ (u"ࠫ࡫࡯࡬ࡦࡐࡤࡱࡪ࠭ࢯ") in locals():
    bstack111_opy_ = os.path.abspath(fileName)
  else:
    bstack111_opy_ = bstack1l111l_opy_ (u"ࠬ࠭ࢰ")
  bstack1111llll_opy_ = os.getcwd()
  bstack1111l111l_opy_ = bstack1l111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡿ࡭࡭ࠩࢱ")
  bstack11l1l1ll_opy_ = bstack1l111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡹࡢ࡯࡯ࠫࢲ")
  while (not os.path.exists(bstack111_opy_)) and bstack1111llll_opy_ != bstack1l111l_opy_ (u"ࠣࠤࢳ"):
    bstack111_opy_ = os.path.join(bstack1111llll_opy_, bstack1111l111l_opy_)
    if not os.path.exists(bstack111_opy_):
      bstack111_opy_ = os.path.join(bstack1111llll_opy_, bstack11l1l1ll_opy_)
    if bstack1111llll_opy_ != os.path.dirname(bstack1111llll_opy_):
      bstack1111llll_opy_ = os.path.dirname(bstack1111llll_opy_)
    else:
      bstack1111llll_opy_ = bstack1l111l_opy_ (u"ࠤࠥࢴ")
  if not os.path.exists(bstack111_opy_):
    bstack1ll1lllll_opy_(
      bstack1lllll1ll1_opy_.format(os.getcwd()))
  try:
    with open(bstack111_opy_, bstack1l111l_opy_ (u"ࠪࡶࠬࢵ")) as stream:
      yaml.add_implicit_resolver(bstack1l111l_opy_ (u"ࠦࠦࡶࡡࡵࡪࡨࡼࠧࢶ"), bstack1l1111l1l_opy_)
      yaml.add_constructor(bstack1l111l_opy_ (u"ࠧࠧࡰࡢࡶ࡫ࡩࡽࠨࢷ"), bstack111l1llll_opy_)
      config = yaml.load(stream, yaml.FullLoader)
      return config
  except:
    with open(bstack111_opy_, bstack1l111l_opy_ (u"࠭ࡲࠨࢸ")) as stream:
      try:
        config = yaml.safe_load(stream)
        return config
      except yaml.YAMLError as exc:
        bstack1ll1lllll_opy_(bstack11111l1l1_opy_.format(str(exc)))
def bstack1lll111111_opy_(config):
  bstack1ll1ll111l_opy_ = bstack1111l1ll_opy_(config)
  for option in list(bstack1ll1ll111l_opy_):
    if option.lower() in bstack1ll11ll1l_opy_ and option != bstack1ll11ll1l_opy_[option.lower()]:
      bstack1ll1ll111l_opy_[bstack1ll11ll1l_opy_[option.lower()]] = bstack1ll1ll111l_opy_[option]
      del bstack1ll1ll111l_opy_[option]
  return config
def bstack1ll1ll11l_opy_():
  global bstack111l1ll1_opy_
  for key, bstack11l11ll1l_opy_ in bstack111l1ll11_opy_.items():
    if isinstance(bstack11l11ll1l_opy_, list):
      for var in bstack11l11ll1l_opy_:
        if var in os.environ and os.environ[var] and str(os.environ[var]).strip():
          bstack111l1ll1_opy_[key] = os.environ[var]
          break
    elif bstack11l11ll1l_opy_ in os.environ and os.environ[bstack11l11ll1l_opy_] and str(os.environ[bstack11l11ll1l_opy_]).strip():
      bstack111l1ll1_opy_[key] = os.environ[bstack11l11ll1l_opy_]
  if bstack1l111l_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡌࡐࡅࡄࡐࡤࡏࡄࡆࡐࡗࡍࡋࡏࡅࡓࠩࢹ") in os.environ:
    bstack111l1ll1_opy_[bstack1l111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࡌࡰࡥࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬࢺ")] = {}
    bstack111l1ll1_opy_[bstack1l111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࡍࡱࡦࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭ࢻ")][bstack1l111l_opy_ (u"ࠪࡰࡴࡩࡡ࡭ࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬࢼ")] = os.environ[bstack1l111l_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡐࡔࡉࡁࡍࡡࡌࡈࡊࡔࡔࡊࡈࡌࡉࡗ࠭ࢽ")]
def bstack1l1l1111_opy_():
  global bstack1lll11l1l1_opy_
  global bstack1l1l1l11l_opy_
  for idx, val in enumerate(sys.argv):
    if idx < len(sys.argv) and bstack1l111l_opy_ (u"ࠬ࠳࠭ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴࡬ࡰࡥࡤࡰࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨࢾ").lower() == val.lower():
      bstack1lll11l1l1_opy_[bstack1l111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪࢿ")] = {}
      bstack1lll11l1l1_opy_[bstack1l111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫࣀ")][bstack1l111l_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪࣁ")] = sys.argv[idx + 1]
      del sys.argv[idx:idx + 2]
      break
  for key, bstack11l1l11ll_opy_ in bstack1l1l1111l_opy_.items():
    if isinstance(bstack11l1l11ll_opy_, list):
      for idx, val in enumerate(sys.argv):
        for var in bstack11l1l11ll_opy_:
          if idx < len(sys.argv) and bstack1l111l_opy_ (u"ࠩ࠰࠱ࠬࣂ") + var.lower() == val.lower() and not key in bstack1lll11l1l1_opy_:
            bstack1lll11l1l1_opy_[key] = sys.argv[idx + 1]
            bstack1l1l1l11l_opy_ += bstack1l111l_opy_ (u"ࠪࠤ࠲࠳ࠧࣃ") + var + bstack1l111l_opy_ (u"ࠫࠥ࠭ࣄ") + sys.argv[idx + 1]
            del sys.argv[idx:idx + 2]
            break
    else:
      for idx, val in enumerate(sys.argv):
        if idx < len(sys.argv) and bstack1l111l_opy_ (u"ࠬ࠳࠭ࠨࣅ") + bstack11l1l11ll_opy_.lower() == val.lower() and not key in bstack1lll11l1l1_opy_:
          bstack1lll11l1l1_opy_[key] = sys.argv[idx + 1]
          bstack1l1l1l11l_opy_ += bstack1l111l_opy_ (u"࠭ࠠ࠮࠯ࠪࣆ") + bstack11l1l11ll_opy_ + bstack1l111l_opy_ (u"ࠧࠡࠩࣇ") + sys.argv[idx + 1]
          del sys.argv[idx:idx + 2]
def bstack1l1111ll1_opy_(config):
  bstack11l1ll111_opy_ = config.keys()
  for bstack1111l1ll1_opy_, bstack1lll1lll1_opy_ in bstack1lllll11l_opy_.items():
    if bstack1lll1lll1_opy_ in bstack11l1ll111_opy_:
      config[bstack1111l1ll1_opy_] = config[bstack1lll1lll1_opy_]
      del config[bstack1lll1lll1_opy_]
  for bstack1111l1ll1_opy_, bstack1lll1lll1_opy_ in bstack111lll111_opy_.items():
    if isinstance(bstack1lll1lll1_opy_, list):
      for bstack11lll111l_opy_ in bstack1lll1lll1_opy_:
        if bstack11lll111l_opy_ in bstack11l1ll111_opy_:
          config[bstack1111l1ll1_opy_] = config[bstack11lll111l_opy_]
          del config[bstack11lll111l_opy_]
          break
    elif bstack1lll1lll1_opy_ in bstack11l1ll111_opy_:
      config[bstack1111l1ll1_opy_] = config[bstack1lll1lll1_opy_]
      del config[bstack1lll1lll1_opy_]
  for bstack11lll111l_opy_ in list(config):
    for bstack11lll1l1l_opy_ in bstack1lll111l11_opy_:
      if bstack11lll111l_opy_.lower() == bstack11lll1l1l_opy_.lower() and bstack11lll111l_opy_ != bstack11lll1l1l_opy_:
        config[bstack11lll1l1l_opy_] = config[bstack11lll111l_opy_]
        del config[bstack11lll111l_opy_]
  bstack1ll1llll1_opy_ = []
  if bstack1l111l_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫࣈ") in config:
    bstack1ll1llll1_opy_ = config[bstack1l111l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬࣉ")]
  for platform in bstack1ll1llll1_opy_:
    for bstack11lll111l_opy_ in list(platform):
      for bstack11lll1l1l_opy_ in bstack1lll111l11_opy_:
        if bstack11lll111l_opy_.lower() == bstack11lll1l1l_opy_.lower() and bstack11lll111l_opy_ != bstack11lll1l1l_opy_:
          platform[bstack11lll1l1l_opy_] = platform[bstack11lll111l_opy_]
          del platform[bstack11lll111l_opy_]
  for bstack1111l1ll1_opy_, bstack1lll1lll1_opy_ in bstack111lll111_opy_.items():
    for platform in bstack1ll1llll1_opy_:
      if isinstance(bstack1lll1lll1_opy_, list):
        for bstack11lll111l_opy_ in bstack1lll1lll1_opy_:
          if bstack11lll111l_opy_ in platform:
            platform[bstack1111l1ll1_opy_] = platform[bstack11lll111l_opy_]
            del platform[bstack11lll111l_opy_]
            break
      elif bstack1lll1lll1_opy_ in platform:
        platform[bstack1111l1ll1_opy_] = platform[bstack1lll1lll1_opy_]
        del platform[bstack1lll1lll1_opy_]
  for bstack11111l11l_opy_ in bstack1l11l11ll_opy_:
    if bstack11111l11l_opy_ in config:
      if not bstack1l11l11ll_opy_[bstack11111l11l_opy_] in config:
        config[bstack1l11l11ll_opy_[bstack11111l11l_opy_]] = {}
      config[bstack1l11l11ll_opy_[bstack11111l11l_opy_]].update(config[bstack11111l11l_opy_])
      del config[bstack11111l11l_opy_]
  for platform in bstack1ll1llll1_opy_:
    for bstack11111l11l_opy_ in bstack1l11l11ll_opy_:
      if bstack11111l11l_opy_ in list(platform):
        if not bstack1l11l11ll_opy_[bstack11111l11l_opy_] in platform:
          platform[bstack1l11l11ll_opy_[bstack11111l11l_opy_]] = {}
        platform[bstack1l11l11ll_opy_[bstack11111l11l_opy_]].update(platform[bstack11111l11l_opy_])
        del platform[bstack11111l11l_opy_]
  config = bstack1lll111111_opy_(config)
  return config
def bstack1l1l1l11_opy_(config):
  global bstack1ll1ll1ll1_opy_
  if bstack1l111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࠧ࣊") in config and str(config[bstack1l111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡏࡳࡨࡧ࡬ࠨ࣋")]).lower() != bstack1l111l_opy_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫ࣌"):
    if not bstack1l111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪ࣍") in config:
      config[bstack1l111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫ࣎")] = {}
    if not bstack1l111l_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴ࣏ࠪ") in config[bstack1l111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࡍࡱࡦࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࣐࠭")]:
      bstack1l1lll1l_opy_ = datetime.datetime.now()
      bstack1l11l1111_opy_ = bstack1l1lll1l_opy_.strftime(bstack1l111l_opy_ (u"ࠪࠩࡩࡥࠥࡣࡡࠨࡌࠪࡓ࣑ࠧ"))
      hostname = socket.gethostname()
      bstack1l1l1l1l1_opy_ = bstack1l111l_opy_ (u"࣒ࠫࠬ").join(random.choices(string.ascii_lowercase + string.digits, k=4))
      identifier = bstack1l111l_opy_ (u"ࠬࢁࡽࡠࡽࢀࡣࢀࢃ࣓ࠧ").format(bstack1l11l1111_opy_, hostname, bstack1l1l1l1l1_opy_)
      config[bstack1l111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪࣔ")][bstack1l111l_opy_ (u"ࠧ࡭ࡱࡦࡥࡱࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩࣕ")] = identifier
    bstack1ll1ll1ll1_opy_ = config[bstack1l111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࡌࡰࡥࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬࣖ")][bstack1l111l_opy_ (u"ࠩ࡯ࡳࡨࡧ࡬ࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫࣗ")]
  return config
def bstack11ll1ll1l_opy_():
  if (
          isinstance(os.getenv(bstack1l111l_opy_ (u"ࠪࡎࡊࡔࡋࡊࡐࡖࡣ࡚ࡘࡌࠨࣘ")), str) and len(os.getenv(bstack1l111l_opy_ (u"ࠫࡏࡋࡎࡌࡋࡑࡗࡤ࡛ࡒࡍࠩࣙ"))) > 0
  ) or (
          isinstance(os.getenv(bstack1l111l_opy_ (u"ࠬࡐࡅࡏࡍࡌࡒࡘࡥࡈࡐࡏࡈࠫࣚ")), str) and len(os.getenv(bstack1l111l_opy_ (u"࠭ࡊࡆࡐࡎࡍࡓ࡙࡟ࡉࡑࡐࡉࠬࣛ"))) > 0
  ):
    return os.getenv(bstack1l111l_opy_ (u"ࠧࡃࡗࡌࡐࡉࡥࡎࡖࡏࡅࡉࡗ࠭ࣜ"), 0)
  if str(os.getenv(bstack1l111l_opy_ (u"ࠨࡅࡌࠫࣝ"))).lower() == bstack1l111l_opy_ (u"ࠩࡷࡶࡺ࡫ࠧࣞ") and str(os.getenv(bstack1l111l_opy_ (u"ࠪࡇࡎࡘࡃࡍࡇࡆࡍࠬࣟ"))).lower() == bstack1l111l_opy_ (u"ࠫࡹࡸࡵࡦࠩ࣠"):
    return os.getenv(bstack1l111l_opy_ (u"ࠬࡉࡉࡓࡅࡏࡉࡤࡈࡕࡊࡎࡇࡣࡓ࡛ࡍࠨ࣡"), 0)
  if str(os.getenv(bstack1l111l_opy_ (u"࠭ࡃࡊࠩ࣢"))).lower() == bstack1l111l_opy_ (u"ࠧࡵࡴࡸࡩࣣࠬ") and str(os.getenv(bstack1l111l_opy_ (u"ࠨࡖࡕࡅ࡛ࡏࡓࠨࣤ"))).lower() == bstack1l111l_opy_ (u"ࠩࡷࡶࡺ࡫ࠧࣥ"):
    return os.getenv(bstack1l111l_opy_ (u"ࠪࡘࡗࡇࡖࡊࡕࡢࡆ࡚ࡏࡌࡅࡡࡑ࡙ࡒࡈࡅࡓࣦࠩ"), 0)
  if str(os.getenv(bstack1l111l_opy_ (u"ࠫࡈࡏࠧࣧ"))).lower() == bstack1l111l_opy_ (u"ࠬࡺࡲࡶࡧࠪࣨ") and str(os.getenv(bstack1l111l_opy_ (u"࠭ࡃࡊࡡࡑࡅࡒࡋࣩࠧ"))).lower() == bstack1l111l_opy_ (u"ࠧࡤࡱࡧࡩࡸ࡮ࡩࡱࠩ࣪"):
    return 0
  if os.getenv(bstack1l111l_opy_ (u"ࠨࡄࡌࡘࡇ࡛ࡃࡌࡇࡗࡣࡇࡘࡁࡏࡅࡋࠫ࣫")) and os.getenv(bstack1l111l_opy_ (u"ࠩࡅࡍ࡙ࡈࡕࡄࡍࡈࡘࡤࡉࡏࡎࡏࡌࡘࠬ࣬")):
    return os.getenv(bstack1l111l_opy_ (u"ࠪࡆࡎ࡚ࡂࡖࡅࡎࡉ࡙ࡥࡂࡖࡋࡏࡈࡤࡔࡕࡎࡄࡈࡖ࣭ࠬ"), 0)
  if str(os.getenv(bstack1l111l_opy_ (u"ࠫࡈࡏ࣮ࠧ"))).lower() == bstack1l111l_opy_ (u"ࠬࡺࡲࡶࡧ࣯ࠪ") and str(os.getenv(bstack1l111l_opy_ (u"࠭ࡄࡓࡑࡑࡉࣰࠬ"))).lower() == bstack1l111l_opy_ (u"ࠧࡵࡴࡸࡩࣱࠬ"):
    return os.getenv(bstack1l111l_opy_ (u"ࠨࡆࡕࡓࡓࡋ࡟ࡃࡗࡌࡐࡉࡥࡎࡖࡏࡅࡉࡗࣲ࠭"), 0)
  if str(os.getenv(bstack1l111l_opy_ (u"ࠩࡆࡍࠬࣳ"))).lower() == bstack1l111l_opy_ (u"ࠪࡸࡷࡻࡥࠨࣴ") and str(os.getenv(bstack1l111l_opy_ (u"ࠫࡘࡋࡍࡂࡒࡋࡓࡗࡋࠧࣵ"))).lower() == bstack1l111l_opy_ (u"ࠬࡺࡲࡶࡧࣶࠪ"):
    return os.getenv(bstack1l111l_opy_ (u"࠭ࡓࡆࡏࡄࡔࡍࡕࡒࡆࡡࡍࡓࡇࡥࡉࡅࠩࣷ"), 0)
  if str(os.getenv(bstack1l111l_opy_ (u"ࠧࡄࡋࠪࣸ"))).lower() == bstack1l111l_opy_ (u"ࠨࡶࡵࡹࡪࣹ࠭") and str(os.getenv(bstack1l111l_opy_ (u"ࠩࡊࡍ࡙ࡒࡁࡃࡡࡆࡍࣺࠬ"))).lower() == bstack1l111l_opy_ (u"ࠪࡸࡷࡻࡥࠨࣻ"):
    return os.getenv(bstack1l111l_opy_ (u"ࠫࡈࡏ࡟ࡋࡑࡅࡣࡎࡊࠧࣼ"), 0)
  if str(os.getenv(bstack1l111l_opy_ (u"ࠬࡉࡉࠨࣽ"))).lower() == bstack1l111l_opy_ (u"࠭ࡴࡳࡷࡨࠫࣾ") and str(os.getenv(bstack1l111l_opy_ (u"ࠧࡃࡗࡌࡐࡉࡑࡉࡕࡇࠪࣿ"))).lower() == bstack1l111l_opy_ (u"ࠨࡶࡵࡹࡪ࠭ऀ"):
    return os.getenv(bstack1l111l_opy_ (u"ࠩࡅ࡙ࡎࡒࡄࡌࡋࡗࡉࡤࡈࡕࡊࡎࡇࡣࡓ࡛ࡍࡃࡇࡕࠫँ"), 0)
  if str(os.getenv(bstack1l111l_opy_ (u"ࠪࡘࡋࡥࡂࡖࡋࡏࡈࠬं"))).lower() == bstack1l111l_opy_ (u"ࠫࡹࡸࡵࡦࠩः"):
    return os.getenv(bstack1l111l_opy_ (u"ࠬࡈࡕࡊࡎࡇࡣࡇ࡛ࡉࡍࡆࡌࡈࠬऄ"), 0)
  return -1
def bstack11l111l11_opy_(bstack111l111ll_opy_):
  global CONFIG
  if not bstack1l111l_opy_ (u"࠭ࠤࡼࡄࡘࡍࡑࡊ࡟ࡏࡗࡐࡆࡊࡘࡽࠨअ") in CONFIG[bstack1l111l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩआ")]:
    return
  CONFIG[bstack1l111l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪइ")] = CONFIG[bstack1l111l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫई")].replace(
    bstack1l111l_opy_ (u"ࠪࠨࢀࡈࡕࡊࡎࡇࡣࡓ࡛ࡍࡃࡇࡕࢁࠬउ"),
    str(bstack111l111ll_opy_)
  )
def bstack1ll1l11l1l_opy_():
  global CONFIG
  if not bstack1l111l_opy_ (u"ࠫࠩࢁࡄࡂࡖࡈࡣ࡙ࡏࡍࡆࡿࠪऊ") in CONFIG[bstack1l111l_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧऋ")]:
    return
  bstack1l1lll1l_opy_ = datetime.datetime.now()
  bstack1l11l1111_opy_ = bstack1l1lll1l_opy_.strftime(bstack1l111l_opy_ (u"࠭ࠥࡥ࠯ࠨࡦ࠲ࠫࡈ࠻ࠧࡐࠫऌ"))
  CONFIG[bstack1l111l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩऍ")] = CONFIG[bstack1l111l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪऎ")].replace(
    bstack1l111l_opy_ (u"ࠩࠧࡿࡉࡇࡔࡆࡡࡗࡍࡒࡋࡽࠨए"),
    bstack1l11l1111_opy_
  )
def bstack11l11l11_opy_():
  global CONFIG
  if bstack1l111l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬऐ") in CONFIG and not bool(CONFIG[bstack1l111l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭ऑ")]):
    del CONFIG[bstack1l111l_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧऒ")]
    return
  if not bstack1l111l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨओ") in CONFIG:
    CONFIG[bstack1l111l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩऔ")] = bstack1l111l_opy_ (u"ࠨࠥࠧࡿࡇ࡛ࡉࡍࡆࡢࡒ࡚ࡓࡂࡆࡔࢀࠫक")
  if bstack1l111l_opy_ (u"ࠩࠧࡿࡉࡇࡔࡆࡡࡗࡍࡒࡋࡽࠨख") in CONFIG[bstack1l111l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬग")]:
    bstack1ll1l11l1l_opy_()
    os.environ[bstack1l111l_opy_ (u"ࠫࡇ࡙ࡔࡂࡅࡎࡣࡈࡕࡍࡃࡋࡑࡉࡉࡥࡂࡖࡋࡏࡈࡤࡏࡄࠨघ")] = CONFIG[bstack1l111l_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧङ")]
  if not bstack1l111l_opy_ (u"࠭ࠤࡼࡄࡘࡍࡑࡊ࡟ࡏࡗࡐࡆࡊࡘࡽࠨच") in CONFIG[bstack1l111l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩछ")]:
    return
  bstack111l111ll_opy_ = bstack1l111l_opy_ (u"ࠨࠩज")
  bstack1llll1l1l_opy_ = bstack11ll1ll1l_opy_()
  if bstack1llll1l1l_opy_ != -1:
    bstack111l111ll_opy_ = bstack1l111l_opy_ (u"ࠩࡆࡍࠥ࠭झ") + str(bstack1llll1l1l_opy_)
  if bstack111l111ll_opy_ == bstack1l111l_opy_ (u"ࠪࠫञ"):
    bstack1ll1llll11_opy_ = bstack1lllll11ll_opy_(CONFIG[bstack1l111l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠧट")])
    if bstack1ll1llll11_opy_ != -1:
      bstack111l111ll_opy_ = str(bstack1ll1llll11_opy_)
  if bstack111l111ll_opy_:
    bstack11l111l11_opy_(bstack111l111ll_opy_)
    os.environ[bstack1l111l_opy_ (u"ࠬࡈࡓࡕࡃࡆࡏࡤࡉࡏࡎࡄࡌࡒࡊࡊ࡟ࡃࡗࡌࡐࡉࡥࡉࡅࠩठ")] = CONFIG[bstack1l111l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨड")]
def bstack11lllllll_opy_(bstack1l11ll1l1_opy_, bstack1l11l1l1l_opy_, path):
  bstack1ll1l11ll_opy_ = {
    bstack1l111l_opy_ (u"ࠧࡪࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫढ"): bstack1l11l1l1l_opy_
  }
  if os.path.exists(path):
    bstack111l11l1l_opy_ = json.load(open(path, bstack1l111l_opy_ (u"ࠨࡴࡥࠫण")))
  else:
    bstack111l11l1l_opy_ = {}
  bstack111l11l1l_opy_[bstack1l11ll1l1_opy_] = bstack1ll1l11ll_opy_
  with open(path, bstack1l111l_opy_ (u"ࠤࡺ࠯ࠧत")) as outfile:
    json.dump(bstack111l11l1l_opy_, outfile)
def bstack1lllll11ll_opy_(bstack1l11ll1l1_opy_):
  bstack1l11ll1l1_opy_ = str(bstack1l11ll1l1_opy_)
  bstack1l1l1l1l_opy_ = os.path.join(os.path.expanduser(bstack1l111l_opy_ (u"ࠪࢂࠬथ")), bstack1l111l_opy_ (u"ࠫ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠫद"))
  try:
    if not os.path.exists(bstack1l1l1l1l_opy_):
      os.makedirs(bstack1l1l1l1l_opy_)
    file_path = os.path.join(os.path.expanduser(bstack1l111l_opy_ (u"ࠬࢄࠧध")), bstack1l111l_opy_ (u"࠭࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠭न"), bstack1l111l_opy_ (u"ࠧ࠯ࡤࡸ࡭ࡱࡪ࠭࡯ࡣࡰࡩ࠲ࡩࡡࡤࡪࡨ࠲࡯ࡹ࡯࡯ࠩऩ"))
    if not os.path.isfile(file_path):
      with open(file_path, bstack1l111l_opy_ (u"ࠨࡹࠪप")):
        pass
      with open(file_path, bstack1l111l_opy_ (u"ࠤࡺ࠯ࠧफ")) as outfile:
        json.dump({}, outfile)
    with open(file_path, bstack1l111l_opy_ (u"ࠪࡶࠬब")) as bstack1llll111l_opy_:
      bstack111ll1l11_opy_ = json.load(bstack1llll111l_opy_)
    if bstack1l11ll1l1_opy_ in bstack111ll1l11_opy_:
      bstack1l11l1l1_opy_ = bstack111ll1l11_opy_[bstack1l11ll1l1_opy_][bstack1l111l_opy_ (u"ࠫ࡮ࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨभ")]
      bstack1l111l1l1_opy_ = int(bstack1l11l1l1_opy_) + 1
      bstack11lllllll_opy_(bstack1l11ll1l1_opy_, bstack1l111l1l1_opy_, file_path)
      return bstack1l111l1l1_opy_
    else:
      bstack11lllllll_opy_(bstack1l11ll1l1_opy_, 1, file_path)
      return 1
  except Exception as e:
    logger.warn(bstack1lll111ll_opy_.format(str(e)))
    return -1
def bstack11111llll_opy_(config):
  if not config[bstack1l111l_opy_ (u"ࠬࡻࡳࡦࡴࡑࡥࡲ࡫ࠧम")] or not config[bstack1l111l_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸࡑࡥࡺࠩय")]:
    return True
  else:
    return False
def bstack111llll1l_opy_(config, index=0):
  global bstack1ll111l11_opy_
  bstack11l1l1111_opy_ = {}
  caps = bstack11l1lll1l_opy_ + bstack1lll1lll1l_opy_
  if bstack1ll111l11_opy_:
    caps += bstack11ll11l1l_opy_
  for key in config:
    if key in caps + [bstack1l111l_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪर")]:
      continue
    bstack11l1l1111_opy_[key] = config[key]
  if bstack1l111l_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫऱ") in config:
    for bstack1l111l111_opy_ in config[bstack1l111l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬल")][index]:
      if bstack1l111l111_opy_ in caps + [bstack1l111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡒࡦࡳࡥࠨळ"), bstack1l111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠬऴ")]:
        continue
      bstack11l1l1111_opy_[bstack1l111l111_opy_] = config[bstack1l111l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨव")][index][bstack1l111l111_opy_]
  bstack11l1l1111_opy_[bstack1l111l_opy_ (u"࠭ࡨࡰࡵࡷࡒࡦࡳࡥࠨश")] = socket.gethostname()
  if bstack1l111l_opy_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨष") in bstack11l1l1111_opy_:
    del (bstack11l1l1111_opy_[bstack1l111l_opy_ (u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩस")])
  return bstack11l1l1111_opy_
def bstack111l1l1l1_opy_(config):
  global bstack1ll111l11_opy_
  bstack1llllll11_opy_ = {}
  caps = bstack1lll1lll1l_opy_
  if bstack1ll111l11_opy_:
    caps += bstack11ll11l1l_opy_
  for key in caps:
    if key in config:
      bstack1llllll11_opy_[key] = config[key]
  return bstack1llllll11_opy_
def bstack1ll11ll1ll_opy_(bstack11l1l1111_opy_, bstack1llllll11_opy_):
  bstack11ll11lll_opy_ = {}
  for key in bstack11l1l1111_opy_.keys():
    if key in bstack1lllll11l_opy_:
      bstack11ll11lll_opy_[bstack1lllll11l_opy_[key]] = bstack11l1l1111_opy_[key]
    else:
      bstack11ll11lll_opy_[key] = bstack11l1l1111_opy_[key]
  for key in bstack1llllll11_opy_:
    if key in bstack1lllll11l_opy_:
      bstack11ll11lll_opy_[bstack1lllll11l_opy_[key]] = bstack1llllll11_opy_[key]
    else:
      bstack11ll11lll_opy_[key] = bstack1llllll11_opy_[key]
  return bstack11ll11lll_opy_
def bstack1ll111111_opy_(config, index=0):
  global bstack1ll111l11_opy_
  config = copy.deepcopy(config)
  caps = {}
  bstack1llllll11_opy_ = bstack111l1l1l1_opy_(config)
  bstack1lllll11l1_opy_ = bstack1lll1lll1l_opy_
  bstack1lllll11l1_opy_ += bstack11l11l11l_opy_
  if bstack1ll111l11_opy_:
    bstack1lllll11l1_opy_ += bstack11ll11l1l_opy_
  if bstack1l111l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬह") in config:
    if bstack1l111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡒࡦࡳࡥࠨऺ") in config[bstack1l111l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧऻ")][index]:
      caps[bstack1l111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡔࡡ࡮ࡧ़ࠪ")] = config[bstack1l111l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩऽ")][index][bstack1l111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠬा")]
    if bstack1l111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡘࡨࡶࡸ࡯࡯࡯ࠩि") in config[bstack1l111l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬी")][index]:
      caps[bstack1l111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵ࡚ࡪࡸࡳࡪࡱࡱࠫु")] = str(config[bstack1l111l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧू")][index][bstack1l111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡜ࡥࡳࡵ࡬ࡳࡳ࠭ृ")])
    bstack1l11ll1l_opy_ = {}
    for bstack1llll11ll1_opy_ in bstack1lllll11l1_opy_:
      if bstack1llll11ll1_opy_ in config[bstack1l111l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩॄ")][index]:
        if bstack1llll11ll1_opy_ == bstack1l111l_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡘࡨࡶࡸ࡯࡯࡯ࠩॅ"):
          try:
            bstack1l11ll1l_opy_[bstack1llll11ll1_opy_] = str(config[bstack1l111l_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫॆ")][index][bstack1llll11ll1_opy_] * 1.0)
          except:
            bstack1l11ll1l_opy_[bstack1llll11ll1_opy_] = str(config[bstack1l111l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬे")][index][bstack1llll11ll1_opy_])
        else:
          bstack1l11ll1l_opy_[bstack1llll11ll1_opy_] = config[bstack1l111l_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ै")][index][bstack1llll11ll1_opy_]
        del (config[bstack1l111l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧॉ")][index][bstack1llll11ll1_opy_])
    bstack1llllll11_opy_ = update(bstack1llllll11_opy_, bstack1l11ll1l_opy_)
  bstack11l1l1111_opy_ = bstack111llll1l_opy_(config, index)
  for bstack11lll111l_opy_ in bstack1lll1lll1l_opy_ + [bstack1l111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡔࡡ࡮ࡧࠪॊ"), bstack1l111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠧो")]:
    if bstack11lll111l_opy_ in bstack11l1l1111_opy_:
      bstack1llllll11_opy_[bstack11lll111l_opy_] = bstack11l1l1111_opy_[bstack11lll111l_opy_]
      del (bstack11l1l1111_opy_[bstack11lll111l_opy_])
  if bstack111111l11_opy_(config):
    bstack11l1l1111_opy_[bstack1l111l_opy_ (u"ࠧࡶࡵࡨ࡛࠸ࡉࠧौ")] = True
    caps.update(bstack1llllll11_opy_)
    caps[bstack1l111l_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫࠻ࡱࡳࡸ࡮ࡵ࡮ࡴ्ࠩ")] = bstack11l1l1111_opy_
  else:
    bstack11l1l1111_opy_[bstack1l111l_opy_ (u"ࠩࡸࡷࡪ࡝࠳ࡄࠩॎ")] = False
    caps.update(bstack1ll11ll1ll_opy_(bstack11l1l1111_opy_, bstack1llllll11_opy_))
    if bstack1l111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡒࡦࡳࡥࠨॏ") in caps:
      caps[bstack1l111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࠬॐ")] = caps[bstack1l111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡔࡡ࡮ࡧࠪ॑")]
      del (caps[bstack1l111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡎࡢ࡯ࡨ॒ࠫ")])
    if bstack1l111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨ॓") in caps:
      caps[bstack1l111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡡࡹࡩࡷࡹࡩࡰࡰࠪ॔")] = caps[bstack1l111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪॕ")]
      del (caps[bstack1l111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵ࡚ࡪࡸࡳࡪࡱࡱࠫॖ")])
  return caps
def bstack111111ll_opy_():
  global bstack1ll11lll1_opy_
  if bstack111lllll1_opy_() <= version.parse(bstack1l111l_opy_ (u"ࠫ࠸࠴࠱࠴࠰࠳ࠫॗ")):
    if bstack1ll11lll1_opy_ != bstack1l111l_opy_ (u"ࠬ࠭क़"):
      return bstack1l111l_opy_ (u"ࠨࡨࡵࡶࡳ࠾࠴࠵ࠢख़") + bstack1ll11lll1_opy_ + bstack1l111l_opy_ (u"ࠢ࠻࠺࠳࠳ࡼࡪ࠯ࡩࡷࡥࠦग़")
    return bstack1ll11llll1_opy_
  if bstack1ll11lll1_opy_ != bstack1l111l_opy_ (u"ࠨࠩज़"):
    return bstack1l111l_opy_ (u"ࠤ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠦड़") + bstack1ll11lll1_opy_ + bstack1l111l_opy_ (u"ࠥ࠳ࡼࡪ࠯ࡩࡷࡥࠦढ़")
  return bstack1lll1l1ll_opy_
def bstack1ll1l1l111_opy_(options):
  return hasattr(options, bstack1l111l_opy_ (u"ࠫࡸ࡫ࡴࡠࡥࡤࡴࡦࡨࡩ࡭࡫ࡷࡽࠬफ़"))
def update(d, u):
  for k, v in u.items():
    if isinstance(v, collections.abc.Mapping):
      d[k] = update(d.get(k, {}), v)
    else:
      if isinstance(v, list):
        d[k] = d.get(k, []) + v
      else:
        d[k] = v
  return d
def bstack1lll1l11l1_opy_(options, bstack1l111l1l_opy_):
  for bstack1l1l1l1ll_opy_ in bstack1l111l1l_opy_:
    if bstack1l1l1l1ll_opy_ in [bstack1l111l_opy_ (u"ࠬࡧࡲࡨࡵࠪय़"), bstack1l111l_opy_ (u"࠭ࡥࡹࡶࡨࡲࡸ࡯࡯࡯ࡵࠪॠ")]:
      next
    if bstack1l1l1l1ll_opy_ in options._experimental_options:
      options._experimental_options[bstack1l1l1l1ll_opy_] = update(options._experimental_options[bstack1l1l1l1ll_opy_],
                                                         bstack1l111l1l_opy_[bstack1l1l1l1ll_opy_])
    else:
      options.add_experimental_option(bstack1l1l1l1ll_opy_, bstack1l111l1l_opy_[bstack1l1l1l1ll_opy_])
  if bstack1l111l_opy_ (u"ࠧࡢࡴࡪࡷࠬॡ") in bstack1l111l1l_opy_:
    for arg in bstack1l111l1l_opy_[bstack1l111l_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭ॢ")]:
      options.add_argument(arg)
    del (bstack1l111l1l_opy_[bstack1l111l_opy_ (u"ࠩࡤࡶ࡬ࡹࠧॣ")])
  if bstack1l111l_opy_ (u"ࠪࡩࡽࡺࡥ࡯ࡵ࡬ࡳࡳࡹࠧ।") in bstack1l111l1l_opy_:
    for ext in bstack1l111l1l_opy_[bstack1l111l_opy_ (u"ࠫࡪࡾࡴࡦࡰࡶ࡭ࡴࡴࡳࠨ॥")]:
      options.add_extension(ext)
    del (bstack1l111l1l_opy_[bstack1l111l_opy_ (u"ࠬ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮ࡴࠩ०")])
def bstack1ll11l11l_opy_(options, bstack1ll1lll11l_opy_):
  if bstack1l111l_opy_ (u"࠭ࡰࡳࡧࡩࡷࠬ१") in bstack1ll1lll11l_opy_:
    for bstack11l1ll1ll_opy_ in bstack1ll1lll11l_opy_[bstack1l111l_opy_ (u"ࠧࡱࡴࡨࡪࡸ࠭२")]:
      if bstack11l1ll1ll_opy_ in options._preferences:
        options._preferences[bstack11l1ll1ll_opy_] = update(options._preferences[bstack11l1ll1ll_opy_], bstack1ll1lll11l_opy_[bstack1l111l_opy_ (u"ࠨࡲࡵࡩ࡫ࡹࠧ३")][bstack11l1ll1ll_opy_])
      else:
        options.set_preference(bstack11l1ll1ll_opy_, bstack1ll1lll11l_opy_[bstack1l111l_opy_ (u"ࠩࡳࡶࡪ࡬ࡳࠨ४")][bstack11l1ll1ll_opy_])
  if bstack1l111l_opy_ (u"ࠪࡥࡷ࡭ࡳࠨ५") in bstack1ll1lll11l_opy_:
    for arg in bstack1ll1lll11l_opy_[bstack1l111l_opy_ (u"ࠫࡦࡸࡧࡴࠩ६")]:
      options.add_argument(arg)
def bstack11111l11_opy_(options, bstack11ll1l11_opy_):
  if bstack1l111l_opy_ (u"ࠬࡽࡥࡣࡸ࡬ࡩࡼ࠭७") in bstack11ll1l11_opy_:
    options.use_webview(bool(bstack11ll1l11_opy_[bstack1l111l_opy_ (u"࠭ࡷࡦࡤࡹ࡭ࡪࡽࠧ८")]))
  bstack1lll1l11l1_opy_(options, bstack11ll1l11_opy_)
def bstack111ll11l_opy_(options, bstack11llll11_opy_):
  for bstack11ll1l1l_opy_ in bstack11llll11_opy_:
    if bstack11ll1l1l_opy_ in [bstack1l111l_opy_ (u"ࠧࡵࡧࡦ࡬ࡳࡵ࡬ࡰࡩࡼࡔࡷ࡫ࡶࡪࡧࡺࠫ९"), bstack1l111l_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭॰")]:
      next
    options.set_capability(bstack11ll1l1l_opy_, bstack11llll11_opy_[bstack11ll1l1l_opy_])
  if bstack1l111l_opy_ (u"ࠩࡤࡶ࡬ࡹࠧॱ") in bstack11llll11_opy_:
    for arg in bstack11llll11_opy_[bstack1l111l_opy_ (u"ࠪࡥࡷ࡭ࡳࠨॲ")]:
      options.add_argument(arg)
  if bstack1l111l_opy_ (u"ࠫࡹ࡫ࡣࡩࡰࡲࡰࡴ࡭ࡹࡑࡴࡨࡺ࡮࡫ࡷࠨॳ") in bstack11llll11_opy_:
    options.bstack1l11l111l_opy_(bool(bstack11llll11_opy_[bstack1l111l_opy_ (u"ࠬࡺࡥࡤࡪࡱࡳࡱࡵࡧࡺࡒࡵࡩࡻ࡯ࡥࡸࠩॴ")]))
def bstack11ll1l11l_opy_(options, bstack1l1111ll_opy_):
  for bstack1l1lllll_opy_ in bstack1l1111ll_opy_:
    if bstack1l1lllll_opy_ in [bstack1l111l_opy_ (u"࠭ࡡࡥࡦ࡬ࡸ࡮ࡵ࡮ࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪॵ"), bstack1l111l_opy_ (u"ࠧࡢࡴࡪࡷࠬॶ")]:
      next
    options._options[bstack1l1lllll_opy_] = bstack1l1111ll_opy_[bstack1l1lllll_opy_]
  if bstack1l111l_opy_ (u"ࠨࡣࡧࡨ࡮ࡺࡩࡰࡰࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬॷ") in bstack1l1111ll_opy_:
    for bstack1ll1ll11l1_opy_ in bstack1l1111ll_opy_[bstack1l111l_opy_ (u"ࠩࡤࡨࡩ࡯ࡴࡪࡱࡱࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭ॸ")]:
      options.bstack1ll11lll11_opy_(
        bstack1ll1ll11l1_opy_, bstack1l1111ll_opy_[bstack1l111l_opy_ (u"ࠪࡥࡩࡪࡩࡵ࡫ࡲࡲࡦࡲࡏࡱࡶ࡬ࡳࡳࡹࠧॹ")][bstack1ll1ll11l1_opy_])
  if bstack1l111l_opy_ (u"ࠫࡦࡸࡧࡴࠩॺ") in bstack1l1111ll_opy_:
    for arg in bstack1l1111ll_opy_[bstack1l111l_opy_ (u"ࠬࡧࡲࡨࡵࠪॻ")]:
      options.add_argument(arg)
def bstack1ll1lll1ll_opy_(options, caps):
  if not hasattr(options, bstack1l111l_opy_ (u"࠭ࡋࡆ࡛ࠪॼ")):
    return
  if options.KEY == bstack1l111l_opy_ (u"ࠧࡨࡱࡲ࡫࠿ࡩࡨࡳࡱࡰࡩࡔࡶࡴࡪࡱࡱࡷࠬॽ") and options.KEY in caps:
    bstack1lll1l11l1_opy_(options, caps[bstack1l111l_opy_ (u"ࠨࡩࡲࡳ࡬ࡀࡣࡩࡴࡲࡱࡪࡕࡰࡵ࡫ࡲࡲࡸ࠭ॾ")])
  elif options.KEY == bstack1l111l_opy_ (u"ࠩࡰࡳࡿࡀࡦࡪࡴࡨࡪࡴࡾࡏࡱࡶ࡬ࡳࡳࡹࠧॿ") and options.KEY in caps:
    bstack1ll11l11l_opy_(options, caps[bstack1l111l_opy_ (u"ࠪࡱࡴࢀ࠺ࡧ࡫ࡵࡩ࡫ࡵࡸࡐࡲࡷ࡭ࡴࡴࡳࠨঀ")])
  elif options.KEY == bstack1l111l_opy_ (u"ࠫࡸࡧࡦࡢࡴ࡬࠲ࡴࡶࡴࡪࡱࡱࡷࠬঁ") and options.KEY in caps:
    bstack111ll11l_opy_(options, caps[bstack1l111l_opy_ (u"ࠬࡹࡡࡧࡣࡵ࡭࠳ࡵࡰࡵ࡫ࡲࡲࡸ࠭ং")])
  elif options.KEY == bstack1l111l_opy_ (u"࠭࡭ࡴ࠼ࡨࡨ࡬࡫ࡏࡱࡶ࡬ࡳࡳࡹࠧঃ") and options.KEY in caps:
    bstack11111l11_opy_(options, caps[bstack1l111l_opy_ (u"ࠧ࡮ࡵ࠽ࡩࡩ࡭ࡥࡐࡲࡷ࡭ࡴࡴࡳࠨ঄")])
  elif options.KEY == bstack1l111l_opy_ (u"ࠨࡵࡨ࠾࡮࡫ࡏࡱࡶ࡬ࡳࡳࡹࠧঅ") and options.KEY in caps:
    bstack11ll1l11l_opy_(options, caps[bstack1l111l_opy_ (u"ࠩࡶࡩ࠿࡯ࡥࡐࡲࡷ࡭ࡴࡴࡳࠨআ")])
def bstack11ll11ll_opy_(caps):
  global bstack1ll111l11_opy_
  if isinstance(os.environ.get(bstack1l111l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡌࡗࡤࡇࡐࡑࡡࡄ࡙࡙ࡕࡍࡂࡖࡈࠫই")), str):
    bstack1ll111l11_opy_ = eval(os.getenv(bstack1l111l_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡍࡘࡥࡁࡑࡒࡢࡅ࡚࡚ࡏࡎࡃࡗࡉࠬঈ")))
  if bstack1ll111l11_opy_:
    if bstack1l11111l1_opy_() < version.parse(bstack1l111l_opy_ (u"ࠬ࠸࠮࠴࠰࠳ࠫউ")):
      return None
    else:
      from appium.options.common.base import AppiumOptions
      options = AppiumOptions().load_capabilities(caps)
      return options
  else:
    browser = bstack1l111l_opy_ (u"࠭ࡣࡩࡴࡲࡱࡪ࠭ঊ")
    if bstack1l111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠬঋ") in caps:
      browser = caps[bstack1l111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡐࡤࡱࡪ࠭ঌ")]
    elif bstack1l111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࠪ঍") in caps:
      browser = caps[bstack1l111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࠫ঎")]
    browser = str(browser).lower()
    if browser == bstack1l111l_opy_ (u"ࠫ࡮ࡶࡨࡰࡰࡨࠫএ") or browser == bstack1l111l_opy_ (u"ࠬ࡯ࡰࡢࡦࠪঐ"):
      browser = bstack1l111l_opy_ (u"࠭ࡳࡢࡨࡤࡶ࡮࠭঑")
    if browser == bstack1l111l_opy_ (u"ࠧࡴࡣࡰࡷࡺࡴࡧࠨ঒"):
      browser = bstack1l111l_opy_ (u"ࠨࡥ࡫ࡶࡴࡳࡥࠨও")
    if browser not in [bstack1l111l_opy_ (u"ࠩࡦ࡬ࡷࡵ࡭ࡦࠩঔ"), bstack1l111l_opy_ (u"ࠪࡩࡩ࡭ࡥࠨক"), bstack1l111l_opy_ (u"ࠫ࡮࡫ࠧখ"), bstack1l111l_opy_ (u"ࠬࡹࡡࡧࡣࡵ࡭ࠬগ"), bstack1l111l_opy_ (u"࠭ࡦࡪࡴࡨࡪࡴࡾࠧঘ")]:
      return None
    try:
      package = bstack1l111l_opy_ (u"ࠧࡴࡧ࡯ࡩࡳ࡯ࡵ࡮࠰ࡺࡩࡧࡪࡲࡪࡸࡨࡶ࠳ࢁࡽ࠯ࡱࡳࡸ࡮ࡵ࡮ࡴࠩঙ").format(browser)
      name = bstack1l111l_opy_ (u"ࠨࡑࡳࡸ࡮ࡵ࡮ࡴࠩচ")
      browser_options = getattr(__import__(package, fromlist=[name]), name)
      options = browser_options()
      if not bstack1ll1l1l111_opy_(options):
        return None
      for bstack11lll111l_opy_ in caps.keys():
        options.set_capability(bstack11lll111l_opy_, caps[bstack11lll111l_opy_])
      bstack1ll1lll1ll_opy_(options, caps)
      return options
    except Exception as e:
      logger.debug(str(e))
      return None
def bstack1111l1lll_opy_(options, bstack1llllllll_opy_):
  if not bstack1ll1l1l111_opy_(options):
    return
  for bstack11lll111l_opy_ in bstack1llllllll_opy_.keys():
    if bstack11lll111l_opy_ in bstack11l11l11l_opy_:
      next
    if bstack11lll111l_opy_ in options._caps and type(options._caps[bstack11lll111l_opy_]) in [dict, list]:
      options._caps[bstack11lll111l_opy_] = update(options._caps[bstack11lll111l_opy_], bstack1llllllll_opy_[bstack11lll111l_opy_])
    else:
      options.set_capability(bstack11lll111l_opy_, bstack1llllllll_opy_[bstack11lll111l_opy_])
  bstack1ll1lll1ll_opy_(options, bstack1llllllll_opy_)
  if bstack1l111l_opy_ (u"ࠩࡰࡳࡿࡀࡤࡦࡤࡸ࡫࡬࡫ࡲࡂࡦࡧࡶࡪࡹࡳࠨছ") in options._caps:
    if options._caps[bstack1l111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡒࡦࡳࡥࠨজ")] and options._caps[bstack1l111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠩঝ")].lower() != bstack1l111l_opy_ (u"ࠬ࡬ࡩࡳࡧࡩࡳࡽ࠭ঞ"):
      del options._caps[bstack1l111l_opy_ (u"࠭࡭ࡰࡼ࠽ࡨࡪࡨࡵࡨࡩࡨࡶࡆࡪࡤࡳࡧࡶࡷࠬট")]
def bstack11l11l1ll_opy_(proxy_config):
  if bstack1l111l_opy_ (u"ࠧࡩࡶࡷࡴࡸࡖࡲࡰࡺࡼࠫঠ") in proxy_config:
    proxy_config[bstack1l111l_opy_ (u"ࠨࡵࡶࡰࡕࡸ࡯ࡹࡻࠪড")] = proxy_config[bstack1l111l_opy_ (u"ࠩ࡫ࡸࡹࡶࡳࡑࡴࡲࡼࡾ࠭ঢ")]
    del (proxy_config[bstack1l111l_opy_ (u"ࠪ࡬ࡹࡺࡰࡴࡒࡵࡳࡽࡿࠧণ")])
  if bstack1l111l_opy_ (u"ࠫࡵࡸ࡯ࡹࡻࡗࡽࡵ࡫ࠧত") in proxy_config and proxy_config[bstack1l111l_opy_ (u"ࠬࡶࡲࡰࡺࡼࡘࡾࡶࡥࠨথ")].lower() != bstack1l111l_opy_ (u"࠭ࡤࡪࡴࡨࡧࡹ࠭দ"):
    proxy_config[bstack1l111l_opy_ (u"ࠧࡱࡴࡲࡼࡾ࡚ࡹࡱࡧࠪধ")] = bstack1l111l_opy_ (u"ࠨ࡯ࡤࡲࡺࡧ࡬ࠨন")
  if bstack1l111l_opy_ (u"ࠩࡳࡶࡴࡾࡹࡂࡷࡷࡳࡨࡵ࡮ࡧ࡫ࡪ࡙ࡷࡲࠧ঩") in proxy_config:
    proxy_config[bstack1l111l_opy_ (u"ࠪࡴࡷࡵࡸࡺࡖࡼࡴࡪ࠭প")] = bstack1l111l_opy_ (u"ࠫࡵࡧࡣࠨফ")
  return proxy_config
def bstack1ll1lll111_opy_(config, proxy):
  from selenium.webdriver.common.proxy import Proxy
  if not bstack1l111l_opy_ (u"ࠬࡶࡲࡰࡺࡼࠫব") in config:
    return proxy
  config[bstack1l111l_opy_ (u"࠭ࡰࡳࡱࡻࡽࠬভ")] = bstack11l11l1ll_opy_(config[bstack1l111l_opy_ (u"ࠧࡱࡴࡲࡼࡾ࠭ম")])
  if proxy == None:
    proxy = Proxy(config[bstack1l111l_opy_ (u"ࠨࡲࡵࡳࡽࡿࠧয")])
  return proxy
def bstack11ll1lll_opy_(self):
  global CONFIG
  global bstack1lllll1111_opy_
  try:
    proxy = bstack1111ll11_opy_(CONFIG)
    if proxy:
      if proxy.endswith(bstack1l111l_opy_ (u"ࠩ࠱ࡴࡦࡩࠧর")):
        proxies = bstack11ll1111_opy_(proxy, bstack111111ll_opy_())
        if len(proxies) > 0:
          protocol, bstack1l111l1ll_opy_ = proxies.popitem()
          if bstack1l111l_opy_ (u"ࠥ࠾࠴࠵ࠢ঱") in bstack1l111l1ll_opy_:
            return bstack1l111l1ll_opy_
          else:
            return bstack1l111l_opy_ (u"ࠦ࡭ࡺࡴࡱ࠼࠲࠳ࠧল") + bstack1l111l1ll_opy_
      else:
        return proxy
  except Exception as e:
    logger.error(bstack1l111l_opy_ (u"ࠧࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡵࡳࡽࡿࠠࡶࡴ࡯ࠤ࠿ࠦࡻࡾࠤ঳").format(str(e)))
  return bstack1lllll1111_opy_(self)
def bstack1ll1ll1l11_opy_():
  global CONFIG
  return bstack1111ll11l_opy_(CONFIG) and bstack111lllll1_opy_() >= version.parse(bstack11llll1l_opy_)
def bstack1111l1ll_opy_(config):
  bstack1ll1ll111l_opy_ = {}
  if bstack1l111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪ঴") in config:
    bstack1ll1ll111l_opy_ = config[bstack1l111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫ঵")]
  if bstack1l111l_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࡏࡱࡶ࡬ࡳࡳࡹࠧশ") in config:
    bstack1ll1ll111l_opy_ = config[bstack1l111l_opy_ (u"ࠩ࡯ࡳࡨࡧ࡬ࡐࡲࡷ࡭ࡴࡴࡳࠨষ")]
  proxy = bstack1111ll11_opy_(config)
  if proxy:
    if proxy.endswith(bstack1l111l_opy_ (u"ࠪ࠲ࡵࡧࡣࠨস")) and os.path.isfile(proxy):
      bstack1ll1ll111l_opy_[bstack1l111l_opy_ (u"ࠫ࠲ࡶࡡࡤ࠯ࡩ࡭ࡱ࡫ࠧহ")] = proxy
    else:
      parsed_url = None
      if proxy.endswith(bstack1l111l_opy_ (u"ࠬ࠴ࡰࡢࡥࠪ঺")):
        proxies = bstack11l1l111_opy_(config, bstack111111ll_opy_())
        if len(proxies) > 0:
          protocol, bstack1l111l1ll_opy_ = proxies.popitem()
          if bstack1l111l_opy_ (u"ࠨ࠺࠰࠱ࠥ঻") in bstack1l111l1ll_opy_:
            parsed_url = urlparse(bstack1l111l1ll_opy_)
          else:
            parsed_url = urlparse(protocol + bstack1l111l_opy_ (u"ࠢ࠻࠱࠲়ࠦ") + bstack1l111l1ll_opy_)
      else:
        parsed_url = urlparse(proxy)
      if parsed_url and parsed_url.hostname: bstack1ll1ll111l_opy_[bstack1l111l_opy_ (u"ࠨࡲࡵࡳࡽࡿࡈࡰࡵࡷࠫঽ")] = str(parsed_url.hostname)
      if parsed_url and parsed_url.port: bstack1ll1ll111l_opy_[bstack1l111l_opy_ (u"ࠩࡳࡶࡴࡾࡹࡑࡱࡵࡸࠬা")] = str(parsed_url.port)
      if parsed_url and parsed_url.username: bstack1ll1ll111l_opy_[bstack1l111l_opy_ (u"ࠪࡴࡷࡵࡸࡺࡗࡶࡩࡷ࠭ি")] = str(parsed_url.username)
      if parsed_url and parsed_url.password: bstack1ll1ll111l_opy_[bstack1l111l_opy_ (u"ࠫࡵࡸ࡯ࡹࡻࡓࡥࡸࡹࠧী")] = str(parsed_url.password)
  return bstack1ll1ll111l_opy_
def bstack1ll11l1ll_opy_(config):
  if bstack1l111l_opy_ (u"ࠬࡺࡥࡴࡶࡆࡳࡳࡺࡥࡹࡶࡒࡴࡹ࡯࡯࡯ࡵࠪু") in config:
    return config[bstack1l111l_opy_ (u"࠭ࡴࡦࡵࡷࡇࡴࡴࡴࡦࡺࡷࡓࡵࡺࡩࡰࡰࡶࠫূ")]
  return {}
def bstack1l111lll_opy_(caps):
  global bstack1ll1ll1ll1_opy_
  if bstack1l111l_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࠺ࡰࡲࡷ࡭ࡴࡴࡳࠨৃ") in caps:
    caps[bstack1l111l_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫࠻ࡱࡳࡸ࡮ࡵ࡮ࡴࠩৄ")][bstack1l111l_opy_ (u"ࠩ࡯ࡳࡨࡧ࡬ࠨ৅")] = True
    if bstack1ll1ll1ll1_opy_:
      caps[bstack1l111l_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭࠽ࡳࡵࡺࡩࡰࡰࡶࠫ৆")][bstack1l111l_opy_ (u"ࠫࡱࡵࡣࡢ࡮ࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭ে")] = bstack1ll1ll1ll1_opy_
  else:
    caps[bstack1l111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡱࡵࡣࡢ࡮ࠪৈ")] = True
    if bstack1ll1ll1ll1_opy_:
      caps[bstack1l111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡲ࡯ࡤࡣ࡯ࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧ৉")] = bstack1ll1ll1ll1_opy_
def bstack1111ll1l1_opy_():
  global CONFIG
  if bstack1l111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࠫ৊") in CONFIG and CONFIG[bstack1l111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡌࡰࡥࡤࡰࠬো")]:
    bstack1ll1ll111l_opy_ = bstack1111l1ll_opy_(CONFIG)
    bstack1l1ll111l_opy_(CONFIG[bstack1l111l_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴࡍࡨࡽࠬৌ")], bstack1ll1ll111l_opy_)
def bstack1l1ll111l_opy_(key, bstack1ll1ll111l_opy_):
  global bstack1l11lllll_opy_
  logger.info(bstack1l1111l11_opy_)
  try:
    bstack1l11lllll_opy_ = Local()
    bstack1ll1l1llll_opy_ = {bstack1l111l_opy_ (u"ࠪ࡯ࡪࡿ্ࠧ"): key}
    bstack1ll1l1llll_opy_.update(bstack1ll1ll111l_opy_)
    logger.debug(bstack11111l1ll_opy_.format(str(bstack1ll1l1llll_opy_)))
    bstack1l11lllll_opy_.start(**bstack1ll1l1llll_opy_)
    if bstack1l11lllll_opy_.isRunning():
      logger.info(bstack1111111l_opy_)
  except Exception as e:
    bstack1ll1lllll_opy_(bstack1lll1ll111_opy_.format(str(e)))
def bstack1l1lll111_opy_():
  global bstack1l11lllll_opy_
  if bstack1l11lllll_opy_.isRunning():
    logger.info(bstack111lll11l_opy_)
    bstack1l11lllll_opy_.stop()
  bstack1l11lllll_opy_ = None
def bstack1l111l11l_opy_(bstack11l11l1l1_opy_=[]):
  global CONFIG
  bstack1111l111_opy_ = []
  bstack1lllllll1_opy_ = [bstack1l111l_opy_ (u"ࠫࡴࡹࠧৎ"), bstack1l111l_opy_ (u"ࠬࡵࡳࡗࡧࡵࡷ࡮ࡵ࡮ࠨ৏"), bstack1l111l_opy_ (u"࠭ࡤࡦࡸ࡬ࡧࡪࡔࡡ࡮ࡧࠪ৐"), bstack1l111l_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡘࡨࡶࡸ࡯࡯࡯ࠩ৑"), bstack1l111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡐࡤࡱࡪ࠭৒"), bstack1l111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪ৓")]
  try:
    for err in bstack11l11l1l1_opy_:
      bstack1lll1l1lll_opy_ = {}
      for k in bstack1lllllll1_opy_:
        val = CONFIG[bstack1l111l_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭৔")][int(err[bstack1l111l_opy_ (u"ࠫ࡮ࡴࡤࡦࡺࠪ৕")])].get(k)
        if val:
          bstack1lll1l1lll_opy_[k] = val
      bstack1lll1l1lll_opy_[bstack1l111l_opy_ (u"ࠬࡺࡥࡴࡶࡶࠫ৖")] = {
        err[bstack1l111l_opy_ (u"࠭࡮ࡢ࡯ࡨࠫৗ")]: err[bstack1l111l_opy_ (u"ࠧࡦࡴࡵࡳࡷ࠭৘")]
      }
      bstack1111l111_opy_.append(bstack1lll1l1lll_opy_)
  except Exception as e:
    logger.debug(bstack1l111l_opy_ (u"ࠨࡇࡵࡶࡴࡸࠠࡪࡰࠣࡪࡴࡸ࡭ࡢࡶࡷ࡭ࡳ࡭ࠠࡥࡣࡷࡥࠥ࡬࡯ࡳࠢࡨࡺࡪࡴࡴ࠻ࠢࠪ৙") + str(e))
  finally:
    return bstack1111l111_opy_
def bstack111111lll_opy_():
  global bstack11l1l111l_opy_
  global bstack1llllllll1_opy_
  global bstack1l1l1lll1_opy_
  if bstack11l1l111l_opy_:
    logger.warning(bstack11l1l11l_opy_.format(str(bstack11l1l111l_opy_)))
  else:
    try:
      bstack111l11l1l_opy_ = bstack11lll11l_opy_(bstack1l111l_opy_ (u"ࠩ࠱ࡦࡸࡺࡡࡤ࡭࠰ࡧࡴࡴࡦࡪࡩ࠱࡮ࡸࡵ࡮ࠨ৚"), logger)
      if bstack111l11l1l_opy_.get(bstack1l111l_opy_ (u"ࠪࡲࡺࡪࡧࡦࡡ࡯ࡳࡨࡧ࡬ࠨ৛")) and bstack111l11l1l_opy_.get(bstack1l111l_opy_ (u"ࠫࡳࡻࡤࡨࡧࡢࡰࡴࡩࡡ࡭ࠩড়")).get(bstack1l111l_opy_ (u"ࠬ࡮࡯ࡴࡶࡱࡥࡲ࡫ࠧঢ়")):
        logger.warning(bstack11l1l11l_opy_.format(str(bstack111l11l1l_opy_[bstack1l111l_opy_ (u"࠭࡮ࡶࡦࡪࡩࡤࡲ࡯ࡤࡣ࡯ࠫ৞")][bstack1l111l_opy_ (u"ࠧࡩࡱࡶࡸࡳࡧ࡭ࡦࠩয়")])))
    except Exception as e:
      logger.error(e)
  logger.info(bstack11ll11ll1_opy_)
  global bstack1l11lllll_opy_
  if bstack1l11lllll_opy_:
    bstack1l1lll111_opy_()
  try:
    for driver in bstack1llllllll1_opy_:
      driver.quit()
  except Exception as e:
    pass
  logger.info(bstack1l1lll1l1_opy_)
  bstack1l1l11ll1_opy_()
  if len(bstack1l1l1lll1_opy_) > 0:
    message = bstack1l111l11l_opy_(bstack1l1l1lll1_opy_)
    bstack1l1l11ll1_opy_(message)
  else:
    bstack1l1l11ll1_opy_()
  bstack1ll11lll1l_opy_(bstack11l1lll1_opy_, logger)
def bstack1lllll1l11_opy_(self, *args):
  logger.error(bstack1lll11lll_opy_)
  bstack111111lll_opy_()
  sys.exit(1)
def bstack1ll1lllll_opy_(err):
  logger.critical(bstack11llllll_opy_.format(str(err)))
  bstack1l1l11ll1_opy_(bstack11llllll_opy_.format(str(err)))
  atexit.unregister(bstack111111lll_opy_)
  sys.exit(1)
def bstack11l11lll_opy_(error, message):
  logger.critical(str(error))
  logger.critical(message)
  bstack1l1l11ll1_opy_(message)
  atexit.unregister(bstack111111lll_opy_)
  sys.exit(1)
def bstack1ll1l1111_opy_():
  global CONFIG
  global bstack1lll11l1l1_opy_
  global bstack111l1ll1_opy_
  global bstack1111l11l1_opy_
  CONFIG = bstack1lll1l11l_opy_()
  bstack1ll1ll11l_opy_()
  bstack1l1l1111_opy_()
  CONFIG = bstack1l1111ll1_opy_(CONFIG)
  update(CONFIG, bstack111l1ll1_opy_)
  update(CONFIG, bstack1lll11l1l1_opy_)
  CONFIG = bstack1l1l1l11_opy_(CONFIG)
  bstack1111l11l1_opy_ = bstack11llll111_opy_(CONFIG)
  bstack1l1ll1ll1_opy_.set_property(bstack1l111l_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫ࡠࡵࡨࡷࡸ࡯࡯࡯ࠩৠ"), bstack1111l11l1_opy_)
  if (bstack1l111l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬৡ") in CONFIG and bstack1l111l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭ৢ") in bstack1lll11l1l1_opy_) or (
          bstack1l111l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠧৣ") in CONFIG and bstack1l111l_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡒࡦࡳࡥࠨ৤") not in bstack111l1ll1_opy_):
    if os.getenv(bstack1l111l_opy_ (u"࠭ࡂࡔࡖࡄࡇࡐࡥࡃࡐࡏࡅࡍࡓࡋࡄࡠࡄࡘࡍࡑࡊ࡟ࡊࡆࠪ৥")):
      CONFIG[bstack1l111l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩ০")] = os.getenv(bstack1l111l_opy_ (u"ࠨࡄࡖࡘࡆࡉࡋࡠࡅࡒࡑࡇࡏࡎࡆࡆࡢࡆ࡚ࡏࡌࡅࡡࡌࡈࠬ১"))
    else:
      bstack11l11l11_opy_()
  elif (bstack1l111l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬ২") not in CONFIG and bstack1l111l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬ৩") in CONFIG) or (
          bstack1l111l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠧ৪") in bstack111l1ll1_opy_ and bstack1l111l_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡒࡦࡳࡥࠨ৫") not in bstack1lll11l1l1_opy_):
    del (CONFIG[bstack1l111l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨ৬")])
  if bstack11111llll_opy_(CONFIG):
    bstack1ll1lllll_opy_(bstack11ll1111l_opy_)
  bstack1llll11l1_opy_()
  bstack1llll11l11_opy_()
  if bstack1ll111l11_opy_:
    CONFIG[bstack1l111l_opy_ (u"ࠧࡢࡲࡳࠫ৭")] = bstack1l1ll11ll_opy_(CONFIG)
    logger.info(bstack1l1ll1111_opy_.format(CONFIG[bstack1l111l_opy_ (u"ࠨࡣࡳࡴࠬ৮")]))
def bstack1lll11ll1l_opy_(config, bstack1llll11lll_opy_):
  global CONFIG
  global bstack1ll111l11_opy_
  CONFIG = config
  bstack1ll111l11_opy_ = bstack1llll11lll_opy_
def bstack1llll11l11_opy_():
  global CONFIG
  global bstack1ll111l11_opy_
  if bstack1l111l_opy_ (u"ࠩࡤࡴࡵ࠭৯") in CONFIG:
    try:
      from appium import version
    except Exception as e:
      bstack11l11lll_opy_(e, bstack111111l1_opy_)
    bstack1ll111l11_opy_ = True
    bstack1l1ll1ll1_opy_.set_property(bstack1l111l_opy_ (u"ࠪࡥࡵࡶ࡟ࡢࡷࡷࡳࡲࡧࡴࡦࠩৰ"), True)
def bstack1l1ll11ll_opy_(config):
  bstack11lllll1l_opy_ = bstack1l111l_opy_ (u"ࠫࠬৱ")
  app = config[bstack1l111l_opy_ (u"ࠬࡧࡰࡱࠩ৲")]
  if isinstance(app, str):
    if os.path.splitext(app)[1] in bstack111l11ll1_opy_:
      if os.path.exists(app):
        bstack11lllll1l_opy_ = bstack11lll1111_opy_(config, app)
      elif bstack11l11111_opy_(app):
        bstack11lllll1l_opy_ = app
      else:
        bstack1ll1lllll_opy_(bstack1ll1llllll_opy_.format(app))
    else:
      if bstack11l11111_opy_(app):
        bstack11lllll1l_opy_ = app
      elif os.path.exists(app):
        bstack11lllll1l_opy_ = bstack11lll1111_opy_(app)
      else:
        bstack1ll1lllll_opy_(bstack1ll1l1ll11_opy_)
  else:
    if len(app) > 2:
      bstack1ll1lllll_opy_(bstack1l1llll1l_opy_)
    elif len(app) == 2:
      if bstack1l111l_opy_ (u"࠭ࡰࡢࡶ࡫ࠫ৳") in app and bstack1l111l_opy_ (u"ࠧࡤࡷࡶࡸࡴࡳ࡟ࡪࡦࠪ৴") in app:
        if os.path.exists(app[bstack1l111l_opy_ (u"ࠨࡲࡤࡸ࡭࠭৵")]):
          bstack11lllll1l_opy_ = bstack11lll1111_opy_(config, app[bstack1l111l_opy_ (u"ࠩࡳࡥࡹ࡮ࠧ৶")], app[bstack1l111l_opy_ (u"ࠪࡧࡺࡹࡴࡰ࡯ࡢ࡭ࡩ࠭৷")])
        else:
          bstack1ll1lllll_opy_(bstack1ll1llllll_opy_.format(app))
      else:
        bstack1ll1lllll_opy_(bstack1l1llll1l_opy_)
    else:
      for key in app:
        if key in bstack1lll11ll1_opy_:
          if key == bstack1l111l_opy_ (u"ࠫࡵࡧࡴࡩࠩ৸"):
            if os.path.exists(app[key]):
              bstack11lllll1l_opy_ = bstack11lll1111_opy_(config, app[key])
            else:
              bstack1ll1lllll_opy_(bstack1ll1llllll_opy_.format(app))
          else:
            bstack11lllll1l_opy_ = app[key]
        else:
          bstack1ll1lllll_opy_(bstack1ll1ll1l1_opy_)
  return bstack11lllll1l_opy_
def bstack11l11111_opy_(bstack11lllll1l_opy_):
  import re
  bstack1ll1lll1l1_opy_ = re.compile(bstack1l111l_opy_ (u"ࡷࠨ࡞࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡠࡤ࠴࡜࠮࡟࠭ࠨࠧ৹"))
  bstack1l1ll111_opy_ = re.compile(bstack1l111l_opy_ (u"ࡸࠢ࡟࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࡡࡥ࠮࡝࠯ࡠ࠮࠴ࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺࡞ࡢ࠲ࡡ࠳࡝ࠫࠦࠥ৺"))
  if bstack1l111l_opy_ (u"ࠧࡣࡵ࠽࠳࠴࠭৻") in bstack11lllll1l_opy_ or re.fullmatch(bstack1ll1lll1l1_opy_, bstack11lllll1l_opy_) or re.fullmatch(bstack1l1ll111_opy_, bstack11lllll1l_opy_):
    return True
  else:
    return False
def bstack11lll1111_opy_(config, path, bstack1l1ll1ll_opy_=None):
  import requests
  from requests_toolbelt.multipart.encoder import MultipartEncoder
  import hashlib
  md5_hash = hashlib.md5(open(os.path.abspath(path), bstack1l111l_opy_ (u"ࠨࡴࡥࠫৼ")).read()).hexdigest()
  bstack11111111l_opy_ = bstack1lll1ll1l_opy_(md5_hash)
  bstack11lllll1l_opy_ = None
  if bstack11111111l_opy_:
    logger.info(bstack1ll1ll1lll_opy_.format(bstack11111111l_opy_, md5_hash))
    return bstack11111111l_opy_
  bstack11llllll1_opy_ = MultipartEncoder(
    fields={
      bstack1l111l_opy_ (u"ࠩࡩ࡭ࡱ࡫ࠧ৽"): (os.path.basename(path), open(os.path.abspath(path), bstack1l111l_opy_ (u"ࠪࡶࡧ࠭৾")), bstack1l111l_opy_ (u"ࠫࡹ࡫ࡸࡵ࠱ࡳࡰࡦ࡯࡮ࠨ৿")),
      bstack1l111l_opy_ (u"ࠬࡩࡵࡴࡶࡲࡱࡤ࡯ࡤࠨ਀"): bstack1l1ll1ll_opy_
    }
  )
  response = requests.post(bstack11111l1l_opy_, data=bstack11llllll1_opy_,
                           headers={bstack1l111l_opy_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬਁ"): bstack11llllll1_opy_.content_type},
                           auth=(config[bstack1l111l_opy_ (u"ࠧࡶࡵࡨࡶࡓࡧ࡭ࡦࠩਂ")], config[bstack1l111l_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡌࡧࡼࠫਃ")]))
  try:
    res = json.loads(response.text)
    bstack11lllll1l_opy_ = res[bstack1l111l_opy_ (u"ࠩࡤࡴࡵࡥࡵࡳ࡮ࠪ਄")]
    logger.info(bstack11l11l111_opy_.format(bstack11lllll1l_opy_))
    bstack11lll11l1_opy_(md5_hash, bstack11lllll1l_opy_)
  except ValueError as err:
    bstack1ll1lllll_opy_(bstack1l1llll1_opy_.format(str(err)))
  return bstack11lllll1l_opy_
def bstack1llll11l1_opy_():
  global CONFIG
  global bstack1l1lll11_opy_
  bstack1lll1ll11l_opy_ = 0
  bstack1lll1111l_opy_ = 1
  if bstack1l111l_opy_ (u"ࠪࡴࡦࡸࡡ࡭࡮ࡨࡰࡸࡖࡥࡳࡒ࡯ࡥࡹ࡬࡯ࡳ࡯ࠪਅ") in CONFIG:
    bstack1lll1111l_opy_ = CONFIG[bstack1l111l_opy_ (u"ࠫࡵࡧࡲࡢ࡮࡯ࡩࡱࡹࡐࡦࡴࡓࡰࡦࡺࡦࡰࡴࡰࠫਆ")]
  if bstack1l111l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨਇ") in CONFIG:
    bstack1lll1ll11l_opy_ = len(CONFIG[bstack1l111l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩਈ")])
  bstack1l1lll11_opy_ = int(bstack1lll1111l_opy_) * int(bstack1lll1ll11l_opy_)
def bstack1lll1ll1l_opy_(md5_hash):
  bstack1ll1l11l11_opy_ = os.path.join(os.path.expanduser(bstack1l111l_opy_ (u"ࠧࡿࠩਉ")), bstack1l111l_opy_ (u"ࠨ࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࠨਊ"), bstack1l111l_opy_ (u"ࠩࡤࡴࡵ࡛ࡰ࡭ࡱࡤࡨࡒࡊ࠵ࡉࡣࡶ࡬࠳ࡰࡳࡰࡰࠪ਋"))
  if os.path.exists(bstack1ll1l11l11_opy_):
    bstack1l111ll1_opy_ = json.load(open(bstack1ll1l11l11_opy_, bstack1l111l_opy_ (u"ࠪࡶࡧ࠭਌")))
    if md5_hash in bstack1l111ll1_opy_:
      bstack1ll1l1l11l_opy_ = bstack1l111ll1_opy_[md5_hash]
      bstack11l1lllll_opy_ = datetime.datetime.now()
      bstack1ll1lll1l_opy_ = datetime.datetime.strptime(bstack1ll1l1l11l_opy_[bstack1l111l_opy_ (u"ࠫࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠧ਍")], bstack1l111l_opy_ (u"ࠬࠫࡤ࠰ࠧࡰ࠳ࠪ࡟ࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠩ਎"))
      if (bstack11l1lllll_opy_ - bstack1ll1lll1l_opy_).days > 60:
        return None
      elif version.parse(str(__version__)) > version.parse(bstack1ll1l1l11l_opy_[bstack1l111l_opy_ (u"࠭ࡳࡥ࡭ࡢࡺࡪࡸࡳࡪࡱࡱࠫਏ")]):
        return None
      return bstack1ll1l1l11l_opy_[bstack1l111l_opy_ (u"ࠧࡪࡦࠪਐ")]
  else:
    return None
def bstack11lll11l1_opy_(md5_hash, bstack11lllll1l_opy_):
  bstack1l1l1l1l_opy_ = os.path.join(os.path.expanduser(bstack1l111l_opy_ (u"ࠨࢀࠪ਑")), bstack1l111l_opy_ (u"ࠩ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠩ਒"))
  if not os.path.exists(bstack1l1l1l1l_opy_):
    os.makedirs(bstack1l1l1l1l_opy_)
  bstack1ll1l11l11_opy_ = os.path.join(os.path.expanduser(bstack1l111l_opy_ (u"ࠪࢂࠬਓ")), bstack1l111l_opy_ (u"ࠫ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠫਔ"), bstack1l111l_opy_ (u"ࠬࡧࡰࡱࡗࡳࡰࡴࡧࡤࡎࡆ࠸ࡌࡦࡹࡨ࠯࡬ࡶࡳࡳ࠭ਕ"))
  bstack11l11111l_opy_ = {
    bstack1l111l_opy_ (u"࠭ࡩࡥࠩਖ"): bstack11lllll1l_opy_,
    bstack1l111l_opy_ (u"ࠧࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪਗ"): datetime.datetime.strftime(datetime.datetime.now(), bstack1l111l_opy_ (u"ࠨࠧࡧ࠳ࠪࡳ࠯࡛ࠦࠣࠩࡍࡀࠥࡎ࠼ࠨࡗࠬਘ")),
    bstack1l111l_opy_ (u"ࠩࡶࡨࡰࡥࡶࡦࡴࡶ࡭ࡴࡴࠧਙ"): str(__version__)
  }
  if os.path.exists(bstack1ll1l11l11_opy_):
    bstack1l111ll1_opy_ = json.load(open(bstack1ll1l11l11_opy_, bstack1l111l_opy_ (u"ࠪࡶࡧ࠭ਚ")))
  else:
    bstack1l111ll1_opy_ = {}
  bstack1l111ll1_opy_[md5_hash] = bstack11l11111l_opy_
  with open(bstack1ll1l11l11_opy_, bstack1l111l_opy_ (u"ࠦࡼ࠱ࠢਛ")) as outfile:
    json.dump(bstack1l111ll1_opy_, outfile)
def bstack111llll11_opy_(self):
  return
def bstack11111lll1_opy_(self):
  return
def bstack11lll1l11_opy_(self):
  from selenium.webdriver.remote.webdriver import WebDriver
  WebDriver.quit(self)
def bstack1ll1l11lll_opy_(self):
  global bstack111111ll1_opy_
  global bstack111ll11l1_opy_
  global bstack1lllllll1l_opy_
  try:
    if bstack1l111l_opy_ (u"ࠬࡶࡹࡵࡧࡶࡸࠬਜ") in bstack111111ll1_opy_ and self.session_id != None:
      bstack1ll1l1l1ll_opy_ = bstack1l111l_opy_ (u"࠭ࡰࡢࡵࡶࡩࡩ࠭ਝ") if len(threading.current_thread().bstackTestErrorMessages) == 0 else bstack1l111l_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧਞ")
      bstack11111lll_opy_ = bstack1ll111lll_opy_(bstack1l111l_opy_ (u"ࠨࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡘࡺࡡࡵࡷࡶࠫਟ"), bstack1l111l_opy_ (u"ࠩࠪਠ"), bstack1ll1l1l1ll_opy_, bstack1l111l_opy_ (u"ࠪ࠰ࠥ࠭ਡ").join(
        threading.current_thread().bstackTestErrorMessages), bstack1l111l_opy_ (u"ࠫࠬਢ"), bstack1l111l_opy_ (u"ࠬ࠭ਣ"))
      if self != None:
        self.execute_script(bstack11111lll_opy_)
  except Exception as e:
    logger.debug(bstack1l111l_opy_ (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡨࡪ࡮ࡨࠤࡲࡧࡲ࡬࡫ࡱ࡫ࠥࡹࡴࡢࡶࡸࡷ࠿ࠦࠢਤ") + str(e))
  bstack1lllllll1l_opy_(self)
  self.session_id = None
def bstack111l1l11l_opy_(self, *args, **kwargs):
  bstack1l1l1ll1l_opy_ = bstack11lll1l1_opy_(self, *args, **kwargs)
  bstack1lllll111_opy_.bstack1l11l1l11_opy_(self)
  return bstack1l1l1ll1l_opy_
def bstack1ll1l1lll1_opy_(self, command_executor,
             desired_capabilities=None, browser_profile=None, proxy=None,
             keep_alive=True, file_detector=None, options=None):
  global CONFIG
  global bstack111ll11l1_opy_
  global bstack11l1111l_opy_
  global bstack11ll1l111_opy_
  global bstack1lll1l111_opy_
  global bstack1l1l11111_opy_
  global bstack111111ll1_opy_
  global bstack11lll1l1_opy_
  global bstack1llllllll1_opy_
  global bstack111l1l1l_opy_
  CONFIG[bstack1l111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࡙ࡄࡌࠩਥ")] = str(bstack111111ll1_opy_) + str(__version__)
  command_executor = bstack111111ll_opy_()
  logger.debug(bstack1llllll1l1_opy_.format(command_executor))
  proxy = bstack1ll1lll111_opy_(CONFIG, proxy)
  bstack1l1lll1ll_opy_ = 0 if bstack11l1111l_opy_ < 0 else bstack11l1111l_opy_
  try:
    if bstack1lll1l111_opy_ is True:
      bstack1l1lll1ll_opy_ = int(multiprocessing.current_process().name)
    elif bstack1l1l11111_opy_ is True:
      bstack1l1lll1ll_opy_ = int(threading.current_thread().name)
  except:
    bstack1l1lll1ll_opy_ = 0
  bstack1llllllll_opy_ = bstack1ll111111_opy_(CONFIG, bstack1l1lll1ll_opy_)
  logger.debug(bstack1l1l1ll11_opy_.format(str(bstack1llllllll_opy_)))
  if bstack1l111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡌࡰࡥࡤࡰࠬਦ") in CONFIG and CONFIG[bstack1l111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡍࡱࡦࡥࡱ࠭ਧ")]:
    bstack1l111lll_opy_(bstack1llllllll_opy_)
  if desired_capabilities:
    bstack1lllllll11_opy_ = bstack1l1111ll1_opy_(desired_capabilities)
    bstack1lllllll11_opy_[bstack1l111l_opy_ (u"ࠪࡹࡸ࡫ࡗ࠴ࡅࠪਨ")] = bstack111111l11_opy_(CONFIG)
    bstack1l1l1ll1_opy_ = bstack1ll111111_opy_(bstack1lllllll11_opy_)
    if bstack1l1l1ll1_opy_:
      bstack1llllllll_opy_ = update(bstack1l1l1ll1_opy_, bstack1llllllll_opy_)
    desired_capabilities = None
  if options:
    bstack1111l1lll_opy_(options, bstack1llllllll_opy_)
  if not options:
    options = bstack11ll11ll_opy_(bstack1llllllll_opy_)
  if proxy and bstack111lllll1_opy_() >= version.parse(bstack1l111l_opy_ (u"ࠫ࠹࠴࠱࠱࠰࠳ࠫ਩")):
    options.proxy(proxy)
  if options and bstack111lllll1_opy_() >= version.parse(bstack1l111l_opy_ (u"ࠬ࠹࠮࠹࠰࠳ࠫਪ")):
    desired_capabilities = None
  if (
          not options and not desired_capabilities
  ) or (
          bstack111lllll1_opy_() < version.parse(bstack1l111l_opy_ (u"࠭࠳࠯࠺࠱࠴ࠬਫ")) and not desired_capabilities
  ):
    desired_capabilities = {}
    desired_capabilities.update(bstack1llllllll_opy_)
  logger.info(bstack11l1l1l11_opy_)
  if bstack111lllll1_opy_() >= version.parse(bstack1l111l_opy_ (u"ࠧ࠵࠰࠴࠴࠳࠶ࠧਬ")):
    bstack11lll1l1_opy_(self, command_executor=command_executor,
              options=options, keep_alive=keep_alive, file_detector=file_detector)
  elif bstack111lllll1_opy_() >= version.parse(bstack1l111l_opy_ (u"ࠨ࠵࠱࠼࠳࠶ࠧਭ")):
    bstack11lll1l1_opy_(self, command_executor=command_executor,
              desired_capabilities=desired_capabilities, options=options,
              browser_profile=browser_profile, proxy=proxy,
              keep_alive=keep_alive, file_detector=file_detector)
  elif bstack111lllll1_opy_() >= version.parse(bstack1l111l_opy_ (u"ࠩ࠵࠲࠺࠹࠮࠱ࠩਮ")):
    bstack11lll1l1_opy_(self, command_executor=command_executor,
              desired_capabilities=desired_capabilities,
              browser_profile=browser_profile, proxy=proxy,
              keep_alive=keep_alive, file_detector=file_detector)
  else:
    bstack11lll1l1_opy_(self, command_executor=command_executor,
              desired_capabilities=desired_capabilities,
              browser_profile=browser_profile, proxy=proxy,
              keep_alive=keep_alive)
  try:
    bstack1llll1llll_opy_ = bstack1l111l_opy_ (u"ࠪࠫਯ")
    if bstack111lllll1_opy_() >= version.parse(bstack1l111l_opy_ (u"ࠫ࠹࠴࠰࠯࠲ࡥ࠵ࠬਰ")):
      bstack1llll1llll_opy_ = self.caps.get(bstack1l111l_opy_ (u"ࠧࡵࡰࡵ࡫ࡰࡥࡱࡎࡵࡣࡗࡵࡰࠧ਱"))
    else:
      bstack1llll1llll_opy_ = self.capabilities.get(bstack1l111l_opy_ (u"ࠨ࡯ࡱࡶ࡬ࡱࡦࡲࡈࡶࡤࡘࡶࡱࠨਲ"))
    if bstack1llll1llll_opy_:
      if bstack111lllll1_opy_() <= version.parse(bstack1l111l_opy_ (u"ࠧ࠴࠰࠴࠷࠳࠶ࠧਲ਼")):
        self.command_executor._url = bstack1l111l_opy_ (u"ࠣࡪࡷࡸࡵࡀ࠯࠰ࠤ਴") + bstack1ll11lll1_opy_ + bstack1l111l_opy_ (u"ࠤ࠽࠼࠵࠵ࡷࡥ࠱࡫ࡹࡧࠨਵ")
      else:
        self.command_executor._url = bstack1l111l_opy_ (u"ࠥ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠧਸ਼") + bstack1llll1llll_opy_ + bstack1l111l_opy_ (u"ࠦ࠴ࡽࡤ࠰ࡪࡸࡦࠧ਷")
      logger.debug(bstack1llll1lll1_opy_.format(bstack1llll1llll_opy_))
    else:
      logger.debug(bstack11lllll1_opy_.format(bstack1l111l_opy_ (u"ࠧࡕࡰࡵ࡫ࡰࡥࡱࠦࡈࡶࡤࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠨਸ")))
  except Exception as e:
    logger.debug(bstack11lllll1_opy_.format(e))
  if bstack1l111l_opy_ (u"࠭ࡲࡰࡤࡲࡸࠬਹ") in bstack111111ll1_opy_:
    bstack1ll1l111l_opy_(bstack11l1111l_opy_, bstack111l1l1l_opy_)
  bstack111ll11l1_opy_ = self.session_id
  if bstack1l111l_opy_ (u"ࠧࡱࡻࡷࡩࡸࡺࠧ਺") in bstack111111ll1_opy_ or bstack1l111l_opy_ (u"ࠨࡤࡨ࡬ࡦࡼࡥࠨ਻") in bstack111111ll1_opy_:
    threading.current_thread().bstack1111l11l_opy_ = self.session_id
    threading.current_thread().bstackSessionDriver = self
    threading.current_thread().bstackTestErrorMessages = []
    bstack1lllll111_opy_.bstack1l11l1l11_opy_(self)
  bstack1llllllll1_opy_.append(self)
  if bstack1l111l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷ਼ࠬ") in CONFIG and bstack1l111l_opy_ (u"ࠪࡷࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠨ਽") in CONFIG[bstack1l111l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧਾ")][bstack1l1lll1ll_opy_]:
    bstack11ll1l111_opy_ = CONFIG[bstack1l111l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨਿ")][bstack1l1lll1ll_opy_][bstack1l111l_opy_ (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࡎࡢ࡯ࡨࠫੀ")]
  logger.debug(bstack11111ll1_opy_.format(bstack111ll11l1_opy_))
try:
  try:
    import Browser
    from subprocess import Popen
    def bstack11111111_opy_(self, args, bufsize=-1, executable=None,
              stdin=None, stdout=None, stderr=None,
              preexec_fn=None, close_fds=True,
              shell=False, cwd=None, env=None, universal_newlines=None,
              startupinfo=None, creationflags=0,
              restore_signals=True, start_new_session=False,
              pass_fds=(), *, user=None, group=None, extra_groups=None,
              encoding=None, errors=None, text=None, umask=-1, pipesize=-1):
      global CONFIG
      global bstack111l11l1_opy_
      if(bstack1l111l_opy_ (u"ࠢࡪࡰࡧࡩࡽ࠴ࡪࡴࠤੁ") in args[1]):
        with open(os.path.join(os.path.expanduser(bstack1l111l_opy_ (u"ࠨࢀࠪੂ")), bstack1l111l_opy_ (u"ࠩ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠩ੃"), bstack1l111l_opy_ (u"ࠪ࠲ࡸ࡫ࡳࡴ࡫ࡲࡲ࡮ࡪࡳ࠯ࡶࡻࡸࠬ੄")), bstack1l111l_opy_ (u"ࠫࡼ࠭੅")) as fp:
          fp.write(bstack1l111l_opy_ (u"ࠧࠨ੆"))
        if(not os.path.exists(os.path.join(os.path.dirname(args[1]), bstack1l111l_opy_ (u"ࠨࡩ࡯ࡦࡨࡼࡤࡨࡳࡵࡣࡦ࡯࠳ࡰࡳࠣੇ")))):
          with open(args[1], bstack1l111l_opy_ (u"ࠧࡳࠩੈ")) as f:
            lines = f.readlines()
            index = next((i for i, line in enumerate(lines) if bstack1l111l_opy_ (u"ࠨࡣࡶࡽࡳࡩࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡢࡲࡪࡽࡐࡢࡩࡨࠬࡨࡵ࡮ࡵࡧࡻࡸ࠱ࠦࡰࡢࡩࡨࠤࡂࠦࡶࡰ࡫ࡧࠤ࠵࠯ࠧ੉") in line), None)
            if index is not None:
                lines.insert(index+2, bstack11l1111ll_opy_)
            lines.insert(1, bstack1lll1lllll_opy_)
            f.seek(0)
            with open(os.path.join(os.path.dirname(args[1]), bstack1l111l_opy_ (u"ࠤ࡬ࡲࡩ࡫ࡸࡠࡤࡶࡸࡦࡩ࡫࠯࡬ࡶࠦ੊")), bstack1l111l_opy_ (u"ࠪࡻࠬੋ")) as bstack11lll111_opy_:
              bstack11lll111_opy_.writelines(lines)
        CONFIG[bstack1l111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡖࡈࡐ࠭ੌ")] = str(bstack111111ll1_opy_) + str(__version__)
        bstack1l1lll1ll_opy_ = 0 if bstack11l1111l_opy_ < 0 else bstack11l1111l_opy_
        try:
          if bstack1lll1l111_opy_ is True:
            bstack1l1lll1ll_opy_ = int(multiprocessing.current_process().name)
          elif bstack1l1l11111_opy_ is True:
            bstack1l1lll1ll_opy_ = int(threading.current_thread().name)
        except:
          bstack1l1lll1ll_opy_ = 0
        CONFIG[bstack1l111l_opy_ (u"ࠧࡻࡳࡦ࡙࠶ࡇ੍ࠧ")] = False
        CONFIG[bstack1l111l_opy_ (u"ࠨࡩࡴࡒ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸࠧ੎")] = True
        bstack1llllllll_opy_ = bstack1ll111111_opy_(CONFIG, bstack1l1lll1ll_opy_)
        logger.debug(bstack1l1l1ll11_opy_.format(str(bstack1llllllll_opy_)))
        if CONFIG[bstack1l111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࠫ੏")]:
          bstack1l111lll_opy_(bstack1llllllll_opy_)
        if bstack1l111l_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫ੐") in CONFIG and bstack1l111l_opy_ (u"ࠩࡶࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠧੑ") in CONFIG[bstack1l111l_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭੒")][bstack1l1lll1ll_opy_]:
          bstack11ll1l111_opy_ = CONFIG[bstack1l111l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧ੓")][bstack1l1lll1ll_opy_][bstack1l111l_opy_ (u"ࠬࡹࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠪ੔")]
        args.append(os.path.join(os.path.expanduser(bstack1l111l_opy_ (u"࠭ࡾࠨ੕")), bstack1l111l_opy_ (u"ࠧ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧ੖"), bstack1l111l_opy_ (u"ࠨ࠰ࡶࡩࡸࡹࡩࡰࡰ࡬ࡨࡸ࠴ࡴࡹࡶࠪ੗")))
        args.append(str(threading.get_ident()))
        args.append(json.dumps(bstack1llllllll_opy_))
        args[1] = os.path.join(os.path.dirname(args[1]), bstack1l111l_opy_ (u"ࠤ࡬ࡲࡩ࡫ࡸࡠࡤࡶࡸࡦࡩ࡫࠯࡬ࡶࠦ੘"))
      bstack111l11l1_opy_ = True
      return bstack1l11111ll_opy_(self, args, bufsize=bufsize, executable=executable,
                    stdin=stdin, stdout=stdout, stderr=stderr,
                    preexec_fn=preexec_fn, close_fds=close_fds,
                    shell=shell, cwd=cwd, env=env, universal_newlines=universal_newlines,
                    startupinfo=startupinfo, creationflags=creationflags,
                    restore_signals=restore_signals, start_new_session=start_new_session,
                    pass_fds=pass_fds, user=user, group=group, extra_groups=extra_groups,
                    encoding=encoding, errors=errors, text=text, umask=umask, pipesize=pipesize)
  except Exception as e:
    pass
  import playwright._impl._api_structures
  import playwright._impl._helper
  def bstack111l11ll_opy_(self,
        executablePath = None,
        channel = None,
        args = None,
        ignoreDefaultArgs = None,
        handleSIGINT = None,
        handleSIGTERM = None,
        handleSIGHUP = None,
        timeout = None,
        env = None,
        headless = None,
        devtools = None,
        proxy = None,
        downloadsPath = None,
        slowMo = None,
        tracesDir = None,
        chromiumSandbox = None,
        firefoxUserPrefs = None
        ):
    global CONFIG
    global bstack11l1111l_opy_
    global bstack11ll1l111_opy_
    global bstack1lll1l111_opy_
    global bstack1l1l11111_opy_
    global bstack111111ll1_opy_
    CONFIG[bstack1l111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡕࡇࡏࠬਖ਼")] = str(bstack111111ll1_opy_) + str(__version__)
    bstack1l1lll1ll_opy_ = 0 if bstack11l1111l_opy_ < 0 else bstack11l1111l_opy_
    try:
      if bstack1lll1l111_opy_ is True:
        bstack1l1lll1ll_opy_ = int(multiprocessing.current_process().name)
      elif bstack1l1l11111_opy_ is True:
        bstack1l1lll1ll_opy_ = int(threading.current_thread().name)
    except:
      bstack1l1lll1ll_opy_ = 0
    CONFIG[bstack1l111l_opy_ (u"ࠦ࡮ࡹࡐ࡭ࡣࡼࡻࡷ࡯ࡧࡩࡶࠥਗ਼")] = True
    bstack1llllllll_opy_ = bstack1ll111111_opy_(CONFIG, bstack1l1lll1ll_opy_)
    logger.debug(bstack1l1l1ll11_opy_.format(str(bstack1llllllll_opy_)))
    if CONFIG[bstack1l111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࠩਜ਼")]:
      bstack1l111lll_opy_(bstack1llllllll_opy_)
    if bstack1l111l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩੜ") in CONFIG and bstack1l111l_opy_ (u"ࠧࡴࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠬ੝") in CONFIG[bstack1l111l_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫਫ਼")][bstack1l1lll1ll_opy_]:
      bstack11ll1l111_opy_ = CONFIG[bstack1l111l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬ੟")][bstack1l1lll1ll_opy_][bstack1l111l_opy_ (u"ࠪࡷࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠨ੠")]
    import urllib
    import json
    bstack1ll1lll11_opy_ = bstack1l111l_opy_ (u"ࠫࡼࡹࡳ࠻࠱࠲ࡧࡩࡶ࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡣࡰ࡯࠲ࡴࡱࡧࡹࡸࡴ࡬࡫࡭ࡺ࠿ࡤࡣࡳࡷࡂ࠭੡") + urllib.parse.quote(json.dumps(bstack1llllllll_opy_))
    browser = self.connect(bstack1ll1lll11_opy_)
    return browser
except Exception as e:
    pass
def bstack1lll1llll_opy_():
    global bstack111l11l1_opy_
    try:
        from playwright._impl._browser_type import BrowserType
        BrowserType.launch = bstack111l11ll_opy_
        bstack111l11l1_opy_ = True
    except Exception as e:
        pass
    try:
      import Browser
      from subprocess import Popen
      Popen.__init__ = bstack11111111_opy_
      bstack111l11l1_opy_ = True
    except Exception as e:
      pass
def bstack11l1111l1_opy_(context, bstack1111lll11_opy_):
  try:
    context.page.evaluate(bstack1l111l_opy_ (u"ࠧࡥࠠ࠾ࡀࠣࡿࢂࠨ੢"), bstack1l111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࠥࡥࡨࡺࡩࡰࡰࠥ࠾ࠥࠨࡳࡦࡶࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠢ࠭ࠢࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ࠺ࠡࡽࠥࡲࡦࡳࡥࠣ࠼ࠪ੣")+ json.dumps(bstack1111lll11_opy_) + bstack1l111l_opy_ (u"ࠢࡾࡿࠥ੤"))
  except Exception as e:
    logger.debug(bstack1l111l_opy_ (u"ࠣࡧࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡱ࡮ࡤࡽࡼࡸࡩࡨࡪࡷࠤࡸ࡫ࡳࡴ࡫ࡲࡲࠥࡴࡡ࡮ࡧࠣࡿࢂࠨ੥"), e)
def bstack111llll1_opy_(context, message, level):
  try:
    context.page.evaluate(bstack1l111l_opy_ (u"ࠤࡢࠤࡂࡄࠠࡼࡿࠥ੦"), bstack1l111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡥࡳࡴ࡯ࡵࡣࡷࡩࠧ࠲ࠠࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ࠿ࠦࡻࠣࡦࡤࡸࡦࠨ࠺ࠨ੧") + json.dumps(message) + bstack1l111l_opy_ (u"ࠫ࠱ࠨ࡬ࡦࡸࡨࡰࠧࡀࠧ੨") + json.dumps(level) + bstack1l111l_opy_ (u"ࠬࢃࡽࠨ੩"))
  except Exception as e:
    logger.debug(bstack1l111l_opy_ (u"ࠨࡥࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥࡶ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵࠢࡤࡲࡳࡵࡴࡢࡶ࡬ࡳࡳࠦࡻࡾࠤ੪"), e)
def bstack1lll1l1l1l_opy_(context, status, message = bstack1l111l_opy_ (u"ࠢࠣ੫")):
  try:
    if(status == bstack1l111l_opy_ (u"ࠣࡨࡤ࡭ࡱ࡫ࡤࠣ੬")):
      context.page.evaluate(bstack1l111l_opy_ (u"ࠤࡢࠤࡂࡄࠠࡼࡿࠥ੭"), bstack1l111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡷࡪࡺࡓࡦࡵࡶ࡭ࡴࡴࡓࡵࡣࡷࡹࡸࠨࠬࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼࠤࡵࡩࡦࡹ࡯࡯ࠤ࠽ࠫ੮") + json.dumps(bstack1l111l_opy_ (u"ࠦࡘࡩࡥ࡯ࡣࡵ࡭ࡴࠦࡦࡢ࡫࡯ࡩࡩࠦࡷࡪࡶ࡫࠾ࠥࠨ੯") + str(message)) + bstack1l111l_opy_ (u"ࠬ࠲ࠢࡴࡶࡤࡸࡺࡹࠢ࠻ࠩੰ") + json.dumps(status) + bstack1l111l_opy_ (u"ࠨࡽࡾࠤੱ"))
    else:
      context.page.evaluate(bstack1l111l_opy_ (u"ࠢࡠࠢࡀࡂࠥࢁࡽࠣੲ"), bstack1l111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࠧࡧࡣࡵ࡫ࡲࡲࠧࡀࠠࠣࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡘࡺࡡࡵࡷࡶࠦ࠱ࠦࠢࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠥ࠾ࠥࢁࠢࡴࡶࡤࡸࡺࡹࠢ࠻ࠩੳ") + json.dumps(status) + bstack1l111l_opy_ (u"ࠤࢀࢁࠧੴ"))
  except Exception as e:
    logger.debug(bstack1l111l_opy_ (u"ࠥࡩࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡳࡰࡦࡿࡷࡳ࡫ࡪ࡬ࡹࠦࡳࡦࡶࠣࡷࡪࡹࡳࡪࡱࡱࠤࡸࡺࡡࡵࡷࡶࠤࢀࢃࠢੵ"), e)
def bstack1l111111l_opy_(self, url):
  global bstack11ll11111_opy_
  try:
    bstack1lllll1l1_opy_(url)
  except Exception as err:
    logger.debug(bstack11ll1ll1_opy_.format(str(err)))
  try:
    bstack11ll11111_opy_(self, url)
  except Exception as e:
    try:
      bstack1lllll111l_opy_ = str(e)
      if any(err_msg in bstack1lllll111l_opy_ for err_msg in bstack111ll111l_opy_):
        bstack1lllll1l1_opy_(url, True)
    except Exception as err:
      logger.debug(bstack11ll1ll1_opy_.format(str(err)))
    raise e
def bstack111ll1l1_opy_(self):
  global bstack111l1l11_opy_
  bstack111l1l11_opy_ = self
  return
def bstack1l11l11l1_opy_(self):
  global bstack1l11l1ll1_opy_
  bstack1l11l1ll1_opy_ = self
  return
def bstack1lll1l1ll1_opy_(self, test):
  global CONFIG
  global bstack1l11l1ll1_opy_
  global bstack111l1l11_opy_
  global bstack111ll11l1_opy_
  global bstack1lll1ll1l1_opy_
  global bstack11ll1l111_opy_
  global bstack1ll1l1l1l_opy_
  global bstack1l1l11lll_opy_
  global bstack1l1l11l1l_opy_
  global bstack1llllllll1_opy_
  try:
    if not bstack111ll11l1_opy_:
      with open(os.path.join(os.path.expanduser(bstack1l111l_opy_ (u"ࠫࢃ࠭੶")), bstack1l111l_opy_ (u"ࠬ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠬ੷"), bstack1l111l_opy_ (u"࠭࠮ࡴࡧࡶࡷ࡮ࡵ࡮ࡪࡦࡶ࠲ࡹࡾࡴࠨ੸"))) as f:
        bstack1lll1llll1_opy_ = json.loads(bstack1l111l_opy_ (u"ࠢࡼࠤ੹") + f.read().strip() + bstack1l111l_opy_ (u"ࠨࠤࡻࠦ࠿ࠦࠢࡺࠤࠪ੺") + bstack1l111l_opy_ (u"ࠤࢀࠦ੻"))
        bstack111ll11l1_opy_ = bstack1lll1llll1_opy_[str(threading.get_ident())]
  except:
    pass
  if bstack1llllllll1_opy_:
    for driver in bstack1llllllll1_opy_:
      if bstack111ll11l1_opy_ == driver.session_id:
        if test:
          bstack1llll111ll_opy_ = str(test.data)
        if not bstack11l1l1l1l_opy_ and bstack1llll111ll_opy_:
          bstack1ll111l1l_opy_ = {
            bstack1l111l_opy_ (u"ࠪࡥࡨࡺࡩࡰࡰࠪ੼"): bstack1l111l_opy_ (u"ࠫࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠬ੽"),
            bstack1l111l_opy_ (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨ੾"): {
              bstack1l111l_opy_ (u"࠭࡮ࡢ࡯ࡨࠫ੿"): bstack1llll111ll_opy_
            }
          }
          bstack1ll1l1111l_opy_ = bstack1l111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࢁࠬ઀").format(json.dumps(bstack1ll111l1l_opy_))
          driver.execute_script(bstack1ll1l1111l_opy_)
        if bstack1lll1ll1l1_opy_:
          bstack1lll111ll1_opy_ = {
            bstack1l111l_opy_ (u"ࠨࡣࡦࡸ࡮ࡵ࡮ࠨઁ"): bstack1l111l_opy_ (u"ࠩࡤࡲࡳࡵࡴࡢࡶࡨࠫં"),
            bstack1l111l_opy_ (u"ࠪࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸ࠭ઃ"): {
              bstack1l111l_opy_ (u"ࠫࡩࡧࡴࡢࠩ઄"): bstack1llll111ll_opy_ + bstack1l111l_opy_ (u"ࠬࠦࡰࡢࡵࡶࡩࡩࠧࠧઅ"),
              bstack1l111l_opy_ (u"࠭࡬ࡦࡸࡨࡰࠬઆ"): bstack1l111l_opy_ (u"ࠧࡪࡰࡩࡳࠬઇ")
            }
          }
          bstack1ll111l1l_opy_ = {
            bstack1l111l_opy_ (u"ࠨࡣࡦࡸ࡮ࡵ࡮ࠨઈ"): bstack1l111l_opy_ (u"ࠩࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳ࡙ࡴࡢࡶࡸࡷࠬઉ"),
            bstack1l111l_opy_ (u"ࠪࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸ࠭ઊ"): {
              bstack1l111l_opy_ (u"ࠫࡸࡺࡡࡵࡷࡶࠫઋ"): bstack1l111l_opy_ (u"ࠬࡶࡡࡴࡵࡨࡨࠬઌ")
            }
          }
          if bstack1lll1ll1l1_opy_.status == bstack1l111l_opy_ (u"࠭ࡐࡂࡕࡖࠫઍ"):
            bstack11l1llll1_opy_ = bstack1l111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࢁࠬ઎").format(json.dumps(bstack1lll111ll1_opy_))
            driver.execute_script(bstack11l1llll1_opy_)
            bstack1ll1l1111l_opy_ = bstack1l111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࢂ࠭એ").format(json.dumps(bstack1ll111l1l_opy_))
            driver.execute_script(bstack1ll1l1111l_opy_)
          elif bstack1lll1ll1l1_opy_.status == bstack1l111l_opy_ (u"ࠩࡉࡅࡎࡒࠧઐ"):
            reason = bstack1l111l_opy_ (u"ࠥࠦઑ")
            bstack111lll1l1_opy_ = bstack1llll111ll_opy_ + bstack1l111l_opy_ (u"ࠫࠥ࡬ࡡࡪ࡮ࡨࡨࠬ઒")
            if bstack1lll1ll1l1_opy_.message:
              reason = str(bstack1lll1ll1l1_opy_.message)
              bstack111lll1l1_opy_ = bstack111lll1l1_opy_ + bstack1l111l_opy_ (u"ࠬࠦࡷࡪࡶ࡫ࠤࡪࡸࡲࡰࡴ࠽ࠤࠬઓ") + reason
            bstack1lll111ll1_opy_[bstack1l111l_opy_ (u"࠭ࡡࡳࡩࡸࡱࡪࡴࡴࡴࠩઔ")] = {
              bstack1l111l_opy_ (u"ࠧ࡭ࡧࡹࡩࡱ࠭ક"): bstack1l111l_opy_ (u"ࠨࡧࡵࡶࡴࡸࠧખ"),
              bstack1l111l_opy_ (u"ࠩࡧࡥࡹࡧࠧગ"): bstack111lll1l1_opy_
            }
            bstack1ll111l1l_opy_[bstack1l111l_opy_ (u"ࠪࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸ࠭ઘ")] = {
              bstack1l111l_opy_ (u"ࠫࡸࡺࡡࡵࡷࡶࠫઙ"): bstack1l111l_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬચ"),
              bstack1l111l_opy_ (u"࠭ࡲࡦࡣࡶࡳࡳ࠭છ"): reason
            }
            bstack11l1llll1_opy_ = bstack1l111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࢁࠬજ").format(json.dumps(bstack1lll111ll1_opy_))
            driver.execute_script(bstack11l1llll1_opy_)
            bstack1ll1l1111l_opy_ = bstack1l111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࢂ࠭ઝ").format(json.dumps(bstack1ll111l1l_opy_))
            driver.execute_script(bstack1ll1l1111l_opy_)
  elif bstack111ll11l1_opy_:
    try:
      data = {}
      bstack1llll111ll_opy_ = None
      if test:
        bstack1llll111ll_opy_ = str(test.data)
      if not bstack11l1l1l1l_opy_ and bstack1llll111ll_opy_:
        data[bstack1l111l_opy_ (u"ࠩࡱࡥࡲ࡫ࠧઞ")] = bstack1llll111ll_opy_
      if bstack1lll1ll1l1_opy_:
        if bstack1lll1ll1l1_opy_.status == bstack1l111l_opy_ (u"ࠪࡔࡆ࡙ࡓࠨટ"):
          data[bstack1l111l_opy_ (u"ࠫࡸࡺࡡࡵࡷࡶࠫઠ")] = bstack1l111l_opy_ (u"ࠬࡶࡡࡴࡵࡨࡨࠬડ")
        elif bstack1lll1ll1l1_opy_.status == bstack1l111l_opy_ (u"࠭ࡆࡂࡋࡏࠫઢ"):
          data[bstack1l111l_opy_ (u"ࠧࡴࡶࡤࡸࡺࡹࠧણ")] = bstack1l111l_opy_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨત")
          if bstack1lll1ll1l1_opy_.message:
            data[bstack1l111l_opy_ (u"ࠩࡵࡩࡦࡹ࡯࡯ࠩથ")] = str(bstack1lll1ll1l1_opy_.message)
      user = CONFIG[bstack1l111l_opy_ (u"ࠪࡹࡸ࡫ࡲࡏࡣࡰࡩࠬદ")]
      key = CONFIG[bstack1l111l_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶࡏࡪࡿࠧધ")]
      url = bstack1l111l_opy_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡻࡾ࠼ࡾࢁࡅࡧࡰࡪ࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡥࡲࡱ࠴ࡧࡵࡵࡱࡰࡥࡹ࡫࠯ࡴࡧࡶࡷ࡮ࡵ࡮ࡴ࠱ࡾࢁ࠳ࡰࡳࡰࡰࠪન").format(user, key, bstack111ll11l1_opy_)
      headers = {
        bstack1l111l_opy_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡵࡻࡳࡩࠬ઩"): bstack1l111l_opy_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡰࡳࡰࡰࠪપ"),
      }
      if bool(data):
        requests.put(url, json=data, headers=headers)
    except Exception as e:
      logger.error(bstack111lll1ll_opy_.format(str(e)))
  if bstack1l11l1ll1_opy_:
    bstack1l1l11lll_opy_(bstack1l11l1ll1_opy_)
  if bstack111l1l11_opy_:
    bstack1l1l11l1l_opy_(bstack111l1l11_opy_)
  bstack1ll1l1l1l_opy_(self, test)
def bstack1ll1ll1l1l_opy_(self, parent, test, skip_on_failure=None, rpa=False):
  global bstack11l111111_opy_
  bstack11l111111_opy_(self, parent, test, skip_on_failure=skip_on_failure, rpa=rpa)
  global bstack1lll1ll1l1_opy_
  bstack1lll1ll1l1_opy_ = self._test
def bstack11111ll11_opy_():
  global bstack1ll1ll1ll_opy_
  try:
    if os.path.exists(bstack1ll1ll1ll_opy_):
      os.remove(bstack1ll1ll1ll_opy_)
  except Exception as e:
    logger.debug(bstack1l111l_opy_ (u"ࠨࡇࡵࡶࡴࡸࠠࡪࡰࠣࡨࡪࡲࡥࡵ࡫ࡱ࡫ࠥࡸ࡯ࡣࡱࡷࠤࡷ࡫ࡰࡰࡴࡷࠤ࡫࡯࡬ࡦ࠼ࠣࠫફ") + str(e))
def bstack1lll1l1l1_opy_():
  global bstack1ll1ll1ll_opy_
  bstack111l11l1l_opy_ = {}
  try:
    if not os.path.isfile(bstack1ll1ll1ll_opy_):
      with open(bstack1ll1ll1ll_opy_, bstack1l111l_opy_ (u"ࠩࡺࠫબ")):
        pass
      with open(bstack1ll1ll1ll_opy_, bstack1l111l_opy_ (u"ࠥࡻ࠰ࠨભ")) as outfile:
        json.dump({}, outfile)
    if os.path.exists(bstack1ll1ll1ll_opy_):
      bstack111l11l1l_opy_ = json.load(open(bstack1ll1ll1ll_opy_, bstack1l111l_opy_ (u"ࠫࡷࡨࠧમ")))
  except Exception as e:
    logger.debug(bstack1l111l_opy_ (u"ࠬࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡳࡧࡤࡨ࡮ࡴࡧࠡࡴࡲࡦࡴࡺࠠࡳࡧࡳࡳࡷࡺࠠࡧ࡫࡯ࡩ࠿ࠦࠧય") + str(e))
  finally:
    return bstack111l11l1l_opy_
def bstack1ll1l111l_opy_(platform_index, item_index):
  global bstack1ll1ll1ll_opy_
  try:
    bstack111l11l1l_opy_ = bstack1lll1l1l1_opy_()
    bstack111l11l1l_opy_[item_index] = platform_index
    with open(bstack1ll1ll1ll_opy_, bstack1l111l_opy_ (u"ࠨࡷࠬࠤર")) as outfile:
      json.dump(bstack111l11l1l_opy_, outfile)
  except Exception as e:
    logger.debug(bstack1l111l_opy_ (u"ࠧࡆࡴࡵࡳࡷࠦࡩ࡯ࠢࡺࡶ࡮ࡺࡩ࡯ࡩࠣࡸࡴࠦࡲࡰࡤࡲࡸࠥࡸࡥࡱࡱࡵࡸࠥ࡬ࡩ࡭ࡧ࠽ࠤࠬ઱") + str(e))
def bstack1llll1ll1l_opy_(bstack111l1lll1_opy_):
  global CONFIG
  bstack1l1111l1_opy_ = bstack1l111l_opy_ (u"ࠨࠩલ")
  if not bstack1l111l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬળ") in CONFIG:
    logger.info(bstack1l111l_opy_ (u"ࠪࡒࡴࠦࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠢࡳࡥࡸࡹࡥࡥࠢࡸࡲࡦࡨ࡬ࡦࠢࡷࡳࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࠠࡳࡧࡳࡳࡷࡺࠠࡧࡱࡵࠤࡗࡵࡢࡰࡶࠣࡶࡺࡴࠧ઴"))
  try:
    platform = CONFIG[bstack1l111l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧવ")][bstack111l1lll1_opy_]
    if bstack1l111l_opy_ (u"ࠬࡵࡳࠨશ") in platform:
      bstack1l1111l1_opy_ += str(platform[bstack1l111l_opy_ (u"࠭࡯ࡴࠩષ")]) + bstack1l111l_opy_ (u"ࠧ࠭ࠢࠪસ")
    if bstack1l111l_opy_ (u"ࠨࡱࡶ࡚ࡪࡸࡳࡪࡱࡱࠫહ") in platform:
      bstack1l1111l1_opy_ += str(platform[bstack1l111l_opy_ (u"ࠩࡲࡷ࡛࡫ࡲࡴ࡫ࡲࡲࠬ઺")]) + bstack1l111l_opy_ (u"ࠪ࠰ࠥ࠭઻")
    if bstack1l111l_opy_ (u"ࠫࡩ࡫ࡶࡪࡥࡨࡒࡦࡳࡥࠨ઼") in platform:
      bstack1l1111l1_opy_ += str(platform[bstack1l111l_opy_ (u"ࠬࡪࡥࡷ࡫ࡦࡩࡓࡧ࡭ࡦࠩઽ")]) + bstack1l111l_opy_ (u"࠭ࠬࠡࠩા")
    if bstack1l111l_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡘࡨࡶࡸ࡯࡯࡯ࠩિ") in platform:
      bstack1l1111l1_opy_ += str(platform[bstack1l111l_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯࡙ࡩࡷࡹࡩࡰࡰࠪી")]) + bstack1l111l_opy_ (u"ࠩ࠯ࠤࠬુ")
    if bstack1l111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡒࡦࡳࡥࠨૂ") in platform:
      bstack1l1111l1_opy_ += str(platform[bstack1l111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠩૃ")]) + bstack1l111l_opy_ (u"ࠬ࠲ࠠࠨૄ")
    if bstack1l111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠧૅ") in platform:
      bstack1l1111l1_opy_ += str(platform[bstack1l111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨ૆")]) + bstack1l111l_opy_ (u"ࠨ࠮ࠣࠫે")
  except Exception as e:
    logger.debug(bstack1l111l_opy_ (u"ࠩࡖࡳࡲ࡫ࠠࡦࡴࡵࡳࡷࠦࡩ࡯ࠢࡪࡩࡳ࡫ࡲࡢࡶ࡬ࡲ࡬ࠦࡰ࡭ࡣࡷࡪࡴࡸ࡭ࠡࡵࡷࡶ࡮ࡴࡧࠡࡨࡲࡶࠥࡸࡥࡱࡱࡵࡸࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡯࡯࡯ࠩૈ") + str(e))
  finally:
    if bstack1l1111l1_opy_[len(bstack1l1111l1_opy_) - 2:] == bstack1l111l_opy_ (u"ࠪ࠰ࠥ࠭ૉ"):
      bstack1l1111l1_opy_ = bstack1l1111l1_opy_[:-2]
    return bstack1l1111l1_opy_
def bstack1l11lll1_opy_(path, bstack1l1111l1_opy_):
  try:
    import xml.etree.ElementTree as ET
    bstack1ll11llll_opy_ = ET.parse(path)
    bstack11llll1l1_opy_ = bstack1ll11llll_opy_.getroot()
    bstack1l111lll1_opy_ = None
    for suite in bstack11llll1l1_opy_.iter(bstack1l111l_opy_ (u"ࠫࡸࡻࡩࡵࡧࠪ૊")):
      if bstack1l111l_opy_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠬો") in suite.attrib:
        suite.attrib[bstack1l111l_opy_ (u"࠭࡮ࡢ࡯ࡨࠫૌ")] += bstack1l111l_opy_ (u"્ࠧࠡࠩ") + bstack1l1111l1_opy_
        bstack1l111lll1_opy_ = suite
    bstack1l1l11l1_opy_ = None
    for robot in bstack11llll1l1_opy_.iter(bstack1l111l_opy_ (u"ࠨࡴࡲࡦࡴࡺࠧ૎")):
      bstack1l1l11l1_opy_ = robot
    bstack1l11l111_opy_ = len(bstack1l1l11l1_opy_.findall(bstack1l111l_opy_ (u"ࠩࡶࡹ࡮ࡺࡥࠨ૏")))
    if bstack1l11l111_opy_ == 1:
      bstack1l1l11l1_opy_.remove(bstack1l1l11l1_opy_.findall(bstack1l111l_opy_ (u"ࠪࡷࡺ࡯ࡴࡦࠩૐ"))[0])
      bstack1111111l1_opy_ = ET.Element(bstack1l111l_opy_ (u"ࠫࡸࡻࡩࡵࡧࠪ૑"), attrib={bstack1l111l_opy_ (u"ࠬࡴࡡ࡮ࡧࠪ૒"): bstack1l111l_opy_ (u"࠭ࡓࡶ࡫ࡷࡩࡸ࠭૓"), bstack1l111l_opy_ (u"ࠧࡪࡦࠪ૔"): bstack1l111l_opy_ (u"ࠨࡵ࠳ࠫ૕")})
      bstack1l1l11l1_opy_.insert(1, bstack1111111l1_opy_)
      bstack1l1ll1l1l_opy_ = None
      for suite in bstack1l1l11l1_opy_.iter(bstack1l111l_opy_ (u"ࠩࡶࡹ࡮ࡺࡥࠨ૖")):
        bstack1l1ll1l1l_opy_ = suite
      bstack1l1ll1l1l_opy_.append(bstack1l111lll1_opy_)
      bstack1l11ll111_opy_ = None
      for status in bstack1l111lll1_opy_.iter(bstack1l111l_opy_ (u"ࠪࡷࡹࡧࡴࡶࡵࠪ૗")):
        bstack1l11ll111_opy_ = status
      bstack1l1ll1l1l_opy_.append(bstack1l11ll111_opy_)
    bstack1ll11llll_opy_.write(path)
  except Exception as e:
    logger.debug(bstack1l111l_opy_ (u"ࠫࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡰࡢࡴࡶ࡭ࡳ࡭ࠠࡸࡪ࡬ࡰࡪࠦࡧࡦࡰࡨࡶࡦࡺࡩ࡯ࡩࠣࡶࡴࡨ࡯ࡵࠢࡵࡩࡵࡵࡲࡵࠩ૘") + str(e))
def bstack1ll1ll11ll_opy_(outs_dir, pabot_args, options, start_time_string, tests_root_name):
  global bstack111lll1l_opy_
  global CONFIG
  if bstack1l111l_opy_ (u"ࠧࡶࡹࡵࡪࡲࡲࡵࡧࡴࡩࠤ૙") in options:
    del options[bstack1l111l_opy_ (u"ࠨࡰࡺࡶ࡫ࡳࡳࡶࡡࡵࡪࠥ૚")]
  bstack1ll1l11ll_opy_ = bstack1lll1l1l1_opy_()
  for bstack11l111ll_opy_ in bstack1ll1l11ll_opy_.keys():
    path = os.path.join(os.getcwd(), bstack1l111l_opy_ (u"ࠧࡱࡣࡥࡳࡹࡥࡲࡦࡵࡸࡰࡹࡹࠧ૛"), str(bstack11l111ll_opy_), bstack1l111l_opy_ (u"ࠨࡱࡸࡸࡵࡻࡴ࠯ࡺࡰࡰࠬ૜"))
    bstack1l11lll1_opy_(path, bstack1llll1ll1l_opy_(bstack1ll1l11ll_opy_[bstack11l111ll_opy_]))
  bstack11111ll11_opy_()
  return bstack111lll1l_opy_(outs_dir, pabot_args, options, start_time_string, tests_root_name)
def bstack1lll1l11ll_opy_(self, ff_profile_dir):
  global bstack11lll1lll_opy_
  if not ff_profile_dir:
    return None
  return bstack11lll1lll_opy_(self, ff_profile_dir)
def bstack1llll1l1ll_opy_(datasources, opts_for_run, outs_dir, pabot_args, suite_group):
  from pabot.pabot import QueueItem
  global CONFIG
  global bstack1ll1ll1ll1_opy_
  bstack11l1ll11l_opy_ = []
  if bstack1l111l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬ૝") in CONFIG:
    bstack11l1ll11l_opy_ = CONFIG[bstack1l111l_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭૞")]
  return [
    QueueItem(
      datasources,
      outs_dir,
      opts_for_run,
      suite,
      pabot_args[bstack1l111l_opy_ (u"ࠦࡨࡵ࡭࡮ࡣࡱࡨࠧ૟")],
      pabot_args[bstack1l111l_opy_ (u"ࠧࡼࡥࡳࡤࡲࡷࡪࠨૠ")],
      argfile,
      pabot_args.get(bstack1l111l_opy_ (u"ࠨࡨࡪࡸࡨࠦૡ")),
      pabot_args[bstack1l111l_opy_ (u"ࠢࡱࡴࡲࡧࡪࡹࡳࡦࡵࠥૢ")],
      platform[0],
      bstack1ll1ll1ll1_opy_
    )
    for suite in suite_group
    for argfile in pabot_args[bstack1l111l_opy_ (u"ࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡩ࡭ࡱ࡫ࡳࠣૣ")] or [(bstack1l111l_opy_ (u"ࠤࠥ૤"), None)]
    for platform in enumerate(bstack11l1ll11l_opy_)
  ]
def bstack1lll11l1ll_opy_(self, datasources, outs_dir, options,
                        execution_item, command, verbose, argfile,
                        hive=None, processes=0, platform_index=0, bstack1ll1111ll_opy_=bstack1l111l_opy_ (u"ࠪࠫ૥")):
  global bstack1ll1lllll1_opy_
  self.platform_index = platform_index
  self.bstack1lll11l111_opy_ = bstack1ll1111ll_opy_
  bstack1ll1lllll1_opy_(self, datasources, outs_dir, options,
                      execution_item, command, verbose, argfile, hive, processes)
def bstack11l1lll11_opy_(caller_id, datasources, is_last, item, outs_dir):
  global bstack111ll1l1l_opy_
  global bstack1l1l1l11l_opy_
  if not bstack1l111l_opy_ (u"ࠫࡻࡧࡲࡪࡣࡥࡰࡪ࠭૦") in item.options:
    item.options[bstack1l111l_opy_ (u"ࠬࡼࡡࡳ࡫ࡤࡦࡱ࡫ࠧ૧")] = []
  for v in item.options[bstack1l111l_opy_ (u"࠭ࡶࡢࡴ࡬ࡥࡧࡲࡥࠨ૨")]:
    if bstack1l111l_opy_ (u"ࠧࡃࡕࡗࡅࡈࡑࡐࡍࡃࡗࡊࡔࡘࡍࡊࡐࡇࡉ࡝࠭૩") in v:
      item.options[bstack1l111l_opy_ (u"ࠨࡸࡤࡶ࡮ࡧࡢ࡭ࡧࠪ૪")].remove(v)
    if bstack1l111l_opy_ (u"ࠩࡅࡗ࡙ࡇࡃࡌࡅࡏࡍࡆࡘࡇࡔࠩ૫") in v:
      item.options[bstack1l111l_opy_ (u"ࠪࡺࡦࡸࡩࡢࡤ࡯ࡩࠬ૬")].remove(v)
  item.options[bstack1l111l_opy_ (u"ࠫࡻࡧࡲࡪࡣࡥࡰࡪ࠭૭")].insert(0, bstack1l111l_opy_ (u"ࠬࡈࡓࡕࡃࡆࡏࡕࡒࡁࡕࡈࡒࡖࡒࡏࡎࡅࡇ࡛࠾ࢀࢃࠧ૮").format(item.platform_index))
  item.options[bstack1l111l_opy_ (u"࠭ࡶࡢࡴ࡬ࡥࡧࡲࡥࠨ૯")].insert(0, bstack1l111l_opy_ (u"ࠧࡃࡕࡗࡅࡈࡑࡄࡆࡈࡏࡓࡈࡇࡌࡊࡆࡈࡒ࡙ࡏࡆࡊࡇࡕ࠾ࢀࢃࠧ૰").format(item.bstack1lll11l111_opy_))
  if bstack1l1l1l11l_opy_:
    item.options[bstack1l111l_opy_ (u"ࠨࡸࡤࡶ࡮ࡧࡢ࡭ࡧࠪ૱")].insert(0, bstack1l111l_opy_ (u"ࠩࡅࡗ࡙ࡇࡃࡌࡅࡏࡍࡆࡘࡇࡔ࠼ࡾࢁࠬ૲").format(bstack1l1l1l11l_opy_))
  return bstack111ll1l1l_opy_(caller_id, datasources, is_last, item, outs_dir)
def bstack11l1llll_opy_(command, item_index):
  global bstack1l1l1l11l_opy_
  if bstack1l1l1l11l_opy_:
    command[0] = command[0].replace(bstack1l111l_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࠩ૳"), bstack1l111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠰ࡷࡩࡱࠠࡳࡱࡥࡳࡹ࠳ࡩ࡯ࡶࡨࡶࡳࡧ࡬ࠡ࠯࠰ࡦࡸࡺࡡࡤ࡭ࡢ࡭ࡹ࡫࡭ࡠ࡫ࡱࡨࡪࡾࠠࠨ૴") + str(
      item_index) + bstack1l111l_opy_ (u"ࠬࠦࠧ૵") + bstack1l1l1l11l_opy_, 1)
  else:
    command[0] = command[0].replace(bstack1l111l_opy_ (u"࠭ࡲࡰࡤࡲࡸࠬ૶"),
                                    bstack1l111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠳ࡳࡥ࡭ࠣࡶࡴࡨ࡯ࡵ࠯࡬ࡲࡹ࡫ࡲ࡯ࡣ࡯ࠤ࠲࠳ࡢࡴࡶࡤࡧࡰࡥࡩࡵࡧࡰࡣ࡮ࡴࡤࡦࡺࠣࠫ૷") + str(item_index), 1)
def bstack1l111111_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index):
  global bstack1l1ll11l_opy_
  bstack11l1llll_opy_(command, item_index)
  return bstack1l1ll11l_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index)
def bstack11l11ll11_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir):
  global bstack1l1ll11l_opy_
  bstack11l1llll_opy_(command, item_index)
  return bstack1l1ll11l_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir)
def bstack1111lll1_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir, process_timeout):
  global bstack1l1ll11l_opy_
  bstack11l1llll_opy_(command, item_index)
  return bstack1l1ll11l_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir, process_timeout)
def bstack1l111ll1l_opy_(self, runner, quiet=False, capture=True):
  global bstack1lll11111_opy_
  bstack1l1l1l111_opy_ = bstack1lll11111_opy_(self, runner, quiet=False, capture=True)
  if self.exception:
    if not hasattr(runner, bstack1l111l_opy_ (u"ࠨࡧࡻࡧࡪࡶࡴࡪࡱࡱࡣࡦࡸࡲࠨ૸")):
      runner.exception_arr = []
    if not hasattr(runner, bstack1l111l_opy_ (u"ࠩࡨࡼࡨࡥࡴࡳࡣࡦࡩࡧࡧࡣ࡬ࡡࡤࡶࡷ࠭ૹ")):
      runner.exc_traceback_arr = []
    runner.exception = self.exception
    runner.exc_traceback = self.exc_traceback
    runner.exception_arr.append(self.exception)
    runner.exc_traceback_arr.append(self.exc_traceback)
  return bstack1l1l1l111_opy_
def bstack1lll11l11_opy_(self, name, context, *args):
  global bstack1ll11l1l1_opy_
  if name == bstack1l111l_opy_ (u"ࠪࡦࡪ࡬࡯ࡳࡧࡢࡪࡪࡧࡴࡶࡴࡨࠫૺ"):
    bstack1ll11l1l1_opy_(self, name, context, *args)
    try:
      if not bstack11l1l1l1l_opy_:
        bstack111l111l1_opy_ = threading.current_thread().bstackSessionDriver if bstack1lll111l1l_opy_(bstack1l111l_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡗࡪࡹࡳࡪࡱࡱࡈࡷ࡯ࡶࡦࡴࠪૻ")) else context.browser
        bstack1111lll11_opy_ = str(self.feature.name)
        bstack11l1111l1_opy_(context, bstack1111lll11_opy_)
        bstack111l111l1_opy_.execute_script(bstack1l111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧࡹࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪࠨࠬࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼࠤࡱࡥࡲ࡫ࠢ࠻ࠢࠪૼ") + json.dumps(bstack1111lll11_opy_) + bstack1l111l_opy_ (u"࠭ࡽࡾࠩ૽"))
      self.driver_before_scenario = False
    except Exception as e:
      logger.debug(bstack1l111l_opy_ (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡷࡪࡺࠠࡴࡧࡶࡷ࡮ࡵ࡮ࠡࡰࡤࡱࡪࠦࡩ࡯ࠢࡥࡩ࡫ࡵࡲࡦࠢࡩࡩࡦࡺࡵࡳࡧ࠽ࠤࢀࢃࠧ૾").format(str(e)))
  elif name == bstack1l111l_opy_ (u"ࠨࡤࡨࡪࡴࡸࡥࡠࡵࡦࡩࡳࡧࡲࡪࡱࠪ૿"):
    bstack1ll11l1l1_opy_(self, name, context, *args)
    try:
      if not hasattr(self, bstack1l111l_opy_ (u"ࠩࡧࡶ࡮ࡼࡥࡳࡡࡥࡩ࡫ࡵࡲࡦࡡࡶࡧࡪࡴࡡࡳ࡫ࡲࠫ଀")):
        self.driver_before_scenario = True
      if (not bstack11l1l1l1l_opy_):
        scenario_name = args[0].name
        feature_name = bstack1111lll11_opy_ = str(self.feature.name)
        bstack1111lll11_opy_ = feature_name + bstack1l111l_opy_ (u"ࠪࠤ࠲ࠦࠧଁ") + scenario_name
        bstack111l111l1_opy_ = threading.current_thread().bstackSessionDriver if bstack1lll111l1l_opy_(bstack1l111l_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡗࡪࡹࡳࡪࡱࡱࡈࡷ࡯ࡶࡦࡴࠪଂ")) else context.browser
        if self.driver_before_scenario:
          bstack11l1111l1_opy_(context, bstack1111lll11_opy_)
          bstack111l111l1_opy_.execute_script(bstack1l111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧࡹࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪࠨࠬࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼࠤࡱࡥࡲ࡫ࠢ࠻ࠢࠪଃ") + json.dumps(bstack1111lll11_opy_) + bstack1l111l_opy_ (u"࠭ࡽࡾࠩ଄"))
    except Exception as e:
      logger.debug(bstack1l111l_opy_ (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡷࡪࡺࠠࡴࡧࡶࡷ࡮ࡵ࡮ࠡࡰࡤࡱࡪࠦࡩ࡯ࠢࡥࡩ࡫ࡵࡲࡦࠢࡶࡧࡪࡴࡡࡳ࡫ࡲ࠾ࠥࢁࡽࠨଅ").format(str(e)))
  elif name == bstack1l111l_opy_ (u"ࠨࡣࡩࡸࡪࡸ࡟ࡴࡥࡨࡲࡦࡸࡩࡰࠩଆ"):
    try:
      bstack111lllll_opy_ = args[0].status.name
      bstack111l111l1_opy_ = threading.current_thread().bstackSessionDriver if bstack1l111l_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬ࡕࡨࡷࡸ࡯࡯࡯ࡆࡵ࡭ࡻ࡫ࡲࠨଇ") in threading.current_thread().__dict__.keys() else context.browser
      if str(bstack111lllll_opy_).lower() == bstack1l111l_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪଈ"):
        bstack1llll1l11l_opy_ = bstack1l111l_opy_ (u"ࠫࠬଉ")
        bstack1l1l11ll_opy_ = bstack1l111l_opy_ (u"ࠬ࠭ଊ")
        bstack1lll1lll11_opy_ = bstack1l111l_opy_ (u"࠭ࠧଋ")
        try:
          import traceback
          bstack1llll1l11l_opy_ = self.exception.__class__.__name__
          bstack111l1ll1l_opy_ = traceback.format_tb(self.exc_traceback)
          bstack1l1l11ll_opy_ = bstack1l111l_opy_ (u"ࠧࠡࠩଌ").join(bstack111l1ll1l_opy_)
          bstack1lll1lll11_opy_ = bstack111l1ll1l_opy_[-1]
        except Exception as e:
          logger.debug(bstack11l111lll_opy_.format(str(e)))
        bstack1llll1l11l_opy_ += bstack1lll1lll11_opy_
        bstack111llll1_opy_(context, json.dumps(str(args[0].name) + bstack1l111l_opy_ (u"ࠣࠢ࠰ࠤࡋࡧࡩ࡭ࡧࡧࠥࡡࡴࠢ଍") + str(bstack1l1l11ll_opy_)),
                            bstack1l111l_opy_ (u"ࠤࡨࡶࡷࡵࡲࠣ଎"))
        if self.driver_before_scenario:
          bstack1lll1l1l1l_opy_(context, bstack1l111l_opy_ (u"ࠥࡪࡦ࡯࡬ࡦࡦࠥଏ"), bstack1llll1l11l_opy_)
          bstack111l111l1_opy_.execute_script(bstack1l111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠼ࠣࠦࡦࡴ࡮ࡰࡶࡤࡸࡪࠨࠬࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼࠤࡧࡥࡹࡧࠢ࠻ࠩଐ") + json.dumps(str(args[0].name) + bstack1l111l_opy_ (u"ࠧࠦ࠭ࠡࡈࡤ࡭ࡱ࡫ࡤࠢ࡞ࡱࠦ଑") + str(bstack1l1l11ll_opy_)) + bstack1l111l_opy_ (u"࠭ࠬࠡࠤ࡯ࡩࡻ࡫࡬ࠣ࠼ࠣࠦࡪࡸࡲࡰࡴࠥࢁࢂ࠭଒"))
        if self.driver_before_scenario:
          bstack111l111l1_opy_.execute_script(bstack1l111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡗࡹࡧࡴࡶࡵࠥ࠰ࠥࠨࡡࡳࡩࡸࡱࡪࡴࡴࡴࠤ࠽ࠤࢀࠨࡳࡵࡣࡷࡹࡸࠨ࠺ࠣࡨࡤ࡭ࡱ࡫ࡤࠣ࠮ࠣࠦࡷ࡫ࡡࡴࡱࡱࠦ࠿ࠦࠧଓ") + json.dumps(bstack1l111l_opy_ (u"ࠣࡕࡦࡩࡳࡧࡲࡪࡱࠣࡪࡦ࡯࡬ࡦࡦࠣࡻ࡮ࡺࡨ࠻ࠢ࡟ࡲࠧଔ") + str(bstack1llll1l11l_opy_)) + bstack1l111l_opy_ (u"ࠩࢀࢁࠬକ"))
      else:
        bstack111llll1_opy_(context, bstack1l111l_opy_ (u"ࠥࡔࡦࡹࡳࡦࡦࠤࠦଖ"), bstack1l111l_opy_ (u"ࠦ࡮ࡴࡦࡰࠤଗ"))
        if self.driver_before_scenario:
          bstack1lll1l1l1l_opy_(context, bstack1l111l_opy_ (u"ࠧࡶࡡࡴࡵࡨࡨࠧଘ"))
        bstack111l111l1_opy_.execute_script(bstack1l111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࠥࡥࡨࡺࡩࡰࡰࠥ࠾ࠥࠨࡡ࡯ࡰࡲࡸࡦࡺࡥࠣ࠮ࠣࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢ࠻ࠢࡾࠦࡩࡧࡴࡢࠤ࠽ࠫଙ") + json.dumps(str(args[0].name) + bstack1l111l_opy_ (u"ࠢࠡ࠯ࠣࡔࡦࡹࡳࡦࡦࠤࠦଚ")) + bstack1l111l_opy_ (u"ࠨ࠮ࠣࠦࡱ࡫ࡶࡦ࡮ࠥ࠾ࠥࠨࡩ࡯ࡨࡲࠦࢂࢃࠧଛ"))
        if self.driver_before_scenario:
          bstack111l111l1_opy_.execute_script(bstack1l111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࠨࡡࡤࡶ࡬ࡳࡳࠨ࠺ࠡࠤࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳ࡙ࡴࡢࡶࡸࡷࠧ࠲ࠠࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ࠿ࠦࡻࠣࡵࡷࡥࡹࡻࡳࠣ࠼ࠥࡴࡦࡹࡳࡦࡦࠥࢁࢂ࠭ଜ"))
    except Exception as e:
      logger.debug(bstack1l111l_opy_ (u"ࠪࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦ࡭ࡢࡴ࡮ࠤࡸ࡫ࡳࡴ࡫ࡲࡲࠥࡹࡴࡢࡶࡸࡷࠥ࡯࡮ࠡࡣࡩࡸࡪࡸࠠࡧࡧࡤࡸࡺࡸࡥ࠻ࠢࡾࢁࠬଝ").format(str(e)))
  elif name == bstack1l111l_opy_ (u"ࠫࡦ࡬ࡴࡦࡴࡢࡪࡪࡧࡴࡶࡴࡨࠫଞ"):
    try:
      bstack111l111l1_opy_ = threading.current_thread().bstackSessionDriver if bstack1lll111l1l_opy_(bstack1l111l_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯ࡘ࡫ࡳࡴ࡫ࡲࡲࡉࡸࡩࡷࡧࡵࠫଟ")) else context.browser
      if context.failed is True:
        bstack11l111ll1_opy_ = []
        bstack11l11lll1_opy_ = []
        bstack111111l1l_opy_ = []
        bstack1l1l111ll_opy_ = bstack1l111l_opy_ (u"࠭ࠧଠ")
        try:
          import traceback
          for exc in self.exception_arr:
            bstack11l111ll1_opy_.append(exc.__class__.__name__)
          for exc_tb in self.exc_traceback_arr:
            bstack111l1ll1l_opy_ = traceback.format_tb(exc_tb)
            bstack1111ll111_opy_ = bstack1l111l_opy_ (u"ࠧࠡࠩଡ").join(bstack111l1ll1l_opy_)
            bstack11l11lll1_opy_.append(bstack1111ll111_opy_)
            bstack111111l1l_opy_.append(bstack111l1ll1l_opy_[-1])
        except Exception as e:
          logger.debug(bstack11l111lll_opy_.format(str(e)))
        bstack1llll1l11l_opy_ = bstack1l111l_opy_ (u"ࠨࠩଢ")
        for i in range(len(bstack11l111ll1_opy_)):
          bstack1llll1l11l_opy_ += bstack11l111ll1_opy_[i] + bstack111111l1l_opy_[i] + bstack1l111l_opy_ (u"ࠩ࡟ࡲࠬଣ")
        bstack1l1l111ll_opy_ = bstack1l111l_opy_ (u"ࠪࠤࠬତ").join(bstack11l11lll1_opy_)
        if not self.driver_before_scenario:
          bstack111llll1_opy_(context, bstack1l1l111ll_opy_, bstack1l111l_opy_ (u"ࠦࡪࡸࡲࡰࡴࠥଥ"))
          bstack1lll1l1l1l_opy_(context, bstack1l111l_opy_ (u"ࠧ࡬ࡡࡪ࡮ࡨࡨࠧଦ"), bstack1llll1l11l_opy_)
          bstack111l111l1_opy_.execute_script(bstack1l111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࠥࡥࡨࡺࡩࡰࡰࠥ࠾ࠥࠨࡡ࡯ࡰࡲࡸࡦࡺࡥࠣ࠮ࠣࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢ࠻ࠢࡾࠦࡩࡧࡴࡢࠤ࠽ࠫଧ") + json.dumps(bstack1l1l111ll_opy_) + bstack1l111l_opy_ (u"ࠧ࠭ࠢࠥࡰࡪࡼࡥ࡭ࠤ࠽ࠤࠧ࡫ࡲࡳࡱࡵࠦࢂࢃࠧନ"))
          bstack111l111l1_opy_.execute_script(bstack1l111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࠧࡧࡣࡵ࡫ࡲࡲࠧࡀࠠࠣࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡘࡺࡡࡵࡷࡶࠦ࠱ࠦࠢࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠥ࠾ࠥࢁࠢࡴࡶࡤࡸࡺࡹࠢ࠻ࠤࡩࡥ࡮ࡲࡥࡥࠤ࠯ࠤࠧࡸࡥࡢࡵࡲࡲࠧࡀࠠࠨ଩") + json.dumps(bstack1l111l_opy_ (u"ࠤࡖࡳࡲ࡫ࠠࡴࡥࡨࡲࡦࡸࡩࡰࡵࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࡡࡴࠢପ") + str(bstack1llll1l11l_opy_)) + bstack1l111l_opy_ (u"ࠪࢁࢂ࠭ଫ"))
      else:
        if not self.driver_before_scenario:
          bstack111llll1_opy_(context, bstack1l111l_opy_ (u"ࠦࡋ࡫ࡡࡵࡷࡵࡩ࠿ࠦࠢବ") + str(self.feature.name) + bstack1l111l_opy_ (u"ࠧࠦࡰࡢࡵࡶࡩࡩࠧࠢଭ"), bstack1l111l_opy_ (u"ࠨࡩ࡯ࡨࡲࠦମ"))
          bstack1lll1l1l1l_opy_(context, bstack1l111l_opy_ (u"ࠢࡱࡣࡶࡷࡪࡪࠢଯ"))
          bstack111l111l1_opy_.execute_script(bstack1l111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࠧࡧࡣࡵ࡫ࡲࡲࠧࡀࠠࠣࡣࡱࡲࡴࡺࡡࡵࡧࠥ࠰ࠥࠨࡡࡳࡩࡸࡱࡪࡴࡴࡴࠤ࠽ࠤࢀࠨࡤࡢࡶࡤࠦ࠿࠭ର") + json.dumps(bstack1l111l_opy_ (u"ࠤࡉࡩࡦࡺࡵࡳࡧ࠽ࠤࠧ଱") + str(self.feature.name) + bstack1l111l_opy_ (u"ࠥࠤࡵࡧࡳࡴࡧࡧࠥࠧଲ")) + bstack1l111l_opy_ (u"ࠫ࠱ࠦࠢ࡭ࡧࡹࡩࡱࠨ࠺ࠡࠤ࡬ࡲ࡫ࡵࠢࡾࡿࠪଳ"))
          bstack111l111l1_opy_.execute_script(bstack1l111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧࡹࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡕࡷࡥࡹࡻࡳࠣ࠮ࠣࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢ࠻ࠢࡾࠦࡸࡺࡡࡵࡷࡶࠦ࠿ࠨࡰࡢࡵࡶࡩࡩࠨࡽࡾࠩ଴"))
    except Exception as e:
      logger.debug(bstack1l111l_opy_ (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡰࡥࡷࡱࠠࡴࡧࡶࡷ࡮ࡵ࡮ࠡࡵࡷࡥࡹࡻࡳࠡ࡫ࡱࠤࡦ࡬ࡴࡦࡴࠣࡪࡪࡧࡴࡶࡴࡨ࠾ࠥࢁࡽࠨଵ").format(str(e)))
  else:
    bstack1ll11l1l1_opy_(self, name, context, *args)
  if name in [bstack1l111l_opy_ (u"ࠧࡢࡨࡷࡩࡷࡥࡦࡦࡣࡷࡹࡷ࡫ࠧଶ"), bstack1l111l_opy_ (u"ࠨࡣࡩࡸࡪࡸ࡟ࡴࡥࡨࡲࡦࡸࡩࡰࠩଷ")]:
    bstack1ll11l1l1_opy_(self, name, context, *args)
    if (name == bstack1l111l_opy_ (u"ࠩࡤࡪࡹ࡫ࡲࡠࡵࡦࡩࡳࡧࡲࡪࡱࠪସ") and self.driver_before_scenario) or (
            name == bstack1l111l_opy_ (u"ࠪࡥ࡫ࡺࡥࡳࡡࡩࡩࡦࡺࡵࡳࡧࠪହ") and not self.driver_before_scenario):
      try:
        bstack111l111l1_opy_ = threading.current_thread().bstackSessionDriver if bstack1lll111l1l_opy_(bstack1l111l_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡗࡪࡹࡳࡪࡱࡱࡈࡷ࡯ࡶࡦࡴࠪ଺")) else context.browser
        bstack111l111l1_opy_.quit()
      except Exception:
        pass
def bstack1ll1l1l11_opy_(config, startdir):
  return bstack1l111l_opy_ (u"ࠧࡪࡲࡪࡸࡨࡶ࠿ࠦࡻ࠱ࡿࠥ଻").format(bstack1l111l_opy_ (u"ࠨࡂࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯଼ࠧ"))
notset = Notset()
def bstack1ll1l11111_opy_(self, name: str, default=notset, skip: bool = False):
  global bstack1l111l11_opy_
  if str(name).lower() == bstack1l111l_opy_ (u"ࠧࡥࡴ࡬ࡺࡪࡸࠧଽ"):
    return bstack1l111l_opy_ (u"ࠣࡄࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࠢା")
  else:
    return bstack1l111l11_opy_(self, name, default, skip)
def bstack1111ll1ll_opy_(item, when):
  global bstack1lllll1ll_opy_
  try:
    bstack1lllll1ll_opy_(item, when)
  except Exception as e:
    pass
def bstack11ll1llll_opy_():
  return
def bstack1ll111lll_opy_(type, name, status, reason, bstack1llll1lll_opy_, bstack1ll11l111_opy_):
  bstack1ll111l1l_opy_ = {
    bstack1l111l_opy_ (u"ࠩࡤࡧࡹ࡯࡯࡯ࠩି"): type,
    bstack1l111l_opy_ (u"ࠪࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸ࠭ୀ"): {}
  }
  if type == bstack1l111l_opy_ (u"ࠫࡦࡴ࡮ࡰࡶࡤࡸࡪ࠭ୁ"):
    bstack1ll111l1l_opy_[bstack1l111l_opy_ (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨୂ")][bstack1l111l_opy_ (u"࠭࡬ࡦࡸࡨࡰࠬୃ")] = bstack1llll1lll_opy_
    bstack1ll111l1l_opy_[bstack1l111l_opy_ (u"ࠧࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠪୄ")][bstack1l111l_opy_ (u"ࠨࡦࡤࡸࡦ࠭୅")] = json.dumps(str(bstack1ll11l111_opy_))
  if type == bstack1l111l_opy_ (u"ࠩࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠪ୆"):
    bstack1ll111l1l_opy_[bstack1l111l_opy_ (u"ࠪࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸ࠭େ")][bstack1l111l_opy_ (u"ࠫࡳࡧ࡭ࡦࠩୈ")] = name
  if type == bstack1l111l_opy_ (u"ࠬࡹࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡕࡷࡥࡹࡻࡳࠨ୉"):
    bstack1ll111l1l_opy_[bstack1l111l_opy_ (u"࠭ࡡࡳࡩࡸࡱࡪࡴࡴࡴࠩ୊")][bstack1l111l_opy_ (u"ࠧࡴࡶࡤࡸࡺࡹࠧୋ")] = status
    if status == bstack1l111l_opy_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨୌ"):
      bstack1ll111l1l_opy_[bstack1l111l_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷ୍ࠬ")][bstack1l111l_opy_ (u"ࠪࡶࡪࡧࡳࡰࡰࠪ୎")] = json.dumps(str(reason))
  bstack1ll1l1111l_opy_ = bstack1l111l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࡾࠩ୏").format(json.dumps(bstack1ll111l1l_opy_))
  return bstack1ll1l1111l_opy_
def bstack1111111ll_opy_(item, call, rep):
  global bstack111ll1ll1_opy_
  global bstack1llllllll1_opy_
  global bstack11l1l1l1l_opy_
  name = bstack1l111l_opy_ (u"ࠬ࠭୐")
  try:
    if rep.when == bstack1l111l_opy_ (u"࠭ࡣࡢ࡮࡯ࠫ୑"):
      bstack111ll11l1_opy_ = threading.current_thread().bstack1111l11l_opy_
      try:
        if not bstack11l1l1l1l_opy_:
          name = str(rep.nodeid)
          bstack11111lll_opy_ = bstack1ll111lll_opy_(bstack1l111l_opy_ (u"ࠧࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠨ୒"), name, bstack1l111l_opy_ (u"ࠨࠩ୓"), bstack1l111l_opy_ (u"ࠩࠪ୔"), bstack1l111l_opy_ (u"ࠪࠫ୕"), bstack1l111l_opy_ (u"ࠫࠬୖ"))
          for driver in bstack1llllllll1_opy_:
            if bstack111ll11l1_opy_ == driver.session_id:
              driver.execute_script(bstack11111lll_opy_)
      except Exception as e:
        logger.debug(bstack1l111l_opy_ (u"ࠬࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡵࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪࠦࡦࡰࡴࠣࡴࡾࡺࡥࡴࡶ࠰ࡦࡩࡪࠠࡴࡧࡶࡷ࡮ࡵ࡮࠻ࠢࡾࢁࠬୗ").format(str(e)))
      try:
        status = bstack1l111l_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭୘") if rep.outcome.lower() == bstack1l111l_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ୙") else bstack1l111l_opy_ (u"ࠨࡲࡤࡷࡸ࡫ࡤࠨ୚")
        reason = bstack1l111l_opy_ (u"ࠩࠪ୛")
        if (reason != bstack1l111l_opy_ (u"ࠥࠦଡ଼")):
          try:
            if (threading.current_thread().bstackTestErrorMessages == None):
              threading.current_thread().bstackTestErrorMessages = []
          except Exception as e:
            threading.current_thread().bstackTestErrorMessages = []
          threading.current_thread().bstackTestErrorMessages.append(str(reason))
        if status == bstack1l111l_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫଢ଼"):
          reason = rep.longrepr.reprcrash.message
          if (not threading.current_thread().bstackTestErrorMessages):
            threading.current_thread().bstackTestErrorMessages = []
          threading.current_thread().bstackTestErrorMessages.append(reason)
        level = bstack1l111l_opy_ (u"ࠬ࡯࡮ࡧࡱࠪ୞") if status == bstack1l111l_opy_ (u"࠭ࡰࡢࡵࡶࡩࡩ࠭ୟ") else bstack1l111l_opy_ (u"ࠧࡦࡴࡵࡳࡷ࠭ୠ")
        data = name + bstack1l111l_opy_ (u"ࠨࠢࡳࡥࡸࡹࡥࡥࠣࠪୡ") if status == bstack1l111l_opy_ (u"ࠩࡳࡥࡸࡹࡥࡥࠩୢ") else name + bstack1l111l_opy_ (u"ࠪࠤ࡫ࡧࡩ࡭ࡧࡧࠥࠥ࠭ୣ") + reason
        bstack11l1l11l1_opy_ = bstack1ll111lll_opy_(bstack1l111l_opy_ (u"ࠫࡦࡴ࡮ࡰࡶࡤࡸࡪ࠭୤"), bstack1l111l_opy_ (u"ࠬ࠭୥"), bstack1l111l_opy_ (u"࠭ࠧ୦"), bstack1l111l_opy_ (u"ࠧࠨ୧"), level, data)
        for driver in bstack1llllllll1_opy_:
          if bstack111ll11l1_opy_ == driver.session_id:
            driver.execute_script(bstack11l1l11l1_opy_)
      except Exception as e:
        logger.debug(bstack1l111l_opy_ (u"ࠨࡇࡵࡶࡴࡸࠠࡪࡰࠣࡷࡪࡺࡴࡪࡰࡪࠤࡸ࡫ࡳࡴ࡫ࡲࡲࠥࡩ࡯࡯ࡶࡨࡼࡹࠦࡦࡰࡴࠣࡴࡾࡺࡥࡴࡶ࠰ࡦࡩࡪࠠࡴࡧࡶࡷ࡮ࡵ࡮࠻ࠢࡾࢁࠬ୨").format(str(e)))
  except Exception as e:
    logger.debug(bstack1l111l_opy_ (u"ࠩࡈࡶࡷࡵࡲࠡ࡫ࡱࠤ࡬࡫ࡴࡵ࡫ࡱ࡫ࠥࡹࡴࡢࡶࡨࠤ࡮ࡴࠠࡱࡻࡷࡩࡸࡺ࠭ࡣࡦࡧࠤࡹ࡫ࡳࡵࠢࡶࡸࡦࡺࡵࡴ࠼ࠣࡿࢂ࠭୩").format(str(e)))
  bstack111ll1ll1_opy_(item, call, rep)
def bstack1lll111lll_opy_(framework_name):
  global bstack111111ll1_opy_
  global bstack111l11l1_opy_
  global bstack1l11lll1l_opy_
  bstack111111ll1_opy_ = framework_name
  logger.info(bstack1ll11111l_opy_.format(bstack111111ll1_opy_.split(bstack1l111l_opy_ (u"ࠪ࠱ࠬ୪"))[0]))
  try:
    from selenium import webdriver
    from selenium.webdriver.common.service import Service
    from selenium.webdriver.remote.webdriver import WebDriver
    if bstack1111l11l1_opy_:
      Service.start = bstack111llll11_opy_
      Service.stop = bstack11111lll1_opy_
      webdriver.Remote.get = bstack1l111111l_opy_
      WebDriver.close = bstack11lll1l11_opy_
      WebDriver.quit = bstack1ll1l11lll_opy_
      webdriver.Remote.__init__ = bstack1ll1l1lll1_opy_
    if not bstack1111l11l1_opy_ and bstack1lllll111_opy_.on():
      webdriver.Remote.__init__ = bstack111l1l11l_opy_
    bstack111l11l1_opy_ = True
  except Exception as e:
    pass
  bstack1lll1llll_opy_()
  if not bstack111l11l1_opy_:
    bstack11l11lll_opy_(bstack1l111l_opy_ (u"ࠦࡕࡧࡣ࡬ࡣࡪࡩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠨ୫"), bstack1lll1l1111_opy_)
  if bstack1ll1ll1l11_opy_():
    try:
      from selenium.webdriver.remote.remote_connection import RemoteConnection
      RemoteConnection._get_proxy_url = bstack11ll1lll_opy_
    except Exception as e:
      logger.error(bstack11111l111_opy_.format(str(e)))
  if (bstack1l111l_opy_ (u"ࠬࡸ࡯ࡣࡱࡷࠫ୬") in str(framework_name).lower()):
    try:
      from robot import run_cli
      from robot.output import Output
      from robot.running.status import TestStatus
      from pabot.pabot import QueueItem
      from pabot import pabot
      try:
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCreator
        WebDriverCreator._get_ff_profile = bstack1lll1l11ll_opy_
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCache
        WebDriverCache.close = bstack1l11l11l1_opy_
      except Exception as e:
        logger.warn(bstack11l11ll1_opy_ + str(e))
      try:
        from AppiumLibrary.utils.applicationcache import ApplicationCache
        ApplicationCache.close = bstack111ll1l1_opy_
      except Exception as e:
        logger.debug(bstack1111l1l1l_opy_ + str(e))
    except Exception as e:
      bstack11l11lll_opy_(e, bstack11l11ll1_opy_)
    Output.end_test = bstack1lll1l1ll1_opy_
    TestStatus.__init__ = bstack1ll1ll1l1l_opy_
    QueueItem.__init__ = bstack1lll11l1ll_opy_
    pabot._create_items = bstack1llll1l1ll_opy_
    try:
      from pabot import __version__ as bstack1ll1l11ll1_opy_
      if version.parse(bstack1ll1l11ll1_opy_) >= version.parse(bstack1l111l_opy_ (u"࠭࠲࠯࠳࠸࠲࠵࠭୭")):
        pabot._run = bstack1111lll1_opy_
      elif version.parse(bstack1ll1l11ll1_opy_) >= version.parse(bstack1l111l_opy_ (u"ࠧ࠳࠰࠴࠷࠳࠶ࠧ୮")):
        pabot._run = bstack11l11ll11_opy_
      else:
        pabot._run = bstack1l111111_opy_
    except Exception as e:
      pabot._run = bstack1l111111_opy_
    pabot._create_command_for_execution = bstack11l1lll11_opy_
    pabot._report_results = bstack1ll1ll11ll_opy_
  if bstack1l111l_opy_ (u"ࠨࡤࡨ࡬ࡦࡼࡥࠨ୯") in str(framework_name).lower():
    try:
      from behave.runner import Runner
      from behave.model import Step
    except Exception as e:
      bstack11l11lll_opy_(e, bstack1lll11llll_opy_)
    Runner.run_hook = bstack1lll11l11_opy_
    Step.run = bstack1l111ll1l_opy_
  if bstack1l111l_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࠩ୰") in str(framework_name).lower():
    if not bstack1111l11l1_opy_:
      return
    try:
      from pytest_selenium import pytest_selenium
      from _pytest.config import Config
      pytest_selenium.pytest_report_header = bstack1ll1l1l11_opy_
      from pytest_selenium.drivers import browserstack
      browserstack.pytest_selenium_runtest_makereport = bstack11ll1llll_opy_
      Config.getoption = bstack1ll1l11111_opy_
    except Exception as e:
      pass
    try:
      from pytest_bdd import reporting
      reporting.runtest_makereport = bstack1111111ll_opy_
    except Exception as e:
      pass
def bstack1lll111l1_opy_():
  global CONFIG
  if bstack1l111l_opy_ (u"ࠪࡴࡦࡸࡡ࡭࡮ࡨࡰࡸࡖࡥࡳࡒ࡯ࡥࡹ࡬࡯ࡳ࡯ࠪୱ") in CONFIG and int(CONFIG[bstack1l111l_opy_ (u"ࠫࡵࡧࡲࡢ࡮࡯ࡩࡱࡹࡐࡦࡴࡓࡰࡦࡺࡦࡰࡴࡰࠫ୲")]) > 1:
    logger.warn(bstack111ll1111_opy_)
def bstack11lll11ll_opy_(arg, bstack1llll1l1_opy_):
  global CONFIG
  global bstack1ll11lll1_opy_
  global bstack1ll111l11_opy_
  global bstack1111l11l1_opy_
  bstack111l11l11_opy_ = bstack1l111l_opy_ (u"ࠬࡶࡹࡵࡧࡶࡸࠬ୳")
  if bstack1llll1l1_opy_ and isinstance(bstack1llll1l1_opy_, str):
    bstack1llll1l1_opy_ = eval(bstack1llll1l1_opy_)
  CONFIG = bstack1llll1l1_opy_[bstack1l111l_opy_ (u"࠭ࡃࡐࡐࡉࡍࡌ࠭୴")]
  bstack1ll11lll1_opy_ = bstack1llll1l1_opy_[bstack1l111l_opy_ (u"ࠧࡉࡗࡅࡣ࡚ࡘࡌࠨ୵")]
  bstack1ll111l11_opy_ = bstack1llll1l1_opy_[bstack1l111l_opy_ (u"ࠨࡋࡖࡣࡆࡖࡐࡠࡃࡘࡘࡔࡓࡁࡕࡇࠪ୶")]
  bstack1111l11l1_opy_ = bstack1llll1l1_opy_[bstack1l111l_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡃࡘࡘࡔࡓࡁࡕࡋࡒࡒࠬ୷")]
  os.environ[bstack1l111l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡉࡖࡆࡓࡅࡘࡑࡕࡏࠬ୸")] = bstack111l11l11_opy_
  os.environ[bstack1l111l_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡇࡔࡔࡆࡊࡉࠪ୹")] = json.dumps(CONFIG)
  os.environ[bstack1l111l_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡍ࡛ࡂࡠࡗࡕࡐࠬ୺")] = bstack1ll11lll1_opy_
  os.environ[bstack1l111l_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡏࡓࡠࡃࡓࡔࡤࡇࡕࡕࡑࡐࡅ࡙ࡋࠧ୻")] = str(bstack1ll111l11_opy_)
  os.environ[bstack1l111l_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡐ࡚ࡖࡈࡗ࡙ࡥࡐࡍࡗࡊࡍࡓ࠭୼")] = str(True)
  if bstack1l1l1llll_opy_(arg, [bstack1l111l_opy_ (u"ࠨ࠯ࡱࠫ୽"), bstack1l111l_opy_ (u"ࠩ࠰࠱ࡳࡻ࡭ࡱࡴࡲࡧࡪࡹࡳࡦࡵࠪ୾")]) != -1:
    os.environ[bstack1l111l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡓ࡝࡙ࡋࡓࡕࡡࡓࡅࡗࡇࡌࡍࡇࡏࠫ୿")] = str(True)
  if len(sys.argv) <= 1:
    logger.critical(bstack1ll1111l1_opy_)
    return
  bstack111l1lll_opy_()
  global bstack1l1lll11_opy_
  global bstack11l1111l_opy_
  global bstack1ll1ll1ll1_opy_
  global bstack1l1l1l11l_opy_
  global bstack1l11111l_opy_
  global bstack1l11lll1l_opy_
  global bstack1lll1l111_opy_
  arg.append(bstack1l111l_opy_ (u"ࠦ࠲࡝ࠢ஀"))
  arg.append(bstack1l111l_opy_ (u"ࠧ࡯ࡧ࡯ࡱࡵࡩ࠿ࡓ࡯ࡥࡷ࡯ࡩࠥࡧ࡬ࡳࡧࡤࡨࡾࠦࡩ࡮ࡲࡲࡶࡹ࡫ࡤ࠻ࡲࡼࡸࡪࡹࡴ࠯ࡒࡼࡸࡪࡹࡴࡘࡣࡵࡲ࡮ࡴࡧࠣ஁"))
  arg.append(bstack1l111l_opy_ (u"ࠨ࠭ࡘࠤஂ"))
  arg.append(bstack1l111l_opy_ (u"ࠢࡪࡩࡱࡳࡷ࡫࠺ࡕࡪࡨࠤ࡭ࡵ࡯࡬࡫ࡰࡴࡱࠨஃ"))
  global bstack11lll1l1_opy_
  global bstack1lllllll1l_opy_
  global bstack11l111111_opy_
  global bstack11lll1lll_opy_
  global bstack1ll1lllll1_opy_
  global bstack111ll1l1l_opy_
  global bstack11l1l1l1_opy_
  global bstack11ll11111_opy_
  global bstack1lllll1111_opy_
  global bstack1l111l11_opy_
  global bstack1lllll1ll_opy_
  global bstack111ll1ll1_opy_
  try:
    from selenium import webdriver
    from selenium.webdriver.remote.webdriver import WebDriver
    bstack11lll1l1_opy_ = webdriver.Remote.__init__
    bstack1lllllll1l_opy_ = WebDriver.quit
    bstack11l1l1l1_opy_ = WebDriver.close
    bstack11ll11111_opy_ = WebDriver.get
  except Exception as e:
    pass
  if bstack1111ll11l_opy_(CONFIG):
    if bstack111lllll1_opy_() < version.parse(bstack11llll1l_opy_):
      logger.error(bstack1ll1l111l1_opy_.format(bstack111lllll1_opy_()))
    else:
      try:
        from selenium.webdriver.remote.remote_connection import RemoteConnection
        bstack1lllll1111_opy_ = RemoteConnection._get_proxy_url
      except Exception as e:
        logger.error(bstack11111l111_opy_.format(str(e)))
  try:
    from _pytest.config import Config
    bstack1l111l11_opy_ = Config.getoption
    from _pytest import runner
    bstack1lllll1ll_opy_ = runner._update_current_test_var
  except Exception as e:
    logger.warn(e, bstack1ll11l1l_opy_)
  try:
    from pytest_bdd import reporting
    bstack111ll1ll1_opy_ = reporting.runtest_makereport
  except Exception as e:
    logger.debug(bstack1l111l_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡ࡫ࡱࡷࡹࡧ࡬࡭ࠢࡳࡽࡹ࡫ࡳࡵ࠯ࡥࡨࡩࠦࡴࡰࠢࡵࡹࡳࠦࡰࡺࡶࡨࡷࡹ࠳ࡢࡥࡦࠣࡸࡪࡹࡴࡴࠩ஄"))
  bstack1ll1ll1ll1_opy_ = CONFIG.get(bstack1l111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࡍࡱࡦࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭அ"), {}).get(bstack1l111l_opy_ (u"ࠪࡰࡴࡩࡡ࡭ࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬஆ"))
  bstack1lll1l111_opy_ = True
  bstack1lll111lll_opy_(bstack1lll1l11_opy_)
  os.environ[bstack1l111l_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢ࡙ࡘࡋࡒࡏࡃࡐࡉࠬஇ")] = CONFIG[bstack1l111l_opy_ (u"ࠬࡻࡳࡦࡴࡑࡥࡲ࡫ࠧஈ")]
  os.environ[bstack1l111l_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡇࡃࡄࡇࡖࡗࡤࡑࡅ࡚ࠩஉ")] = CONFIG[bstack1l111l_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡋࡦࡻࠪஊ")]
  os.environ[bstack1l111l_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡂࡗࡗࡓࡒࡇࡔࡊࡑࡑࠫ஋")] = bstack1111l11l1_opy_.__str__()
  from _pytest.config import main as bstack1llllll1l_opy_
  bstack1llllll1l_opy_(arg)
def bstack1111ll1l_opy_(arg):
  bstack1lll111lll_opy_(bstack1lllllllll_opy_)
  from behave.__main__ import main as bstack11lllll11_opy_
  bstack11lllll11_opy_(arg)
def bstack1l1111111_opy_():
  logger.info(bstack111llllll_opy_)
  import argparse
  parser = argparse.ArgumentParser()
  parser.add_argument(bstack1l111l_opy_ (u"ࠩࡶࡩࡹࡻࡰࠨ஌"), help=bstack1l111l_opy_ (u"ࠪࡋࡪࡴࡥࡳࡣࡷࡩࠥࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠤࡨࡵ࡮ࡧ࡫ࡪࠫ஍"))
  parser.add_argument(bstack1l111l_opy_ (u"ࠫ࠲ࡻࠧஎ"), bstack1l111l_opy_ (u"ࠬ࠳࠭ࡶࡵࡨࡶࡳࡧ࡭ࡦࠩஏ"), help=bstack1l111l_opy_ (u"࡙࠭ࡰࡷࡵࠤࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࠣࡹࡸ࡫ࡲ࡯ࡣࡰࡩࠬஐ"))
  parser.add_argument(bstack1l111l_opy_ (u"ࠧ࠮࡭ࠪ஑"), bstack1l111l_opy_ (u"ࠨ࠯࠰࡯ࡪࡿࠧஒ"), help=bstack1l111l_opy_ (u"ࠩ࡜ࡳࡺࡸࠠࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࠦࡡࡤࡥࡨࡷࡸࠦ࡫ࡦࡻࠪஓ"))
  parser.add_argument(bstack1l111l_opy_ (u"ࠪ࠱࡫࠭ஔ"), bstack1l111l_opy_ (u"ࠫ࠲࠳ࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࠩக"), help=bstack1l111l_opy_ (u"ࠬ࡟࡯ࡶࡴࠣࡸࡪࡹࡴࠡࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࠫ஖"))
  bstack1l1lllll1_opy_ = parser.parse_args()
  try:
    bstack1llll11l1l_opy_ = bstack1l111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳࡭ࡥ࡯ࡧࡵ࡭ࡨ࠴ࡹ࡮࡮࠱ࡷࡦࡳࡰ࡭ࡧࠪ஗")
    if bstack1l1lllll1_opy_.framework and bstack1l1lllll1_opy_.framework not in (bstack1l111l_opy_ (u"ࠧࡱࡻࡷ࡬ࡴࡴࠧ஘"), bstack1l111l_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮࠴ࠩங")):
      bstack1llll11l1l_opy_ = bstack1l111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮࠲ࡾࡳ࡬࠯ࡵࡤࡱࡵࡲࡥࠨச")
    bstack11l11l1l_opy_ = os.path.join(os.path.dirname(os.path.realpath(__file__)), bstack1llll11l1l_opy_)
    bstack1l1lll11l_opy_ = open(bstack11l11l1l_opy_, bstack1l111l_opy_ (u"ࠪࡶࠬ஛"))
    bstack1l1l11l11_opy_ = bstack1l1lll11l_opy_.read()
    bstack1l1lll11l_opy_.close()
    if bstack1l1lllll1_opy_.username:
      bstack1l1l11l11_opy_ = bstack1l1l11l11_opy_.replace(bstack1l111l_opy_ (u"ࠫ࡞ࡕࡕࡓࡡࡘࡗࡊࡘࡎࡂࡏࡈࠫஜ"), bstack1l1lllll1_opy_.username)
    if bstack1l1lllll1_opy_.key:
      bstack1l1l11l11_opy_ = bstack1l1l11l11_opy_.replace(bstack1l111l_opy_ (u"ࠬ࡟ࡏࡖࡔࡢࡅࡈࡉࡅࡔࡕࡢࡏࡊ࡟ࠧ஝"), bstack1l1lllll1_opy_.key)
    if bstack1l1lllll1_opy_.framework:
      bstack1l1l11l11_opy_ = bstack1l1l11l11_opy_.replace(bstack1l111l_opy_ (u"࡙࠭ࡐࡗࡕࡣࡋࡘࡁࡎࡇ࡚ࡓࡗࡑࠧஞ"), bstack1l1lllll1_opy_.framework)
    file_name = bstack1l111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡹ࡮࡮ࠪட")
    file_path = os.path.abspath(file_name)
    bstack11l11llll_opy_ = open(file_path, bstack1l111l_opy_ (u"ࠨࡹࠪ஠"))
    bstack11l11llll_opy_.write(bstack1l1l11l11_opy_)
    bstack11l11llll_opy_.close()
    logger.info(bstack1llllll111_opy_)
    try:
      os.environ[bstack1l111l_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡈࡕࡅࡒࡋࡗࡐࡔࡎࠫ஡")] = bstack1l1lllll1_opy_.framework if bstack1l1lllll1_opy_.framework != None else bstack1l111l_opy_ (u"ࠥࠦ஢")
      config = yaml.safe_load(bstack1l1l11l11_opy_)
      config[bstack1l111l_opy_ (u"ࠫࡸࡵࡵࡳࡥࡨࠫண")] = bstack1l111l_opy_ (u"ࠬࡶࡹࡵࡪࡲࡲ࠲ࡹࡥࡵࡷࡳࠫத")
      bstack11111ll1l_opy_(bstack1l11ll11_opy_, config)
    except Exception as e:
      logger.debug(bstack111ll11ll_opy_.format(str(e)))
  except Exception as e:
    logger.error(bstack1ll1l1ll1_opy_.format(str(e)))
def bstack11111ll1l_opy_(bstack1lll1l111l_opy_, config, bstack1l1l111l1_opy_={}):
  global bstack1111l11l1_opy_
  if not config:
    return
  bstack111ll1lll_opy_ = bstack1llll1l11_opy_ if not bstack1111l11l1_opy_ else (
    bstack1lllll1lll_opy_ if bstack1l111l_opy_ (u"࠭ࡡࡱࡲࠪ஥") in config else bstack1l111llll_opy_)
  data = {
    bstack1l111l_opy_ (u"ࠧࡶࡵࡨࡶࡓࡧ࡭ࡦࠩ஦"): config[bstack1l111l_opy_ (u"ࠨࡷࡶࡩࡷࡔࡡ࡮ࡧࠪ஧")],
    bstack1l111l_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴࡍࡨࡽࠬந"): config[bstack1l111l_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵࡎࡩࡾ࠭ன")],
    bstack1l111l_opy_ (u"ࠫࡪࡼࡥ࡯ࡶࡢࡸࡾࡶࡥࠨப"): bstack1lll1l111l_opy_,
    bstack1l111l_opy_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠨ஫"): {
      bstack1l111l_opy_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࡠࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࠫ஬"): str(config[bstack1l111l_opy_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠧ஭")]) if bstack1l111l_opy_ (u"ࠨࡵࡲࡹࡷࡩࡥࠨம") in config else bstack1l111l_opy_ (u"ࠤࡸࡲࡰࡴ࡯ࡸࡰࠥய"),
      bstack1l111l_opy_ (u"ࠪࡶࡪ࡬ࡥࡳࡴࡨࡶࠬர"): bstack1llll1l111_opy_(os.getenv(bstack1l111l_opy_ (u"ࠦࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡊࡗࡇࡍࡆ࡙ࡒࡖࡐࠨற"), bstack1l111l_opy_ (u"ࠧࠨல"))),
      bstack1l111l_opy_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨள"): bstack1l111l_opy_ (u"ࠧࡱࡻࡷ࡬ࡴࡴࠧழ"),
      bstack1l111l_opy_ (u"ࠨࡲࡵࡳࡩࡻࡣࡵࠩவ"): bstack111ll1lll_opy_,
      bstack1l111l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬஶ"): config[bstack1l111l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭ஷ")] if config[bstack1l111l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠧஸ")] else bstack1l111l_opy_ (u"ࠧࡻ࡮࡬ࡰࡲࡻࡳࠨஹ"),
      bstack1l111l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨ஺"): str(config[bstack1l111l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩ஻")]) if bstack1l111l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪ஼") in config else bstack1l111l_opy_ (u"ࠤࡸࡲࡰࡴ࡯ࡸࡰࠥ஽"),
      bstack1l111l_opy_ (u"ࠪࡳࡸ࠭ா"): sys.platform,
      bstack1l111l_opy_ (u"ࠫ࡭ࡵࡳࡵࡰࡤࡱࡪ࠭ி"): socket.gethostname()
    }
  }
  update(data[bstack1l111l_opy_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠨீ")], bstack1l1l111l1_opy_)
  try:
    response = bstack1ll1l111ll_opy_(bstack1l111l_opy_ (u"࠭ࡐࡐࡕࡗࠫு"), bstack1llll1ll1_opy_(bstack1111llll1_opy_), data, {
      bstack1l111l_opy_ (u"ࠧࡢࡷࡷ࡬ࠬூ"): (config[bstack1l111l_opy_ (u"ࠨࡷࡶࡩࡷࡔࡡ࡮ࡧࠪ௃")], config[bstack1l111l_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴࡍࡨࡽࠬ௄")])
    })
    if response:
      logger.debug(bstack1l11ll11l_opy_.format(bstack1lll1l111l_opy_, str(response.json())))
  except Exception as e:
    logger.debug(bstack11l1l1ll1_opy_.format(str(e)))
def bstack1llll1l111_opy_(framework):
  return bstack1l111l_opy_ (u"ࠥࡿࢂ࠳ࡰࡺࡶ࡫ࡳࡳࡧࡧࡦࡰࡷ࠳ࢀࢃࠢ௅").format(str(framework), __version__) if framework else bstack1l111l_opy_ (u"ࠦࡵࡿࡴࡩࡱࡱࡥ࡬࡫࡮ࡵ࠱ࡾࢁࠧெ").format(
    __version__)
def bstack111l1lll_opy_():
  global CONFIG
  if bool(CONFIG):
    return
  try:
    bstack1ll1l1111_opy_()
    logger.debug(bstack11l1ll1l_opy_.format(str(CONFIG)))
    bstack111l1l111_opy_()
    bstack1ll11111_opy_()
  except Exception as e:
    logger.error(bstack1l111l_opy_ (u"ࠧࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡵࡨࡸࡺࡶࠬࠡࡧࡵࡶࡴࡸ࠺ࠡࠤே") + str(e))
    sys.exit(1)
  sys.excepthook = bstack1lll1111ll_opy_
  atexit.register(bstack111111lll_opy_)
  signal.signal(signal.SIGINT, bstack1lllll1l11_opy_)
  signal.signal(signal.SIGTERM, bstack1lllll1l11_opy_)
def bstack1lll1111ll_opy_(exctype, value, traceback):
  global bstack1llllllll1_opy_
  try:
    for driver in bstack1llllllll1_opy_:
      driver.execute_script(
        bstack1l111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࠥࡥࡨࡺࡩࡰࡰࠥ࠾ࠥࠨࡳࡦࡶࡖࡩࡸࡹࡩࡰࡰࡖࡸࡦࡺࡵࡴࠤ࠯ࠤࠧࡧࡲࡨࡷࡰࡩࡳࡺࡳࠣ࠼ࠣࡿࠧࡹࡴࡢࡶࡸࡷࠧࡀࠢࡧࡣ࡬ࡰࡪࡪࠢ࠭ࠢࠥࡶࡪࡧࡳࡰࡰࠥ࠾ࠥ࠭ை") + json.dumps(
          bstack1l111l_opy_ (u"ࠢࡔࡧࡶࡷ࡮ࡵ࡮ࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡹ࡬ࡸ࡭ࡀࠠ࡝ࡰࠥ௉") + str(value)) + bstack1l111l_opy_ (u"ࠨࡿࢀࠫொ"))
  except Exception:
    pass
  bstack1l1l11ll1_opy_(value)
  sys.__excepthook__(exctype, value, traceback)
  sys.exit(1)
def bstack1l1l11ll1_opy_(message=bstack1l111l_opy_ (u"ࠩࠪோ")):
  global CONFIG
  try:
    if message:
      bstack1l1l111l1_opy_ = {
        bstack1l111l_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࠩௌ"): str(message)
      }
      bstack11111ll1l_opy_(bstack1l11llll_opy_, CONFIG, bstack1l1l111l1_opy_)
    else:
      bstack11111ll1l_opy_(bstack1l11llll_opy_, CONFIG)
  except Exception as e:
    logger.debug(bstack11l111l1l_opy_.format(str(e)))
def bstack1lll1111_opy_(bstack1l1111lll_opy_, size):
  bstack1ll11lllll_opy_ = []
  while len(bstack1l1111lll_opy_) > size:
    bstack111l11lll_opy_ = bstack1l1111lll_opy_[:size]
    bstack1ll11lllll_opy_.append(bstack111l11lll_opy_)
    bstack1l1111lll_opy_ = bstack1l1111lll_opy_[size:]
  bstack1ll11lllll_opy_.append(bstack1l1111lll_opy_)
  return bstack1ll11lllll_opy_
def bstack1lll1111l1_opy_(args):
  if bstack1l111l_opy_ (u"ࠫ࠲ࡳ்ࠧ") in args and bstack1l111l_opy_ (u"ࠬࡶࡤࡣࠩ௎") in args:
    return True
  return False
def run_on_browserstack(bstack11ll111l_opy_=None, bstack111111111_opy_=None, bstack1lll1l1l11_opy_=False):
  global CONFIG
  global bstack1ll11lll1_opy_
  global bstack1ll111l11_opy_
  bstack111l11l11_opy_ = bstack1l111l_opy_ (u"࠭ࠧ௏")
  bstack1ll11lll1l_opy_(bstack11l1lll1_opy_, logger)
  if bstack11ll111l_opy_ and isinstance(bstack11ll111l_opy_, str):
    bstack11ll111l_opy_ = eval(bstack11ll111l_opy_)
  if bstack11ll111l_opy_:
    CONFIG = bstack11ll111l_opy_[bstack1l111l_opy_ (u"ࠧࡄࡑࡑࡊࡎࡍࠧௐ")]
    bstack1ll11lll1_opy_ = bstack11ll111l_opy_[bstack1l111l_opy_ (u"ࠨࡊࡘࡆࡤ࡛ࡒࡍࠩ௑")]
    bstack1ll111l11_opy_ = bstack11ll111l_opy_[bstack1l111l_opy_ (u"ࠩࡌࡗࡤࡇࡐࡑࡡࡄ࡙࡙ࡕࡍࡂࡖࡈࠫ௒")]
    bstack1l1ll1ll1_opy_.set_property(bstack1l111l_opy_ (u"ࠪࡍࡘࡥࡁࡑࡒࡢࡅ࡚࡚ࡏࡎࡃࡗࡉࠬ௓"), bstack1ll111l11_opy_)
    bstack111l11l11_opy_ = bstack1l111l_opy_ (u"ࠫࡵࡿࡴࡩࡱࡱࠫ௔")
  if not bstack1lll1l1l11_opy_:
    if len(sys.argv) <= 1:
      logger.critical(bstack1ll1111l1_opy_)
      return
    if sys.argv[1] == bstack1l111l_opy_ (u"ࠬ࠳࠭ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ௕") or sys.argv[1] == bstack1l111l_opy_ (u"࠭࠭ࡷࠩ௖"):
      logger.info(bstack1l111l_opy_ (u"ࠧࡃࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࠦࡐࡺࡶ࡫ࡳࡳࠦࡓࡅࡍࠣࡺࢀࢃࠧௗ").format(__version__))
      return
    if sys.argv[1] == bstack1l111l_opy_ (u"ࠨࡵࡨࡸࡺࡶࠧ௘"):
      bstack1l1111111_opy_()
      return
  args = sys.argv
  bstack111l1lll_opy_()
  global bstack1l1lll11_opy_
  global bstack1lll1l111_opy_
  global bstack1l1l11111_opy_
  global bstack11l1111l_opy_
  global bstack1ll1ll1ll1_opy_
  global bstack1l1l1l11l_opy_
  global bstack1l1l1lll1_opy_
  global bstack1l11111l_opy_
  global bstack1l11lll1l_opy_
  if not bstack111l11l11_opy_:
    if args[1] == bstack1l111l_opy_ (u"ࠩࡳࡽࡹ࡮࡯࡯ࠩ௙") or args[1] == bstack1l111l_opy_ (u"ࠪࡴࡾࡺࡨࡰࡰ࠶ࠫ௚"):
      bstack111l11l11_opy_ = bstack1l111l_opy_ (u"ࠫࡵࡿࡴࡩࡱࡱࠫ௛")
      args = args[2:]
    elif args[1] == bstack1l111l_opy_ (u"ࠬࡸ࡯ࡣࡱࡷࠫ௜"):
      bstack111l11l11_opy_ = bstack1l111l_opy_ (u"࠭ࡲࡰࡤࡲࡸࠬ௝")
      args = args[2:]
    elif args[1] == bstack1l111l_opy_ (u"ࠧࡱࡣࡥࡳࡹ࠭௞"):
      bstack111l11l11_opy_ = bstack1l111l_opy_ (u"ࠨࡲࡤࡦࡴࡺࠧ௟")
      args = args[2:]
    elif args[1] == bstack1l111l_opy_ (u"ࠩࡵࡳࡧࡵࡴ࠮࡫ࡱࡸࡪࡸ࡮ࡢ࡮ࠪ௠"):
      bstack111l11l11_opy_ = bstack1l111l_opy_ (u"ࠪࡶࡴࡨ࡯ࡵ࠯࡬ࡲࡹ࡫ࡲ࡯ࡣ࡯ࠫ௡")
      args = args[2:]
    elif args[1] == bstack1l111l_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷࠫ௢"):
      bstack111l11l11_opy_ = bstack1l111l_opy_ (u"ࠬࡶࡹࡵࡧࡶࡸࠬ௣")
      args = args[2:]
    elif args[1] == bstack1l111l_opy_ (u"࠭ࡢࡦࡪࡤࡺࡪ࠭௤"):
      bstack111l11l11_opy_ = bstack1l111l_opy_ (u"ࠧࡣࡧ࡫ࡥࡻ࡫ࠧ௥")
      args = args[2:]
    else:
      if not bstack1l111l_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࠫ௦") in CONFIG or str(CONFIG[bstack1l111l_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࠬ௧")]).lower() in [bstack1l111l_opy_ (u"ࠪࡴࡾࡺࡨࡰࡰࠪ௨"), bstack1l111l_opy_ (u"ࠫࡵࡿࡴࡩࡱࡱ࠷ࠬ௩")]:
        bstack111l11l11_opy_ = bstack1l111l_opy_ (u"ࠬࡶࡹࡵࡪࡲࡲࠬ௪")
        args = args[1:]
      elif str(CONFIG[bstack1l111l_opy_ (u"࠭ࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࠩ௫")]).lower() == bstack1l111l_opy_ (u"ࠧࡳࡱࡥࡳࡹ࠭௬"):
        bstack111l11l11_opy_ = bstack1l111l_opy_ (u"ࠨࡴࡲࡦࡴࡺࠧ௭")
        args = args[1:]
      elif str(CONFIG[bstack1l111l_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࠬ௮")]).lower() == bstack1l111l_opy_ (u"ࠪࡴࡦࡨ࡯ࡵࠩ௯"):
        bstack111l11l11_opy_ = bstack1l111l_opy_ (u"ࠫࡵࡧࡢࡰࡶࠪ௰")
        args = args[1:]
      elif str(CONFIG[bstack1l111l_opy_ (u"ࠬ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࠨ௱")]).lower() == bstack1l111l_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹ࠭௲"):
        bstack111l11l11_opy_ = bstack1l111l_opy_ (u"ࠧࡱࡻࡷࡩࡸࡺࠧ௳")
        args = args[1:]
      elif str(CONFIG[bstack1l111l_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࠫ௴")]).lower() == bstack1l111l_opy_ (u"ࠩࡥࡩ࡭ࡧࡶࡦࠩ௵"):
        bstack111l11l11_opy_ = bstack1l111l_opy_ (u"ࠪࡦࡪ࡮ࡡࡷࡧࠪ௶")
        args = args[1:]
      else:
        os.environ[bstack1l111l_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡊࡗࡇࡍࡆ࡙ࡒࡖࡐ࠭௷")] = bstack111l11l11_opy_
        bstack1ll1lllll_opy_(bstack11l1ll11_opy_)
  global bstack1l11111ll_opy_
  if bstack11ll111l_opy_:
    try:
      os.environ[bstack1l111l_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡋࡘࡁࡎࡇ࡚ࡓࡗࡑࠧ௸")] = bstack111l11l11_opy_
      bstack11111ll1l_opy_(bstack1llll1l1l1_opy_, CONFIG)
    except Exception as e:
      logger.debug(bstack11l111l1l_opy_.format(str(e)))
  global bstack11lll1l1_opy_
  global bstack1lllllll1l_opy_
  global bstack1ll1l1l1l_opy_
  global bstack1l1l11l1l_opy_
  global bstack1l1l11lll_opy_
  global bstack11l111111_opy_
  global bstack11lll1lll_opy_
  global bstack1l1ll11l_opy_
  global bstack1ll1lllll1_opy_
  global bstack111ll1l1l_opy_
  global bstack11l1l1l1_opy_
  global bstack1ll11l1l1_opy_
  global bstack1lll11111_opy_
  global bstack11ll11111_opy_
  global bstack1lllll1111_opy_
  global bstack1l111l11_opy_
  global bstack1lllll1ll_opy_
  global bstack111lll1l_opy_
  global bstack111ll1ll1_opy_
  try:
    from selenium import webdriver
    from selenium.webdriver.remote.webdriver import WebDriver
    bstack11lll1l1_opy_ = webdriver.Remote.__init__
    bstack1lllllll1l_opy_ = WebDriver.quit
    bstack11l1l1l1_opy_ = WebDriver.close
    bstack11ll11111_opy_ = WebDriver.get
  except Exception as e:
    pass
  try:
    import Browser
    from subprocess import Popen
    bstack1l11111ll_opy_ = Popen.__init__
  except Exception as e:
    pass
  if bstack1111ll11l_opy_(CONFIG):
    if bstack111lllll1_opy_() < version.parse(bstack11llll1l_opy_):
      logger.error(bstack1ll1l111l1_opy_.format(bstack111lllll1_opy_()))
    else:
      try:
        from selenium.webdriver.remote.remote_connection import RemoteConnection
        bstack1lllll1111_opy_ = RemoteConnection._get_proxy_url
      except Exception as e:
        logger.error(bstack11111l111_opy_.format(str(e)))
  if bstack111l11l11_opy_ != bstack1l111l_opy_ (u"࠭ࡰࡺࡶ࡫ࡳࡳ࠭௹") or (bstack111l11l11_opy_ == bstack1l111l_opy_ (u"ࠧࡱࡻࡷ࡬ࡴࡴࠧ௺") and not bstack11ll111l_opy_):
    bstack111l1111_opy_()
  if (bstack111l11l11_opy_ in [bstack1l111l_opy_ (u"ࠨࡲࡤࡦࡴࡺࠧ௻"), bstack1l111l_opy_ (u"ࠩࡵࡳࡧࡵࡴࠨ௼"), bstack1l111l_opy_ (u"ࠪࡶࡴࡨ࡯ࡵ࠯࡬ࡲࡹ࡫ࡲ࡯ࡣ࡯ࠫ௽")]):
    try:
      from robot import run_cli
      from robot.output import Output
      from robot.running.status import TestStatus
      from pabot.pabot import QueueItem
      from pabot import pabot
      try:
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCreator
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCache
        WebDriverCreator._get_ff_profile = bstack1lll1l11ll_opy_
        bstack1l1l11lll_opy_ = WebDriverCache.close
      except Exception as e:
        logger.warn(bstack11l11ll1_opy_ + str(e))
      try:
        from AppiumLibrary.utils.applicationcache import ApplicationCache
        bstack1l1l11l1l_opy_ = ApplicationCache.close
      except Exception as e:
        logger.debug(bstack1111l1l1l_opy_ + str(e))
    except Exception as e:
      bstack11l11lll_opy_(e, bstack11l11ll1_opy_)
    if bstack111l11l11_opy_ != bstack1l111l_opy_ (u"ࠫࡷࡵࡢࡰࡶ࠰࡭ࡳࡺࡥࡳࡰࡤࡰࠬ௾"):
      bstack11111ll11_opy_()
    bstack1ll1l1l1l_opy_ = Output.end_test
    bstack11l111111_opy_ = TestStatus.__init__
    bstack1l1ll11l_opy_ = pabot._run
    bstack1ll1lllll1_opy_ = QueueItem.__init__
    bstack111ll1l1l_opy_ = pabot._create_command_for_execution
    bstack111lll1l_opy_ = pabot._report_results
  if bstack111l11l11_opy_ == bstack1l111l_opy_ (u"ࠬࡨࡥࡩࡣࡹࡩࠬ௿"):
    try:
      from behave.runner import Runner
      from behave.model import Step
    except Exception as e:
      bstack11l11lll_opy_(e, bstack1lll11llll_opy_)
    bstack1ll11l1l1_opy_ = Runner.run_hook
    bstack1lll11111_opy_ = Step.run
  if bstack111l11l11_opy_ == bstack1l111l_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹ࠭ఀ"):
    try:
      bstack1lllll111_opy_.launch(CONFIG, {
        bstack1l111l_opy_ (u"ࠧࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࡢࡲࡦࡳࡥࠨఁ"): bstack1l111l_opy_ (u"ࠨࡒࡼࡸࡪࡹࡴࠨం"),
        bstack1l111l_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࡤࡼࡥࡳࡵ࡬ࡳࡳ࠭ః"): bstack1ll11l11_opy_.version(),
        bstack1l111l_opy_ (u"ࠪࡷࡩࡱ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨఄ"): __version__
      })
      from _pytest.config import Config
      bstack1l111l11_opy_ = Config.getoption
      from _pytest import runner
      bstack1lllll1ll_opy_ = runner._update_current_test_var
    except Exception as e:
      logger.warn(e, bstack1ll11l1l_opy_)
    try:
      from pytest_bdd import reporting
      bstack111ll1ll1_opy_ = reporting.runtest_makereport
    except Exception as e:
      logger.debug(bstack1l111l_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡶࡹࡵࡧࡶࡸ࠲ࡨࡤࡥࠢࡷࡳࠥࡸࡵ࡯ࠢࡳࡽࡹ࡫ࡳࡵ࠯ࡥࡨࡩࠦࡴࡦࡵࡷࡷࠬఅ"))
  if bstack111l11l11_opy_ == bstack1l111l_opy_ (u"ࠬࡶࡹࡵࡪࡲࡲࠬఆ"):
    bstack1lll1l111_opy_ = True
    if bstack11ll111l_opy_ and bstack1lll1l1l11_opy_:
      bstack1ll1ll1ll1_opy_ = CONFIG.get(bstack1l111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪఇ"), {}).get(bstack1l111l_opy_ (u"ࠧ࡭ࡱࡦࡥࡱࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩఈ"))
      bstack1lll111lll_opy_(bstack1l1ll1lll_opy_)
    elif bstack11ll111l_opy_:
      bstack1ll1ll1ll1_opy_ = CONFIG.get(bstack1l111l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࡌࡰࡥࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬఉ"), {}).get(bstack1l111l_opy_ (u"ࠩ࡯ࡳࡨࡧ࡬ࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫఊ"))
      global bstack1llllllll1_opy_
      try:
        if bstack1lll1111l1_opy_(bstack11ll111l_opy_[bstack1l111l_opy_ (u"ࠪࡪ࡮ࡲࡥࡠࡰࡤࡱࡪ࠭ఋ")]) and multiprocessing.current_process().name == bstack1l111l_opy_ (u"ࠫ࠵࠭ఌ"):
          bstack11ll111l_opy_[bstack1l111l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡢࡲࡦࡳࡥࠨ఍")].remove(bstack1l111l_opy_ (u"࠭࠭࡮ࠩఎ"))
          bstack11ll111l_opy_[bstack1l111l_opy_ (u"ࠧࡧ࡫࡯ࡩࡤࡴࡡ࡮ࡧࠪఏ")].remove(bstack1l111l_opy_ (u"ࠨࡲࡧࡦࠬఐ"))
          bstack11ll111l_opy_[bstack1l111l_opy_ (u"ࠩࡩ࡭ࡱ࡫࡟࡯ࡣࡰࡩࠬ఑")] = bstack11ll111l_opy_[bstack1l111l_opy_ (u"ࠪࡪ࡮ࡲࡥࡠࡰࡤࡱࡪ࠭ఒ")][0]
          with open(bstack11ll111l_opy_[bstack1l111l_opy_ (u"ࠫ࡫࡯࡬ࡦࡡࡱࡥࡲ࡫ࠧఓ")], bstack1l111l_opy_ (u"ࠬࡸࠧఔ")) as f:
            bstack11ll1ll11_opy_ = f.read()
          bstack11ll1lll1_opy_ = bstack1l111l_opy_ (u"ࠨࠢࠣࡨࡵࡳࡲࠦࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤࡹࡤ࡬ࠢ࡬ࡱࡵࡵࡲࡵࠢࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠ࡫ࡱ࡭ࡹ࡯ࡡ࡭࡫ࡽࡩࡀࠦࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡯࡮ࡪࡶ࡬ࡥࡱ࡯ࡺࡦࠪࡾࢁ࠮ࡁࠠࡧࡴࡲࡱࠥࡶࡤࡣࠢ࡬ࡱࡵࡵࡲࡵࠢࡓࡨࡧࡁࠠࡰࡩࡢࡨࡧࠦ࠽ࠡࡒࡧࡦ࠳ࡪ࡯ࡠࡤࡵࡩࡦࡱ࠻ࠋࡦࡨࡪࠥࡳ࡯ࡥࡡࡥࡶࡪࡧ࡫ࠩࡵࡨࡰ࡫࠲ࠠࡢࡴࡪ࠰ࠥࡺࡥ࡮ࡲࡲࡶࡦࡸࡹࠡ࠿ࠣ࠴࠮ࡀࠊࠡࠢࡷࡶࡾࡀࠊࠡࠢࠣࠤࡦࡸࡧࠡ࠿ࠣࡷࡹࡸࠨࡪࡰࡷࠬࡦࡸࡧࠪ࠭࠴࠴࠮ࠐࠠࠡࡧࡻࡧࡪࡶࡴࠡࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤࡦࡹࠠࡦ࠼ࠍࠤࠥࠦࠠࡱࡣࡶࡷࠏࠦࠠࡰࡩࡢࡨࡧ࠮ࡳࡦ࡮ࡩ࠰ࡦࡸࡧ࠭ࡶࡨࡱࡵࡵࡲࡢࡴࡼ࠭ࠏࡖࡤࡣ࠰ࡧࡳࡤࡨࠠ࠾ࠢࡰࡳࡩࡥࡢࡳࡧࡤ࡯ࠏࡖࡤࡣ࠰ࡧࡳࡤࡨࡲࡦࡣ࡮ࠤࡂࠦ࡭ࡰࡦࡢࡦࡷ࡫ࡡ࡬ࠌࡓࡨࡧ࠮ࠩ࠯ࡵࡨࡸࡤࡺࡲࡢࡥࡨࠬ࠮ࡢ࡮ࠣࠤࠥక").format(str(bstack11ll111l_opy_))
          bstack1ll11ll11_opy_ = bstack11ll1lll1_opy_ + bstack11ll1ll11_opy_
          bstack111l1l1ll_opy_ = bstack11ll111l_opy_[bstack1l111l_opy_ (u"ࠧࡧ࡫࡯ࡩࡤࡴࡡ࡮ࡧࠪఖ")] + bstack1l111l_opy_ (u"ࠨࡡࡥࡷࡹࡧࡣ࡬ࡡࡷࡩࡲࡶ࠮ࡱࡻࠪగ")
          with open(bstack111l1l1ll_opy_, bstack1l111l_opy_ (u"ࠩࡺࠫఘ")):
            pass
          with open(bstack111l1l1ll_opy_, bstack1l111l_opy_ (u"ࠥࡻ࠰ࠨఙ")) as f:
            f.write(bstack1ll11ll11_opy_)
          import subprocess
          process_data = subprocess.run([bstack1l111l_opy_ (u"ࠦࡵࡿࡴࡩࡱࡱࠦచ"), bstack111l1l1ll_opy_])
          if os.path.exists(bstack111l1l1ll_opy_):
            os.unlink(bstack111l1l1ll_opy_)
          os._exit(process_data.returncode)
        else:
          if bstack1lll1111l1_opy_(bstack11ll111l_opy_[bstack1l111l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡢࡲࡦࡳࡥࠨఛ")]):
            bstack11ll111l_opy_[bstack1l111l_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩజ")].remove(bstack1l111l_opy_ (u"ࠧ࠮࡯ࠪఝ"))
            bstack11ll111l_opy_[bstack1l111l_opy_ (u"ࠨࡨ࡬ࡰࡪࡥ࡮ࡢ࡯ࡨࠫఞ")].remove(bstack1l111l_opy_ (u"ࠩࡳࡨࡧ࠭ట"))
            bstack11ll111l_opy_[bstack1l111l_opy_ (u"ࠪࡪ࡮ࡲࡥࡠࡰࡤࡱࡪ࠭ఠ")] = bstack11ll111l_opy_[bstack1l111l_opy_ (u"ࠫ࡫࡯࡬ࡦࡡࡱࡥࡲ࡫ࠧడ")][0]
          bstack1lll111lll_opy_(bstack1l1ll1lll_opy_)
          sys.path.append(os.path.dirname(os.path.abspath(bstack11ll111l_opy_[bstack1l111l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡢࡲࡦࡳࡥࠨఢ")])))
          sys.argv = sys.argv[2:]
          mod_globals = globals()
          mod_globals[bstack1l111l_opy_ (u"࠭࡟ࡠࡰࡤࡱࡪࡥ࡟ࠨణ")] = bstack1l111l_opy_ (u"ࠧࡠࡡࡰࡥ࡮ࡴ࡟ࡠࠩత")
          mod_globals[bstack1l111l_opy_ (u"ࠨࡡࡢࡪ࡮ࡲࡥࡠࡡࠪథ")] = os.path.abspath(bstack11ll111l_opy_[bstack1l111l_opy_ (u"ࠩࡩ࡭ࡱ࡫࡟࡯ࡣࡰࡩࠬద")])
          exec(open(bstack11ll111l_opy_[bstack1l111l_opy_ (u"ࠪࡪ࡮ࡲࡥࡠࡰࡤࡱࡪ࠭ధ")]).read(), mod_globals)
      except BaseException as e:
        try:
          traceback.print_exc()
          logger.error(bstack1l111l_opy_ (u"ࠫࡈࡧࡵࡨࡪࡷࠤࡊࡾࡣࡦࡲࡷ࡭ࡴࡴ࠺ࠡࡽࢀࠫన").format(str(e)))
          for driver in bstack1llllllll1_opy_:
            bstack111111111_opy_.append({
              bstack1l111l_opy_ (u"ࠬࡴࡡ࡮ࡧࠪ఩"): bstack11ll111l_opy_[bstack1l111l_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩప")],
              bstack1l111l_opy_ (u"ࠧࡦࡴࡵࡳࡷ࠭ఫ"): str(e),
              bstack1l111l_opy_ (u"ࠨ࡫ࡱࡨࡪࡾࠧబ"): multiprocessing.current_process().name
            })
            driver.execute_script(
              bstack1l111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࠨࡡࡤࡶ࡬ࡳࡳࠨ࠺ࠡࠤࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳ࡙ࡴࡢࡶࡸࡷࠧ࠲ࠠࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ࠿ࠦࡻࠣࡵࡷࡥࡹࡻࡳࠣ࠼ࠥࡪࡦ࡯࡬ࡦࡦࠥ࠰ࠥࠨࡲࡦࡣࡶࡳࡳࠨ࠺ࠡࠩభ") + json.dumps(
                bstack1l111l_opy_ (u"ࠥࡗࡪࡹࡳࡪࡱࡱࠤ࡫ࡧࡩ࡭ࡧࡧࠤࡼ࡯ࡴࡩ࠼ࠣࡠࡳࠨమ") + str(e)) + bstack1l111l_opy_ (u"ࠫࢂࢃࠧయ"))
        except Exception:
          pass
      finally:
        try:
          for driver in bstack1llllllll1_opy_:
            driver.quit()
        except Exception as e:
          pass
    else:
      bstack1111ll1l1_opy_()
      bstack1lll111l1_opy_()
      bstack1llll1l1_opy_ = {
        bstack1l111l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡢࡲࡦࡳࡥࠨర"): args[0],
        bstack1l111l_opy_ (u"࠭ࡃࡐࡐࡉࡍࡌ࠭ఱ"): CONFIG,
        bstack1l111l_opy_ (u"ࠧࡉࡗࡅࡣ࡚ࡘࡌࠨల"): bstack1ll11lll1_opy_,
        bstack1l111l_opy_ (u"ࠨࡋࡖࡣࡆࡖࡐࡠࡃࡘࡘࡔࡓࡁࡕࡇࠪళ"): bstack1ll111l11_opy_
      }
      if bstack1l111l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬఴ") in CONFIG:
        bstack1ll11ll1_opy_ = []
        manager = multiprocessing.Manager()
        bstack1ll11lll_opy_ = manager.list()
        if bstack1lll1111l1_opy_(args):
          for index, platform in enumerate(CONFIG[bstack1l111l_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭వ")]):
            if index == 0:
              bstack1llll1l1_opy_[bstack1l111l_opy_ (u"ࠫ࡫࡯࡬ࡦࡡࡱࡥࡲ࡫ࠧశ")] = args
            bstack1ll11ll1_opy_.append(multiprocessing.Process(name=str(index),
                                                       target=run_on_browserstack,
                                                       args=(bstack1llll1l1_opy_, bstack1ll11lll_opy_)))
        else:
          for index, platform in enumerate(CONFIG[bstack1l111l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨష")]):
            bstack1ll11ll1_opy_.append(multiprocessing.Process(name=str(index),
                                                       target=run_on_browserstack,
                                                       args=(bstack1llll1l1_opy_, bstack1ll11lll_opy_)))
        for t in bstack1ll11ll1_opy_:
          t.start()
        for t in bstack1ll11ll1_opy_:
          t.join()
        bstack1l1l1lll1_opy_ = list(bstack1ll11lll_opy_)
      else:
        if bstack1lll1111l1_opy_(args):
          bstack1llll1l1_opy_[bstack1l111l_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩస")] = args
          test = multiprocessing.Process(name=str(0),
                                         target=run_on_browserstack, args=(bstack1llll1l1_opy_,))
          test.start()
          test.join()
        else:
          bstack1lll111lll_opy_(bstack1l1ll1lll_opy_)
          sys.path.append(os.path.dirname(os.path.abspath(args[0])))
          mod_globals = globals()
          mod_globals[bstack1l111l_opy_ (u"ࠧࡠࡡࡱࡥࡲ࡫࡟ࡠࠩహ")] = bstack1l111l_opy_ (u"ࠨࡡࡢࡱࡦ࡯࡮ࡠࡡࠪ఺")
          mod_globals[bstack1l111l_opy_ (u"ࠩࡢࡣ࡫࡯࡬ࡦࡡࡢࠫ఻")] = os.path.abspath(args[0])
          sys.argv = sys.argv[2:]
          exec(open(args[0]).read(), mod_globals)
  elif bstack111l11l11_opy_ == bstack1l111l_opy_ (u"ࠪࡴࡦࡨ࡯ࡵ఼ࠩ") or bstack111l11l11_opy_ == bstack1l111l_opy_ (u"ࠫࡷࡵࡢࡰࡶࠪఽ"):
    try:
      from pabot import pabot
    except Exception as e:
      bstack11l11lll_opy_(e, bstack11l11ll1_opy_)
    bstack1111ll1l1_opy_()
    bstack1lll111lll_opy_(bstack11ll111ll_opy_)
    if bstack1l111l_opy_ (u"ࠬ࠳࠭ࡱࡴࡲࡧࡪࡹࡳࡦࡵࠪా") in args:
      i = args.index(bstack1l111l_opy_ (u"࠭࠭࠮ࡲࡵࡳࡨ࡫ࡳࡴࡧࡶࠫి"))
      args.pop(i)
      args.pop(i)
    args.insert(0, str(bstack1l1lll11_opy_))
    args.insert(0, str(bstack1l111l_opy_ (u"ࠧ࠮࠯ࡳࡶࡴࡩࡥࡴࡵࡨࡷࠬీ")))
    pabot.main(args)
  elif bstack111l11l11_opy_ == bstack1l111l_opy_ (u"ࠨࡴࡲࡦࡴࡺ࠭ࡪࡰࡷࡩࡷࡴࡡ࡭ࠩు"):
    try:
      from robot import run_cli
    except Exception as e:
      bstack11l11lll_opy_(e, bstack11l11ll1_opy_)
    for a in args:
      if bstack1l111l_opy_ (u"ࠩࡅࡗ࡙ࡇࡃࡌࡒࡏࡅ࡙ࡌࡏࡓࡏࡌࡒࡉࡋࡘࠨూ") in a:
        bstack11l1111l_opy_ = int(a.split(bstack1l111l_opy_ (u"ࠪ࠾ࠬృ"))[1])
      if bstack1l111l_opy_ (u"ࠫࡇ࡙ࡔࡂࡅࡎࡈࡊࡌࡌࡐࡅࡄࡐࡎࡊࡅࡏࡖࡌࡊࡎࡋࡒࠨౄ") in a:
        bstack1ll1ll1ll1_opy_ = str(a.split(bstack1l111l_opy_ (u"ࠬࡀࠧ౅"))[1])
      if bstack1l111l_opy_ (u"࠭ࡂࡔࡖࡄࡇࡐࡉࡌࡊࡃࡕࡋࡘ࠭ె") in a:
        bstack1l1l1l11l_opy_ = str(a.split(bstack1l111l_opy_ (u"ࠧ࠻ࠩే"))[1])
    bstack1l11l11l_opy_ = None
    if bstack1l111l_opy_ (u"ࠨ࠯࠰ࡦࡸࡺࡡࡤ࡭ࡢ࡭ࡹ࡫࡭ࡠ࡫ࡱࡨࡪࡾࠧై") in args:
      i = args.index(bstack1l111l_opy_ (u"ࠩ࠰࠱ࡧࡹࡴࡢࡥ࡮ࡣ࡮ࡺࡥ࡮ࡡ࡬ࡲࡩ࡫ࡸࠨ౉"))
      args.pop(i)
      bstack1l11l11l_opy_ = args.pop(i)
    if bstack1l11l11l_opy_ is not None:
      global bstack111l1l1l_opy_
      bstack111l1l1l_opy_ = bstack1l11l11l_opy_
    bstack1lll111lll_opy_(bstack11ll111ll_opy_)
    run_cli(args)
  elif bstack111l11l11_opy_ == bstack1l111l_opy_ (u"ࠪࡴࡾࡺࡥࡴࡶࠪొ"):
    bstack1111lllll_opy_ = bstack1ll11l11_opy_(args, logger, CONFIG, bstack1111l11l1_opy_)
    bstack1111lllll_opy_.bstack1ll1l1l1_opy_()
    bstack1111ll1l1_opy_()
    bstack1l1l11111_opy_ = True
    bstack1l11lll1l_opy_ = bstack1111lllll_opy_.bstack1lll1lll_opy_()
    bstack1111lllll_opy_.bstack1llll1l1_opy_(bstack11l1l1l1l_opy_)
    bstack1l11111l_opy_ = bstack1111lllll_opy_.bstack1ll1l111_opy_(bstack11lll11ll_opy_, {
      bstack1l111l_opy_ (u"ࠫࡍ࡛ࡂࡠࡗࡕࡐࠬో"): bstack1ll11lll1_opy_,
      bstack1l111l_opy_ (u"ࠬࡏࡓࡠࡃࡓࡔࡤࡇࡕࡕࡑࡐࡅ࡙ࡋࠧౌ"): bstack1ll111l11_opy_,
      bstack1l111l_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡇࡕࡕࡑࡐࡅ࡙ࡏࡏࡏ్ࠩ"): bstack1111l11l1_opy_
    })
  elif bstack111l11l11_opy_ == bstack1l111l_opy_ (u"ࠧࡣࡧ࡫ࡥࡻ࡫ࠧ౎"):
    try:
      from behave.__main__ import main as bstack11lllll11_opy_
      from behave.configuration import Configuration
    except Exception as e:
      bstack11l11lll_opy_(e, bstack1lll11llll_opy_)
    bstack1111ll1l1_opy_()
    bstack1l1l11111_opy_ = True
    bstack1ll111l1_opy_ = 1
    if bstack1l111l_opy_ (u"ࠨࡲࡤࡶࡦࡲ࡬ࡦ࡮ࡶࡔࡪࡸࡐ࡭ࡣࡷࡪࡴࡸ࡭ࠨ౏") in CONFIG:
      bstack1ll111l1_opy_ = CONFIG[bstack1l111l_opy_ (u"ࠩࡳࡥࡷࡧ࡬࡭ࡧ࡯ࡷࡕ࡫ࡲࡑ࡮ࡤࡸ࡫ࡵࡲ࡮ࠩ౐")]
    bstack1llll11ll_opy_ = int(bstack1ll111l1_opy_) * int(len(CONFIG[bstack1l111l_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭౑")]))
    config = Configuration(args)
    bstack1111l11ll_opy_ = config.paths
    if len(bstack1111l11ll_opy_) == 0:
      import glob
      pattern = bstack1l111l_opy_ (u"ࠫ࠯࠰࠯ࠫ࠰ࡩࡩࡦࡺࡵࡳࡧࠪ౒")
      bstack111ll111_opy_ = glob.glob(pattern, recursive=True)
      args.extend(bstack111ll111_opy_)
      config = Configuration(args)
      bstack1111l11ll_opy_ = config.paths
    bstack1ll1llll_opy_ = [os.path.normpath(item) for item in bstack1111l11ll_opy_]
    bstack1ll1l1l1l1_opy_ = [os.path.normpath(item) for item in args]
    bstack1lll1ll1ll_opy_ = [item for item in bstack1ll1l1l1l1_opy_ if item not in bstack1ll1llll_opy_]
    import platform as pf
    if pf.system().lower() == bstack1l111l_opy_ (u"ࠬࡽࡩ࡯ࡦࡲࡻࡸ࠭౓"):
      from pathlib import PureWindowsPath, PurePosixPath
      bstack1ll1llll_opy_ = [str(PurePosixPath(PureWindowsPath(bstack11llll11l_opy_)))
                    for bstack11llll11l_opy_ in bstack1ll1llll_opy_]
    bstack1ll1lll1_opy_ = []
    for spec in bstack1ll1llll_opy_:
      bstack1lllll11_opy_ = []
      bstack1lllll11_opy_ += bstack1lll1ll1ll_opy_
      bstack1lllll11_opy_.append(spec)
      bstack1ll1lll1_opy_.append(bstack1lllll11_opy_)
    execution_items = []
    for bstack1lllll11_opy_ in bstack1ll1lll1_opy_:
      for index, _ in enumerate(CONFIG[bstack1l111l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩ౔")]):
        item = {}
        item[bstack1l111l_opy_ (u"ࠧࡢࡴࡪౕࠫ")] = bstack1l111l_opy_ (u"ࠨౖࠢࠪ").join(bstack1lllll11_opy_)
        item[bstack1l111l_opy_ (u"ࠩ࡬ࡲࡩ࡫ࡸࠨ౗")] = index
        execution_items.append(item)
    bstack1ll1l1lll_opy_ = bstack1lll1111_opy_(execution_items, bstack1llll11ll_opy_)
    for execution_item in bstack1ll1l1lll_opy_:
      bstack1ll11ll1_opy_ = []
      for item in execution_item:
        bstack1ll11ll1_opy_.append(bstack1l11l1lll_opy_(name=str(item[bstack1l111l_opy_ (u"ࠪ࡭ࡳࡪࡥࡹࠩౘ")]),
                                             target=bstack1111ll1l_opy_,
                                             args=(item[bstack1l111l_opy_ (u"ࠫࡦࡸࡧࠨౙ")],)))
      for t in bstack1ll11ll1_opy_:
        t.start()
      for t in bstack1ll11ll1_opy_:
        t.join()
  else:
    bstack1ll1lllll_opy_(bstack11l1ll11_opy_)
  if not bstack11ll111l_opy_:
    bstack1ll111ll1_opy_()
def browserstack_initialize(bstack1l1ll11l1_opy_=None):
  run_on_browserstack(bstack1l1ll11l1_opy_, None, True)
def bstack1ll111ll1_opy_():
  bstack1lllll111_opy_.stop()
  bstack1lllll111_opy_.bstack1llll1111_opy_()
  [bstack1llllll11l_opy_, bstack1l1l1lll_opy_] = bstack111l111l_opy_()
  if bstack1llllll11l_opy_ is not None and bstack11ll1ll1l_opy_() != -1:
    sessions = bstack11lll1ll1_opy_(bstack1llllll11l_opy_)
    bstack1l11l1ll_opy_(sessions, bstack1l1l1lll_opy_)
def bstack1lll11ll11_opy_(bstack1ll1llll1l_opy_):
  if bstack1ll1llll1l_opy_:
    return bstack1ll1llll1l_opy_.capitalize()
  else:
    return bstack1ll1llll1l_opy_
def bstack1ll1l1ll1l_opy_(bstack1111l1l11_opy_):
  if bstack1l111l_opy_ (u"ࠬࡴࡡ࡮ࡧࠪౚ") in bstack1111l1l11_opy_ and bstack1111l1l11_opy_[bstack1l111l_opy_ (u"࠭࡮ࡢ࡯ࡨࠫ౛")] != bstack1l111l_opy_ (u"ࠧࠨ౜"):
    return bstack1111l1l11_opy_[bstack1l111l_opy_ (u"ࠨࡰࡤࡱࡪ࠭ౝ")]
  else:
    bstack1llll111ll_opy_ = bstack1l111l_opy_ (u"ࠤࠥ౞")
    if bstack1l111l_opy_ (u"ࠪࡨࡪࡼࡩࡤࡧࠪ౟") in bstack1111l1l11_opy_ and bstack1111l1l11_opy_[bstack1l111l_opy_ (u"ࠫࡩ࡫ࡶࡪࡥࡨࠫౠ")] != None:
      bstack1llll111ll_opy_ += bstack1111l1l11_opy_[bstack1l111l_opy_ (u"ࠬࡪࡥࡷ࡫ࡦࡩࠬౡ")] + bstack1l111l_opy_ (u"ࠨࠬࠡࠤౢ")
      if bstack1111l1l11_opy_[bstack1l111l_opy_ (u"ࠧࡰࡵࠪౣ")] == bstack1l111l_opy_ (u"ࠣ࡫ࡲࡷࠧ౤"):
        bstack1llll111ll_opy_ += bstack1l111l_opy_ (u"ࠤ࡬ࡓࡘࠦࠢ౥")
      bstack1llll111ll_opy_ += (bstack1111l1l11_opy_[bstack1l111l_opy_ (u"ࠪࡳࡸࡥࡶࡦࡴࡶ࡭ࡴࡴࠧ౦")] or bstack1l111l_opy_ (u"ࠫࠬ౧"))
      return bstack1llll111ll_opy_
    else:
      bstack1llll111ll_opy_ += bstack1lll11ll11_opy_(bstack1111l1l11_opy_[bstack1l111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࠭౨")]) + bstack1l111l_opy_ (u"ࠨࠠࠣ౩") + (
              bstack1111l1l11_opy_[bstack1l111l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡠࡸࡨࡶࡸ࡯࡯࡯ࠩ౪")] or bstack1l111l_opy_ (u"ࠨࠩ౫")) + bstack1l111l_opy_ (u"ࠤ࠯ࠤࠧ౬")
      if bstack1111l1l11_opy_[bstack1l111l_opy_ (u"ࠪࡳࡸ࠭౭")] == bstack1l111l_opy_ (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧ౮"):
        bstack1llll111ll_opy_ += bstack1l111l_opy_ (u"ࠧ࡝ࡩ࡯ࠢࠥ౯")
      bstack1llll111ll_opy_ += bstack1111l1l11_opy_[bstack1l111l_opy_ (u"࠭࡯ࡴࡡࡹࡩࡷࡹࡩࡰࡰࠪ౰")] or bstack1l111l_opy_ (u"ࠧࠨ౱")
      return bstack1llll111ll_opy_
def bstack1llll1111l_opy_(bstack11llll1ll_opy_):
  if bstack11llll1ll_opy_ == bstack1l111l_opy_ (u"ࠣࡦࡲࡲࡪࠨ౲"):
    return bstack1l111l_opy_ (u"ࠩ࠿ࡸࡩࠦࡣ࡭ࡣࡶࡷࡂࠨࡢࡴࡶࡤࡧࡰ࠳ࡤࡢࡶࡤࠦࠥࡹࡴࡺ࡮ࡨࡁࠧࡩ࡯࡭ࡱࡵ࠾࡬ࡸࡥࡦࡰ࠾ࠦࡃࡂࡦࡰࡰࡷࠤࡨࡵ࡬ࡰࡴࡀࠦ࡬ࡸࡥࡦࡰࠥࡂࡈࡵ࡭ࡱ࡮ࡨࡸࡪࡪ࠼࠰ࡨࡲࡲࡹࡄ࠼࠰ࡶࡧࡂࠬ౳")
  elif bstack11llll1ll_opy_ == bstack1l111l_opy_ (u"ࠥࡪࡦ࡯࡬ࡦࡦࠥ౴"):
    return bstack1l111l_opy_ (u"ࠫࡁࡺࡤࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡶࡸࡦࡩ࡫࠮ࡦࡤࡸࡦࠨࠠࡴࡶࡼࡰࡪࡃࠢࡤࡱ࡯ࡳࡷࡀࡲࡦࡦ࠾ࠦࡃࡂࡦࡰࡰࡷࠤࡨࡵ࡬ࡰࡴࡀࠦࡷ࡫ࡤࠣࡀࡉࡥ࡮ࡲࡥࡥ࠾࠲ࡪࡴࡴࡴ࠿࠾࠲ࡸࡩࡄࠧ౵")
  elif bstack11llll1ll_opy_ == bstack1l111l_opy_ (u"ࠧࡶࡡࡴࡵࡨࡨࠧ౶"):
    return bstack1l111l_opy_ (u"࠭࠼ࡵࡦࠣࡧࡱࡧࡳࡴ࠿ࠥࡦࡸࡺࡡࡤ࡭࠰ࡨࡦࡺࡡࠣࠢࡶࡸࡾࡲࡥ࠾ࠤࡦࡳࡱࡵࡲ࠻ࡩࡵࡩࡪࡴ࠻ࠣࡀ࠿ࡪࡴࡴࡴࠡࡥࡲࡰࡴࡸ࠽ࠣࡩࡵࡩࡪࡴࠢ࠿ࡒࡤࡷࡸ࡫ࡤ࠽࠱ࡩࡳࡳࡺ࠾࠽࠱ࡷࡨࡃ࠭౷")
  elif bstack11llll1ll_opy_ == bstack1l111l_opy_ (u"ࠢࡦࡴࡵࡳࡷࠨ౸"):
    return bstack1l111l_opy_ (u"ࠨ࠾ࡷࡨࠥࡩ࡬ࡢࡵࡶࡁࠧࡨࡳࡵࡣࡦ࡯࠲ࡪࡡࡵࡣࠥࠤࡸࡺࡹ࡭ࡧࡀࠦࡨࡵ࡬ࡰࡴ࠽ࡶࡪࡪ࠻ࠣࡀ࠿ࡪࡴࡴࡴࠡࡥࡲࡰࡴࡸ࠽ࠣࡴࡨࡨࠧࡄࡅࡳࡴࡲࡶࡁ࠵ࡦࡰࡰࡷࡂࡁ࠵ࡴࡥࡀࠪ౹")
  elif bstack11llll1ll_opy_ == bstack1l111l_opy_ (u"ࠤࡷ࡭ࡲ࡫࡯ࡶࡶࠥ౺"):
    return bstack1l111l_opy_ (u"ࠪࡀࡹࡪࠠࡤ࡮ࡤࡷࡸࡃࠢࡣࡵࡷࡥࡨࡱ࠭ࡥࡣࡷࡥࠧࠦࡳࡵࡻ࡯ࡩࡂࠨࡣࡰ࡮ࡲࡶ࠿ࠩࡥࡦࡣ࠶࠶࠻ࡁࠢ࠿࠾ࡩࡳࡳࡺࠠࡤࡱ࡯ࡳࡷࡃࠢࠤࡧࡨࡥ࠸࠸࠶ࠣࡀࡗ࡭ࡲ࡫࡯ࡶࡶ࠿࠳࡫ࡵ࡮ࡵࡀ࠿࠳ࡹࡪ࠾ࠨ౻")
  elif bstack11llll1ll_opy_ == bstack1l111l_opy_ (u"ࠦࡷࡻ࡮࡯࡫ࡱ࡫ࠧ౼"):
    return bstack1l111l_opy_ (u"ࠬࡂࡴࡥࠢࡦࡰࡦࡹࡳ࠾ࠤࡥࡷࡹࡧࡣ࡬࠯ࡧࡥࡹࡧࠢࠡࡵࡷࡽࡱ࡫࠽ࠣࡥࡲࡰࡴࡸ࠺ࡣ࡮ࡤࡧࡰࡁࠢ࠿࠾ࡩࡳࡳࡺࠠࡤࡱ࡯ࡳࡷࡃࠢࡣ࡮ࡤࡧࡰࠨ࠾ࡓࡷࡱࡲ࡮ࡴࡧ࠽࠱ࡩࡳࡳࡺ࠾࠽࠱ࡷࡨࡃ࠭౽")
  else:
    return bstack1l111l_opy_ (u"࠭࠼ࡵࡦࠣࡥࡱ࡯ࡧ࡯࠿ࠥࡧࡪࡴࡴࡦࡴࠥࠤࡨࡲࡡࡴࡵࡀࠦࡧࡹࡴࡢࡥ࡮࠱ࡩࡧࡴࡢࠤࠣࡷࡹࡿ࡬ࡦ࠿ࠥࡧࡴࡲ࡯ࡳ࠼ࡥࡰࡦࡩ࡫࠼ࠤࡁࡀ࡫ࡵ࡮ࡵࠢࡦࡳࡱࡵࡲ࠾ࠤࡥࡰࡦࡩ࡫ࠣࡀࠪ౾") + bstack1lll11ll11_opy_(
      bstack11llll1ll_opy_) + bstack1l111l_opy_ (u"ࠧ࠽࠱ࡩࡳࡳࡺ࠾࠽࠱ࡷࡨࡃ࠭౿")
def bstack1ll1ll1111_opy_(session):
  return bstack1l111l_opy_ (u"ࠨ࠾ࡷࡶࠥࡩ࡬ࡢࡵࡶࡁࠧࡨࡳࡵࡣࡦ࡯࠲ࡸ࡯ࡸࠤࡁࡀࡹࡪࠠࡤ࡮ࡤࡷࡸࡃࠢࡣࡵࡷࡥࡨࡱ࠭ࡥࡣࡷࡥࠥࡹࡥࡴࡵ࡬ࡳࡳ࠳࡮ࡢ࡯ࡨࠦࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࡼࡿࠥࠤࡹࡧࡲࡨࡧࡷࡁࠧࡥࡢ࡭ࡣࡱ࡯ࠧࡄࡻࡾ࠾࠲ࡥࡃࡂ࠯ࡵࡦࡁࡿࢂࢁࡽ࠽ࡶࡧࠤࡦࡲࡩࡨࡰࡀࠦࡨ࡫࡮ࡵࡧࡵࠦࠥࡩ࡬ࡢࡵࡶࡁࠧࡨࡳࡵࡣࡦ࡯࠲ࡪࡡࡵࡣࠥࡂࢀࢃ࠼࠰ࡶࡧࡂࡁࡺࡤࠡࡣ࡯࡭࡬ࡴ࠽ࠣࡥࡨࡲࡹ࡫ࡲࠣࠢࡦࡰࡦࡹࡳ࠾ࠤࡥࡷࡹࡧࡣ࡬࠯ࡧࡥࡹࡧࠢ࠿ࡽࢀࡀ࠴ࡺࡤ࠿࠾ࡷࡨࠥࡧ࡬ࡪࡩࡱࡁࠧࡩࡥ࡯ࡶࡨࡶࠧࠦࡣ࡭ࡣࡶࡷࡂࠨࡢࡴࡶࡤࡧࡰ࠳ࡤࡢࡶࡤࠦࡃࢁࡽ࠽࠱ࡷࡨࡃࡂࡴࡥࠢࡤࡰ࡮࡭࡮࠾ࠤࡦࡩࡳࡺࡥࡳࠤࠣࡧࡱࡧࡳࡴ࠿ࠥࡦࡸࡺࡡࡤ࡭࠰ࡨࡦࡺࡡࠣࡀࡾࢁࡁ࠵ࡴࡥࡀ࠿࠳ࡹࡸ࠾ࠨಀ").format(
    session[bstack1l111l_opy_ (u"ࠩࡳࡹࡧࡲࡩࡤࡡࡸࡶࡱ࠭ಁ")], bstack1ll1l1ll1l_opy_(session), bstack1llll1111l_opy_(session[bstack1l111l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡶࡸࡦࡺࡵࡴࠩಂ")]),
    bstack1llll1111l_opy_(session[bstack1l111l_opy_ (u"ࠫࡸࡺࡡࡵࡷࡶࠫಃ")]),
    bstack1lll11ll11_opy_(session[bstack1l111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࠭಄")] or session[bstack1l111l_opy_ (u"࠭ࡤࡦࡸ࡬ࡧࡪ࠭ಅ")] or bstack1l111l_opy_ (u"ࠧࠨಆ")) + bstack1l111l_opy_ (u"ࠣࠢࠥಇ") + (session[bstack1l111l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡢࡺࡪࡸࡳࡪࡱࡱࠫಈ")] or bstack1l111l_opy_ (u"ࠪࠫಉ")),
    session[bstack1l111l_opy_ (u"ࠫࡴࡹࠧಊ")] + bstack1l111l_opy_ (u"ࠧࠦࠢಋ") + session[bstack1l111l_opy_ (u"࠭࡯ࡴࡡࡹࡩࡷࡹࡩࡰࡰࠪಌ")], session[bstack1l111l_opy_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ಍")] or bstack1l111l_opy_ (u"ࠨࠩಎ"),
    session[bstack1l111l_opy_ (u"ࠩࡦࡶࡪࡧࡴࡦࡦࡢࡥࡹ࠭ಏ")] if session[bstack1l111l_opy_ (u"ࠪࡧࡷ࡫ࡡࡵࡧࡧࡣࡦࡺࠧಐ")] else bstack1l111l_opy_ (u"ࠫࠬ಑"))
def bstack1l11l1ll_opy_(sessions, bstack1l1l1lll_opy_):
  try:
    bstack1111l1l1_opy_ = bstack1l111l_opy_ (u"ࠧࠨಒ")
    if not os.path.exists(bstack1lll1ll11_opy_):
      os.mkdir(bstack1lll1ll11_opy_)
    with open(os.path.join(os.path.dirname(os.path.realpath(__file__)), bstack1l111l_opy_ (u"࠭ࡡࡴࡵࡨࡸࡸ࠵ࡲࡦࡲࡲࡶࡹ࠴ࡨࡵ࡯࡯ࠫಓ")), bstack1l111l_opy_ (u"ࠧࡳࠩಔ")) as f:
      bstack1111l1l1_opy_ = f.read()
    bstack1111l1l1_opy_ = bstack1111l1l1_opy_.replace(bstack1l111l_opy_ (u"ࠨࡽࠨࡖࡊ࡙ࡕࡍࡖࡖࡣࡈࡕࡕࡏࡖࠨࢁࠬಕ"), str(len(sessions)))
    bstack1111l1l1_opy_ = bstack1111l1l1_opy_.replace(bstack1l111l_opy_ (u"ࠩࡾࠩࡇ࡛ࡉࡍࡆࡢ࡙ࡗࡒࠥࡾࠩಖ"), bstack1l1l1lll_opy_)
    bstack1111l1l1_opy_ = bstack1111l1l1_opy_.replace(bstack1l111l_opy_ (u"ࠪࡿࠪࡈࡕࡊࡎࡇࡣࡓࡇࡍࡆࠧࢀࠫಗ"),
                                              sessions[0].get(bstack1l111l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡢࡲࡦࡳࡥࠨಘ")) if sessions[0] else bstack1l111l_opy_ (u"ࠬ࠭ಙ"))
    with open(os.path.join(bstack1lll1ll11_opy_, bstack1l111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠲ࡸࡥࡱࡱࡵࡸ࠳࡮ࡴ࡮࡮ࠪಚ")), bstack1l111l_opy_ (u"ࠧࡸࠩಛ")) as stream:
      stream.write(bstack1111l1l1_opy_.split(bstack1l111l_opy_ (u"ࠨࡽࠨࡗࡊ࡙ࡓࡊࡑࡑࡗࡤࡊࡁࡕࡃࠨࢁࠬಜ"))[0])
      for session in sessions:
        stream.write(bstack1ll1ll1111_opy_(session))
      stream.write(bstack1111l1l1_opy_.split(bstack1l111l_opy_ (u"ࠩࡾࠩࡘࡋࡓࡔࡋࡒࡒࡘࡥࡄࡂࡖࡄࠩࢂ࠭ಝ"))[1])
    logger.info(bstack1l111l_opy_ (u"ࠪࡋࡪࡴࡥࡳࡣࡷࡩࡩࠦࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠥࡨࡵࡪ࡮ࡧࠤࡦࡸࡴࡪࡨࡤࡧࡹࡹࠠࡢࡶࠣࡿࢂ࠭ಞ").format(bstack1lll1ll11_opy_));
  except Exception as e:
    logger.debug(bstack1lll11lll1_opy_.format(str(e)))
def bstack11lll1ll1_opy_(bstack1llllll11l_opy_):
  global CONFIG
  try:
    host = bstack1l111l_opy_ (u"ࠫࡦࡶࡩ࠮ࡥ࡯ࡳࡺࡪࠧಟ") if bstack1l111l_opy_ (u"ࠬࡧࡰࡱࠩಠ") in CONFIG else bstack1l111l_opy_ (u"࠭ࡡࡱ࡫ࠪಡ")
    user = CONFIG[bstack1l111l_opy_ (u"ࠧࡶࡵࡨࡶࡓࡧ࡭ࡦࠩಢ")]
    key = CONFIG[bstack1l111l_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡌࡧࡼࠫಣ")]
    bstack11ll11l1_opy_ = bstack1l111l_opy_ (u"ࠩࡤࡴࡵ࠳ࡡࡶࡶࡲࡱࡦࡺࡥࠨತ") if bstack1l111l_opy_ (u"ࠪࡥࡵࡶࠧಥ") in CONFIG else bstack1l111l_opy_ (u"ࠫࡦࡻࡴࡰ࡯ࡤࡸࡪ࠭ದ")
    url = bstack1l111l_opy_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡻࡾ࠼ࡾࢁࡅࢁࡽ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡤࡱࡰ࠳ࢀࢃ࠯ࡣࡷ࡬ࡰࡩࡹ࠯ࡼࡿ࠲ࡷࡪࡹࡳࡪࡱࡱࡷ࠳ࡰࡳࡰࡰࠪಧ").format(user, key, host, bstack11ll11l1_opy_,
                                                                                bstack1llllll11l_opy_)
    headers = {
      bstack1l111l_opy_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡵࡻࡳࡩࠬನ"): bstack1l111l_opy_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡰࡳࡰࡰࠪ಩"),
    }
    proxies = bstack11l1l111_opy_(CONFIG, url)
    response = requests.get(url, headers=headers, proxies=proxies)
    if response.json():
      return list(map(lambda session: session[bstack1l111l_opy_ (u"ࠨࡣࡸࡸࡴࡳࡡࡵ࡫ࡲࡲࡤࡹࡥࡴࡵ࡬ࡳࡳ࠭ಪ")], response.json()))
  except Exception as e:
    logger.debug(bstack1l111ll11_opy_.format(str(e)))
def bstack111l111l_opy_():
  global CONFIG
  try:
    if bstack1l111l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬಫ") in CONFIG:
      host = bstack1l111l_opy_ (u"ࠪࡥࡵ࡯࠭ࡤ࡮ࡲࡹࡩ࠭ಬ") if bstack1l111l_opy_ (u"ࠫࡦࡶࡰࠨಭ") in CONFIG else bstack1l111l_opy_ (u"ࠬࡧࡰࡪࠩಮ")
      user = CONFIG[bstack1l111l_opy_ (u"࠭ࡵࡴࡧࡵࡒࡦࡳࡥࠨಯ")]
      key = CONFIG[bstack1l111l_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡋࡦࡻࠪರ")]
      bstack11ll11l1_opy_ = bstack1l111l_opy_ (u"ࠨࡣࡳࡴ࠲ࡧࡵࡵࡱࡰࡥࡹ࡫ࠧಱ") if bstack1l111l_opy_ (u"ࠩࡤࡴࡵ࠭ಲ") in CONFIG else bstack1l111l_opy_ (u"ࠪࡥࡺࡺ࡯࡮ࡣࡷࡩࠬಳ")
      url = bstack1l111l_opy_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࢁࡽ࠻ࡽࢀࡄࢀࢃ࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡣࡰ࡯࠲ࡿࢂ࠵ࡢࡶ࡫࡯ࡨࡸ࠴ࡪࡴࡱࡱࠫ಴").format(user, key, host, bstack11ll11l1_opy_)
      headers = {
        bstack1l111l_opy_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡴࡺࡲࡨࠫವ"): bstack1l111l_opy_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩಶ"),
      }
      if bstack1l111l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩಷ") in CONFIG:
        params = {bstack1l111l_opy_ (u"ࠨࡰࡤࡱࡪ࠭ಸ"): CONFIG[bstack1l111l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬಹ")], bstack1l111l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡡ࡬ࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭಺"): CONFIG[bstack1l111l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭಻")]}
      else:
        params = {bstack1l111l_opy_ (u"ࠬࡴࡡ࡮ࡧ಼ࠪ"): CONFIG[bstack1l111l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡓࡧ࡭ࡦࠩಽ")]}
      proxies = bstack11l1l111_opy_(CONFIG, url)
      response = requests.get(url, params=params, headers=headers, proxies=proxies)
      if response.json():
        bstack1l1ll1l11_opy_ = response.json()[0][bstack1l111l_opy_ (u"ࠧࡢࡷࡷࡳࡲࡧࡴࡪࡱࡱࡣࡧࡻࡩ࡭ࡦࠪಾ")]
        if bstack1l1ll1l11_opy_:
          bstack1l1l1lll_opy_ = bstack1l1ll1l11_opy_[bstack1l111l_opy_ (u"ࠨࡲࡸࡦࡱ࡯ࡣࡠࡷࡵࡰࠬಿ")].split(bstack1l111l_opy_ (u"ࠩࡳࡹࡧࡲࡩࡤ࠯ࡥࡹ࡮ࡲࡤࠨೀ"))[0] + bstack1l111l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡵ࠲ࠫು") + bstack1l1ll1l11_opy_[
            bstack1l111l_opy_ (u"ࠫ࡭ࡧࡳࡩࡧࡧࡣ࡮ࡪࠧೂ")]
          logger.info(bstack1llll1ll11_opy_.format(bstack1l1l1lll_opy_))
          bstack1llll111l1_opy_ = CONFIG[bstack1l111l_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡒࡦࡳࡥࠨೃ")]
          if bstack1l111l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨೄ") in CONFIG:
            bstack1llll111l1_opy_ += bstack1l111l_opy_ (u"ࠧࠡࠩ೅") + CONFIG[bstack1l111l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪೆ")]
          if bstack1llll111l1_opy_ != bstack1l1ll1l11_opy_[bstack1l111l_opy_ (u"ࠩࡱࡥࡲ࡫ࠧೇ")]:
            logger.debug(bstack11l1l1lll_opy_.format(bstack1l1ll1l11_opy_[bstack1l111l_opy_ (u"ࠪࡲࡦࡳࡥࠨೈ")], bstack1llll111l1_opy_))
          return [bstack1l1ll1l11_opy_[bstack1l111l_opy_ (u"ࠫ࡭ࡧࡳࡩࡧࡧࡣ࡮ࡪࠧ೉")], bstack1l1l1lll_opy_]
    else:
      logger.warn(bstack1lll11l11l_opy_)
  except Exception as e:
    logger.debug(bstack11ll111l1_opy_.format(str(e)))
  return [None, None]
def bstack1lllll1l1_opy_(url, bstack111l11111_opy_=False):
  global CONFIG
  global bstack11l1l111l_opy_
  if not bstack11l1l111l_opy_:
    hostname = bstack11ll1l1ll_opy_(url)
    is_private = bstack1l1llll11_opy_(hostname)
    if (bstack1l111l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࠩೊ") in CONFIG and not CONFIG[bstack1l111l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࠪೋ")]) and (is_private or bstack111l11111_opy_):
      bstack11l1l111l_opy_ = hostname
def bstack11ll1l1ll_opy_(url):
  return urlparse(url).hostname
def bstack1l1llll11_opy_(hostname):
  for bstack1llll11111_opy_ in bstack111ll1ll_opy_:
    regex = re.compile(bstack1llll11111_opy_)
    if regex.match(hostname):
      return True
  return False
def bstack1lll111l1l_opy_(key_name):
  return True if key_name in threading.current_thread().__dict__.keys() else False