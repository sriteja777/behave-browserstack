# coding: UTF-8
import sys
bstack1l1llll_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack11l1lll_opy_ = 7
def bstack1l111l_opy_ (bstack1ll1l1l_opy_):
    global bstack1lllll1l_opy_
    bstack1lll_opy_ = ord (bstack1ll1l1l_opy_ [-1])
    bstack11l1111_opy_ = bstack1ll1l1l_opy_ [:-1]
    bstack111111_opy_ = bstack1lll_opy_ % len (bstack11l1111_opy_)
    bstack1llllll_opy_ = bstack11l1111_opy_ [:bstack111111_opy_] + bstack11l1111_opy_ [bstack111111_opy_:]
    if bstack1l1llll_opy_:
        bstack1l1l1_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack11111l1_opy_ + bstack1lll_opy_) % bstack11l1lll_opy_) for bstack11111l1_opy_, char in enumerate (bstack1llllll_opy_)])
    else:
        bstack1l1l1_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack11111l1_opy_ + bstack1lll_opy_) % bstack11l1lll_opy_) for bstack11111l1_opy_, char in enumerate (bstack1llllll_opy_)])
    return eval (bstack1l1l1_opy_)
import multiprocessing
import os
from browserstack_sdk.bstack1ll1ll1l_opy_ import *
from bstack_utils.helper import bstack1lll1111_opy_
from bstack_utils.messages import bstack1ll11l1l_opy_
from bstack_utils.constants import bstack1lll1l11_opy_
class bstack1ll11l11_opy_:
    def __init__(self, args, logger, bstack1ll1l1ll_opy_, bstack1ll1l11l_opy_):
        self.args = args
        self.logger = logger
        self.bstack1ll1l1ll_opy_ = bstack1ll1l1ll_opy_
        self.bstack1ll1l11l_opy_ = bstack1ll1l11l_opy_
        self._prepareconfig = None
        self.Config = None
        self.runner = None
        self.bstack1ll1llll_opy_ = []
        self.bstack1lll11ll_opy_ = None
        self.bstack1ll1lll1_opy_ = []
        self.bstack1lll11l1_opy_ = self.bstack1lll1lll_opy_()
        self.bstack1ll111l1_opy_ = -1
    def bstack1llll1l1_opy_(self, bstack1llll11l_opy_):
        self.parse_args()
        self.bstack1ll111ll_opy_()
        self.bstack1ll1ll11_opy_(bstack1llll11l_opy_)
    @staticmethod
    def version():
        import pytest
        return pytest.__version__
    def bstack1ll1111l_opy_(self, arg):
        if arg in self.args:
            i = self.args.index(arg)
            self.args.pop(i + 1)
            self.args.pop(i)
    def parse_args(self):
        self.bstack1ll111l1_opy_ = -1
        if bstack1l111l_opy_ (u"ࠩࡳࡥࡷࡧ࡬࡭ࡧ࡯ࡷࡕ࡫ࡲࡑ࡮ࡤࡸ࡫ࡵࡲ࡮ࠩࡵ") in self.bstack1ll1l1ll_opy_:
            self.bstack1ll111l1_opy_ = self.bstack1ll1l1ll_opy_[bstack1l111l_opy_ (u"ࠪࡴࡦࡸࡡ࡭࡮ࡨࡰࡸࡖࡥࡳࡒ࡯ࡥࡹ࡬࡯ࡳ࡯ࠪࡶ")]
        try:
            bstack1llll1ll_opy_ = [bstack1l111l_opy_ (u"ࠫ࠲࠳ࡤࡳ࡫ࡹࡩࡷ࠭ࡷ"), bstack1l111l_opy_ (u"ࠬ࠳࠭ࡱ࡮ࡸ࡫࡮ࡴࡳࠨࡸ"), bstack1l111l_opy_ (u"࠭࠭ࡱࠩࡹ")]
            if self.bstack1ll111l1_opy_ >= 0:
                bstack1llll1ll_opy_.extend([bstack1l111l_opy_ (u"ࠧ࠮࠯ࡱࡹࡲࡶࡲࡰࡥࡨࡷࡸ࡫ࡳࠨࡺ"), bstack1l111l_opy_ (u"ࠨ࠯ࡱࠫࡻ")])
            for arg in bstack1llll1ll_opy_:
                self.bstack1ll1111l_opy_(arg)
        except Exception as exc:
            self.logger.error(str(exc))
    def get_args(self):
        return self.args
    def bstack1ll111ll_opy_(self):
        bstack1lll11ll_opy_ = [os.path.normpath(item) for item in self.args]
        self.bstack1lll11ll_opy_ = bstack1lll11ll_opy_
        return bstack1lll11ll_opy_
    def bstack1ll1l1l1_opy_(self):
        try:
            from _pytest.config import _prepareconfig
            from _pytest.config import Config
            from _pytest import runner
            import importlib
            bstack1lll111l_opy_ = importlib.find_loader(bstack1l111l_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࡡࡶࡩࡱ࡫࡮ࡪࡷࡰࠫࡼ"))
            self._prepareconfig = _prepareconfig
            self.Config = Config
            self.runner = runner
        except Exception as e:
            self.logger.warn(e, bstack1ll11l1l_opy_)
    def bstack1ll1ll11_opy_(self, bstack1llll11l_opy_):
        if bstack1l111l_opy_ (u"ࠪ࠱࠲ࡩࡡࡤࡪࡨ࠱ࡨࡲࡥࡢࡴࠪࡽ") not in self.bstack1lll11ll_opy_:
            self.bstack1lll11ll_opy_.append(bstack1l111l_opy_ (u"ࠫ࠲࠳ࡣࡢࡥ࡫ࡩ࠲ࡩ࡬ࡦࡣࡵࠫࡾ"))
        if bstack1llll11l_opy_:
            self.bstack1lll11ll_opy_.append(bstack1l111l_opy_ (u"ࠬ࠳࠭ࡴ࡭࡬ࡴࡘ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠩࡿ"))
            self.bstack1lll11ll_opy_.append(bstack1l111l_opy_ (u"࠭ࡔࡳࡷࡨࠫࢀ"))
        self.bstack1lll11ll_opy_.append(bstack1l111l_opy_ (u"ࠧ࠮ࡲࠪࢁ"))
        self.bstack1lll11ll_opy_.append(bstack1l111l_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࡠࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡰ࡭ࡷࡪ࡭ࡳ࠭ࢂ"))
        self.bstack1lll11ll_opy_.append(bstack1l111l_opy_ (u"ࠩ࠰࠱ࡩࡸࡩࡷࡧࡵࠫࢃ"))
        self.bstack1lll11ll_opy_.append(bstack1l111l_opy_ (u"ࠪࡧ࡭ࡸ࡯࡮ࡧࠪࢄ"))
        if self.bstack1ll111l1_opy_ >= 0:
            self.bstack1lll11ll_opy_.append(bstack1l111l_opy_ (u"ࠫ࠲ࡴࠧࢅ"))
            self.bstack1lll11ll_opy_.append(str(self.bstack1ll111l1_opy_))
    def bstack1lll1l1l_opy_(self):
        bstack1ll1lll1_opy_ = []
        for spec in self.bstack1ll1llll_opy_:
            bstack1lllll11_opy_ = [spec]
            bstack1lllll11_opy_ += self.bstack1lll11ll_opy_
            bstack1ll1lll1_opy_.append(bstack1lllll11_opy_)
        self.bstack1ll1lll1_opy_ = bstack1ll1lll1_opy_
        return bstack1ll1lll1_opy_
    def bstack1lll1lll_opy_(self):
        try:
            from pytest_bdd import reporting
            self.bstack1lll11l1_opy_ = True
            return True
        except Exception as e:
            self.bstack1lll11l1_opy_ = False
        return self.bstack1lll11l1_opy_
    def bstack1ll1l111_opy_(self, bstack1lll1ll1_opy_, bstack1llll1l1_opy_):
        bstack1llll1l1_opy_[bstack1l111l_opy_ (u"ࠬࡉࡏࡏࡈࡌࡋࠬࢆ")] = self.bstack1ll1l1ll_opy_
        if bstack1l111l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩࢇ") in self.bstack1ll1l1ll_opy_:
            bstack1ll11ll1_opy_ = []
            manager = multiprocessing.Manager()
            bstack1ll11lll_opy_ = manager.list()
            for index, platform in enumerate(self.bstack1ll1l1ll_opy_[bstack1l111l_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪ࢈")]):
                bstack1ll11ll1_opy_.append(multiprocessing.Process(name=str(index),
                                                           target=bstack1lll1ll1_opy_,
                                                           args=(self.bstack1lll11ll_opy_, bstack1llll1l1_opy_)))
            i = 0
            for t in bstack1ll11ll1_opy_:
                os.environ[bstack1l111l_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡑࡎࡄࡘࡋࡕࡒࡎࡡࡌࡒࡉࡋࡘࠨࢉ")] = str(i)
                i += 1
                t.start()
            for t in bstack1ll11ll1_opy_:
                t.join()
            return bstack1ll11lll_opy_